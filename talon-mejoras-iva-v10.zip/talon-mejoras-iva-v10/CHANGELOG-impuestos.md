# Mejoras de Impuestos

## T1 · Moneda extranjera

- La liquidación convierte IVA, crédito y percepciones a pesos con `round(cents × tipo_cambio)` por alícuota.
- LID, CSV y XLSX expresan importes en pesos y conservan moneda y tipo de cambio.
- La base conserva los valores originales.
- Prueba: importar el fixture DOL y calcular 202609; USD 210 con TC 1050,5 aporta 22.060.500 centavos.

## T2 · Períodos confirmados

- La importación comprueba el cierre antes de crear `imp_import_jobs`.
- Los errores PostgreSQL 55000 se reconocen también dentro de `cause` y se traducen a 409.

## T3 · Período y fecha

- AAAAMM acepta 01–12 y años 2000–2100.
- Ventas de otro período y compras futuras se rechazan. Compras anteriores entran con revisión por cómputo diferido.

## T4 · Condición de IVA

- Lista única: RI, monotributo, exento, consumidor final y no alcanzado.
- Migración 0039 normaliza valores inválidos a RI, deja auditoría y agrega CHECK.
- F.2002 devuelve 409 para sujetos que no son RI. Los exentos conservan la exportación LID.

## T5 · Correcciones menores

- Un receptor distinto del titular queda con aviso y revisión.
- El vencimiento de pago se conserva cuando el archivo trae la columna y ocupa el campo 22 del LID.
- El ZIP omite archivos vacíos.
- TODO documentado: el README asigna permisos de Contabilidad al Contador aunque el módulo está intencionalmente apagado. No se modificó por estar fuera de alcance.

## T6 · IVA Simple

- Migración 0040: esquema por cliente e inicio configurable.
- Selección pura entre IVA Simple, F.2002/LID, LID exento y no corresponde.
- Resumen F.2051 por alícuota y certificados en `GET /api/impuestos/iva-simple/resumen`.
- Los endpoints de liquidación, reapertura y exportación reutilizan el cierre y los diseños comprobados.
- TODO: CSV “Ajustes y otros conceptos”. El PDF con columnas y códigos no está en el repo; no se inventó el formato.

## F1 · Retenciones y percepciones sufridas

- Migración 0042 con aislamiento por estudio y empresa cliente.
- API CRUD, duplicados, cierre de período y ventana origen+5 para percepciones.
- Pantalla de carga y consulta por período dentro de Ventas.
- La liquidación suma automáticamente certificados del período de cómputo; los campos manuales quedan como otros importes.
- TODO: importador oficial, pendiente del diseño de ARCA.

## F2 · Prorrateo

- Destino del crédito por compra: directo gravado, directo exento o prorrateable.
- Coeficiente automático por ventas y coeficiente manual configurable y auditado.
- La liquidación guarda el coeficiente usado.
- TODO: ajuste anual, pendiente de una fuente oficial inequívoca.

## F3 · Retenciones y percepciones practicadas

- Migración 0045 modela sujeto, régimen, base, alícuota, importe, fecha, comprobante y certificado con RLS.
- TODO: exportaciones SIRE F.2005 y SICORE F.744. Los diseños oficiales de registro no están disponibles localmente; no se inventaron posiciones.

## F4 · Vencimientos

- Migración 0043 global con fuente URL y fechas oficiales indicadas para 09/2026.
- Helper probado para todas las terminaciones y visualización en la empresa fiscal.

## F5 · Comprobantes manuales

- API de alta, edición de origen manual y baja lógica con control de período, duplicado, tipo, documento, total, IVA, crédito B/C y tolerancia.
- Clasificación para prorrateo y auditoría.
- Formulario visual de alta dentro de Ventas y Compras.
- Endpoint para deshacer un lote mediante baja lógica, motivo y auditoría.

## F6 · Diseños especiales

- TODO: servicios importados, TurIVA y bienes usados. El repo no contiene los diseños oficiales; no se generan archivos vacíos ni formatos supuestos.

## Migraciones

- 0039 condición IVA.
- 0040 configuración IVA Simple.
- 0041 vencimiento de pago.
- 0042 certificados sufridos.
- 0043 calendario.
- 0044 prorrateo.
- 0045 certificados practicados.

# Mejoras IVA v3 — brief v2 (23/10/2026)

Base: ZIP v2 copiado a `/workspace/saas/v3`, repositorio inicializado en la rama `mejoras-iva-v2`. Entorno probado con Node.js 24.19.0, npm 11.9.0 y PostgreSQL 16.15.

## B1 — resumen de IVA Simple
- El resumen aplica el signo de `imp_tipos_comprobante` y redondea cada neto/IVA después de convertir por `tipo_cambio`.
- Se agregó `src/lib/impuestos/iva-simple.ts` y prueba con NC y comprobante en dólares.
- Prueba API con los fixtures 202609: débito del resumen `2.877.000`, igual a `debitoFiscalCents`; crédito `24.370.501`, igual a `creditoComprasCents`. La factura USD quedó convertida con TC 1050,5.

## B2 — guardia de certificados
- Migración `0046_impuestos_guardias_y_practicadas.sql`: trigger 55000 sobre OLD y NEW de `periodo_computo`.
- PATCH comprueba primero el período original y luego el nuevo, con respuesta 409 clara.
- Repro API: mover un certificado desde 202609 confirmado a 202610 respondió 409. El test PostgreSQL verificó el código 55000.

## B3 — períodos inválidos
- `parsePeriodo` y `withErrors` traducen Zod a 400.
- Las cinco rutas del brief respondieron `400 Período inválido` para 202613: libro, exportar, liquidación, certificados e IVA Simple.
- Se mantienen los límites 2000-01 a 2100-12.

## B4 — fecha contra período
- POST y PATCH manuales aplican `reglaFechaImportada`.
- Verificado por API: venta 202608 en 202609 → 400; compra 202611 en 202609 → 400; compra 202608 en 202609 → 200, `requiere_revision=true` y aviso de cómputo diferido.

## B5 — auditoría
- Las bajas de comprobantes y certificados exigen motivo y escriben `impuestos.comprobante.anular` / `impuestos.certificado.anular`.
- Confirmar liquidación e importar escriben auditoría.
- Conteo manual comprobado: 1 baja de comprobante, 1 baja de certificado, 2 importaciones y 1 liquidación confirmada.

## P1 — IVA Simple
- `esquemaParaPeriodo` gobierna resumen, exportación y liquidación; `no_corresponde` responde 409 y el aviso de F.2002 posterior a 202511 llega a API/UI.
- Pantalla IVA Simple por empresa: resumen por alícuota, certificados, saldos, confirmar/reabrir y descargas disponibles.
- Avisos de tamaño: TXT >10 MB, TXT >70 MB y ZIP >10 MB.
- Resuelto en v4 con el PDF oficial incluido en el paquete: CSV de ajustes con posiciones, códigos y snapshots anonimizados.

## P2 — prorrateo
- PATCH individual y masivo de `destinoCredito`, válidos para comprobantes importados, con cierre y auditoría.
- Selector en Libro IVA Compras.
- Verificación API: la factura 1001 fue marcada `prorratea`; con venta exenta el coeficiente fue 5781 bps y el crédito bajó de 24.370.501 a 23.484.511.
- El diseño del LID para informar prorrateo queda **TODO** hasta disponer de especificación oficial inequívoca.

## P3 — certificados
- `periodoOrigen` debe coincidir con el mes de `fecha`.
- Pendientes muestra percepciones futuras y marca el mes límite origen+5.
- La liquidación separa certificados automáticos de importes manuales.
- Importador oficial: **TODO**, no se encontró un diseño oficial de registro utilizable.

## P4 — retenciones practicadas
- CRUD con edición, baja lógica, motivo, auditoría, control de período y relación opcional con comprobante de venta.
- Valida `importe = base × alícuota` con tolerancia de `imp_config`; incluye listado, formulario y CSV.
- Migración 0046 amplía policy/GRANT. Tests de importe y RLS en verde.
- Resuelto en v4: SIRE F.2005 oficial y SICORE v9 experimental detrás de un flag.

## P5 — vencimientos
- Tablero y detalle muestran próximo vencimiento, estado abierto/confirmado y resaltan vencidos sin confirmar.
- Helper y pruebas para terminaciones, ausencia de datos y vencido sin confirmar.
- **TODO de datos:** `https://seti.afip.gob.ar/av/viewVencimientos.do` respondió HTTP 403. Se conserva únicamente 202609, ya verificado (19–23/10/2026; exentos 15/10/2026); no se calcularon fechas por fórmula.

## P6 — períodos
- Cubierto por B3/B4, con meses y años fuera de rango rechazados.

## P7 — sujetos exentos
- **TODO ARCA:** el diseño oficial no pudo obtenerse en este entorno. Se conserva el LID común con aviso explícito y no se afirma compatibilidad con el diseño de sujetos exentos.

## P8 — servicios, TurIVA y bienes usados
- Resuelto en v4 con los diseños oficiales: importación de servicios, TurIVA y bienes usados; los archivos vacíos se omiten.

## Menores
- CSV del LID emite Tipo, Punto de venta y Número como enteros.
- Los 409 usan “Reabrilo para continuar” y los movimientos de certificado identifican período original/nuevo.
- Una reimportación ignora comprobantes anulados; historial de importaciones permite deshacer con motivo.
- RLS cubre certificados, retenciones practicadas y escritura denegada de vencimientos.

## Verificación
- `npx vitest run`: 43 archivos aprobados, 162 tests aprobados, 26 omitidos por flags de integración.
- `npx tsc --noEmit`: correcto.
- `npm run lint`: 0 errores, 3 advertencias preexistentes (TanStack Virtual y navegación de sesión).
- `npm run build`: correcto, 44 rutas.
- `RUN_DB_TESTS=1 npx vitest run src/lib/db/`: 13 tests DB aprobados (11 Impuestos/RLS, 1 RLS general, 1 seed); 14 flows omitidos por su flag propio.
- `npm run test:flows`: 14/14 circuitos HTTP con PostgreSQL aprobados.
- Migraciones: correctas desde base vacía y desde una base detenida exactamente en 0037.
- Repros API B1–B5: ejecutadas en servidor local de desarrollo contra PostgreSQL de demostración.

No se realizó ninguna acción externa ni presentación ante ARCA.

# Mejoras IVA v4 — 23/10/2026

## Correcciones A–D y M1–M3
- `0047_impuestos_v4_guardias.sql` reemplaza la identidad de comprobantes por un índice único parcial sobre filas vigentes. Una identidad anulada puede reimportarse o cargarse manualmente conservando historial; los vigentes continúan detectándose como duplicados.
- Retenciones practicadas y certificados verifican el período original y el nuevo. Los triggers rechazan cambios directos con SQLSTATE 55000 y devuelven `OLD` en DELETE.
- El tablero elige el vencimiento oficial más antiguo sin confirmar, incluso vencido, y filtra la obligación por condición fiscal. Monotributo no muestra obligación de IVA.
- El CSV de practicadas tiene nueve columnas alineadas y coma decimal. Las practicadas y pendientes validan y filtran el período.
- Deshacer una importación dos veces responde 409 sin duplicar auditoría. La baja sin JSON pide el motivo. Los mensajes distinguen alta, período original y período nuevo.
- F.2002 anterior a 202511 incluye el aviso de esquema en resumen y liquidación.

## P1, P2, P4, P5 y P6
- Los avisos sintéticos cubren archivos mayores a 10 MB y 70 MB. IVA Simple incorpora alta, baja, listado y exportación de ajustes.
- El crédito computable por prorrateo se informa en el campo 21 de Compras Cabecera. Fuente: `Libro-IVA-Digital-Especificaciones.pdf`, apartado “Crédito Fiscal Computable”, págs. 17–18; el diseño no contiene otro campo de coeficiente.
- SIRE F.2005 y SICORE experimental se descargan desde Retenciones practicadas. F.2003/F.2004 responden 409 mientras falten datos obligatorios específicos, evitando archivos inválidos.
- Se intentó `curl -A Mozilla/5.0 https://seti.afip.gob.ar/av/viewVencimientos.do` el 23/10/2026: `CONNECT tunnel failed, response 403`. No se inventaron fechas 2026/2027.
- Todas las rutas GET con período usan `parsePeriodo`; 202613, 199912 y `abc` devuelven 400.

## N1 — SIRE
- Funciones puras de ancho fijo para F.2003 (415), F.2004 (191) y F.2005 (305), ISO-8859-1 y CRLF en descargas.
- Fuente: `SIRE-especificacion-para-emision-por-lote.pdf`, §§2, 3.1–3.2, 4.1–4.2 y 5.1–5.2, PDF 08/01/2025.
- F.2005 valida régimen, CUIT, importe y fecha del período antes de descargar. F.2003/F.2004 quedan deshabilitados hasta modelar país/NIF/CDI o seguridad social.

## N2 — ajustes de IVA Simple
- `0048_impuestos_ajustes_servicios.sql` agrega `imp_iva_ajustes` con RLS, auditoría, baja lógica y guardia 55000.
- Genera CSV separados de débito y crédito, con `;` y coma decimal; sólo se incluyen en el ZIP cuando contienen filas. Los importes se incorporan a la liquidación con su signo.
- Fuente: `LID-Ajustes-y-otros-conceptos-para-generar-la-DJ.pdf`, secciones 1–4, PDF 29/05/2025.

## N3 — importación de servicios
- Modelo tenant, RLS, carga API, impacto en crédito fiscal y TXT de 211 posiciones dentro del ZIP cuando hay registros.
- Fuente: `libro-iva-digital-diseno-registros.pdf`, “Importaciones de Servicios”, pág. 8, PDF 14/01/2025.

## N4 y N5 — TurIVA y bienes usados
- Los tipos 063, 195, 196 y 197 se separan de la cabecera común y generan cabeceras TurIVA de 281/340 posiciones. Fuente: diseño oficial, págs. 2 y 5.
- Compras 030, 032 y 049 usan Compras Cabecera (325) y sus alícuotas. Fuente: `Libro-IVA-Digital-Especificaciones.pdf`, apartado “Bienes usados”, PDF 30/07/2025.

## N6 — SICORE experimental
- Flag `IMP_SICORE_EXPERIMENTAL=1`, apagado por defecto. Sin flag responde 409 con “Exportación SICORE no disponible: diseño a confirmar”.
- Con flag genera 146 posiciones y advierte “Posiciones a confirmar con la ayuda de SICORE”. La estructura queda marcada como experimental porque ARCA no publica el diseño v9.

## Privacidad
- Se agregaron al `.gitignore` los patrones obligatorios. Los ejemplos reales permanecieron fuera del repo y no se copiaron a tests, documentación ni entrega. Los fixtures nuevos usan nombres y CUIT ficticios.

## Verificación v4
- `npx vitest run`: 49 archivos aprobados, 180 tests aprobados; 28 omitidos por flags de integración.
- `npx tsc --noEmit`: correcto.
- `npm run lint`: 0 errores y 3 advertencias preexistentes.
- `npm run build`: correcto, 44 rutas.
- `RUN_DB_TESTS=1 npm run test:db`: 14/14 pruebas PostgreSQL aprobadas.
- `npm run test:flows`: 14/14 circuitos HTTP aprobados sobre build de producción.
- Migraciones: base vacía aprobada por el test de seed; actualización desde 0037 hasta 0048 verificada en una base temporal local.
- NO VERIFICADO: presentación o validación contra ARCA real; calendario completo 2026/2027 por HTTP 403 oficial; SIRE F.2003/F.2004 por faltar datos del modelo; SICORE v9 contra la ayuda del aplicativo de Windows.

# Mejoras IVA v5 — 23/10/2026

- V1 — deshacer/reimportar. Test `V1: deshace una sola vez y permite reimportar el mismo archivo` en `src/lib/db/impuestos-rls.integration.test.ts`. **Verificado**.
- V2 — decimales SIRE F.2003/F.2004/F.2005. Tests `V2 F.2003...`, `V2 F.2004...`, `V2 F.2005...` en `src/lib/impuestos/sire/index.test.ts`. **Verificado**.
- Ajustes IVA Simple — cuatro estructuras y dación. Suite `ajustes IVA Simple — cuatro estructuras oficiales`. **Verificado estructuralmente**.
- V4/V5 — guardias 55000 y respuestas 409 para servicios y ajustes. Tests `V4: protege importaciones...` y `V5: permite ajustes abiertos...`. **Verificado**.
- V6/V7 — bienes usados y TurIVA separados. Suites `bienes usados` y `TurIVA`. **Verificado**.
- V8 — edición y anulación lógica de servicios con auditoría. Test V4 ampliado y RLS. **Verificado**.
- SIRE — carga/exportación F.2003/F.2004. Flujo HTTP en `business-flows.integration.test.ts`. **Verificado**.
- SICORE — máscara experimental de 145 posiciones. Test `genera la máscara deducida de 145 posiciones`. **Verificado estructuralmente; falta la ayuda oficial de SICORE 9**.
- P1/P2/C — límites, prorrateo en campo 21 y orden por vencimiento. Tests en `iva-simple.test.ts`, `prorrateo.test.ts` y `vencimientos.test.ts`. **Verificado**.

Conteos corregidos según la revisión de la entrega v5: 190 pruebas generales aprobadas y 18 pruebas DB aprobadas. El archivo anterior indicaba 191 y 17. La validación contra ARCA real y Windows quedó **NO VERIFICADA**.

# Mejoras IVA v6 — 23/10/2026

- W1 — `src/server/impuestos.ts`: cada exportación SIRE filtra su formulario; F.2005 ya no duplica F.2003/F.2004. Test API dentro de `alta, numeradores por punto, vaciado con respaldo y eliminación aislados`, en `src/lib/db/business-flows.integration.test.ts`, que comprueba una línea de 415/191/305 por formulario. **Resuelto y verificado**.
- W2 — `src/lib/impuestos/iva-simple-ajustes/index.ts`: Débito y Restitución de Débito tienen ocho campos exactos; las operaciones exentas terminan en el importe. Suite `ajustes IVA Simple — ejemplos completos del PDF`, con líneas completas para tipos 1, 2 y 3. **Resuelto y verificado**.
- W3 — `src/lib/impuestos/iva-simple-ajustes/index.test.ts`: la salida anonimizada se compara por cantidad de campos y máscara contra ejemplos locales. Test `compara la salida anonimizada con las máscaras reales sin imprimir valores`. **Verificado localmente**; se omite cuando falta `TALON_EJEMPLOS_REALES`.
- W4 — `drizzle/0055_impuestos_sicore_datos.sql`, `src/lib/impuestos/sicore/index.ts` y carga mínima en UI: SICORE queda exclusivo, usa códigos y certificado cargados, mantiene 145 posiciones, solo la retención lleva coma y termina con CRLF. Tests `genera la máscara deducida de 145 posiciones y CRLF final`, `compara toda la máscara sin imprimir valores` y `acepta combinaciones de la tabla local de códigos`. **Verificado estructuralmente**. Sigue experimental detrás de `IMP_SICORE_EXPERIMENTAL=1`; compatibilidad con la ayuda oficial de SICORE 9 **NO VERIFICADA**.
- W5 — `src/lib/impuestos/importacion-servicios/index.ts`, `src/lib/impuestos/sire/index.ts` y API: servicios y los tres SIRE terminan con CRLF. Tests `termina el archivo con CRLF` y `termina cada archivo SIRE con CRLF`. **Resuelto y verificado**.
- W6 — `src/server/impuestos.ts`: F.2003 exige C29 para personas físicas y conserva el 409 por archivo completo con detalle por registro. El flujo HTTP prueba una persona física completa (200 y fecha en posiciones 406–415) y otra incompleta (409 con C29 nombrado). **Resuelto y verificado**.
- W7 — `src/lib/db/business-flows.integration.test.ts`: API acepta el límite de 15.000.000 bytes sin responder 413 y rechaza 15.000.001 con 413. `src/components/impuestos/impuestos-screen.test.tsx` prueba el orden vencida, próxima, confirmada y sin fecha a las 22:00 de Buenos Aires; `iva-simple.test.ts` conserva los avisos de 10/70 MB. El límite de importación y el orden están probados; los topes de exportación solo tienen prueba unitaria. **Verificación parcial**.
- W8 — `src/lib/impuestos/libro-iva-digital/build.ts`: el PDF solo define cabeceras TurIVA y archivos comunes de alícuotas; se documentó la decisión y el TODO para versiones futuras. Test `envía ventas/compras al archivo común del PDF` en `turiva.test.ts`. **Resuelto y verificado contra el PDF disponible**.

## Verificación v6

Entorno: Node.js 24.19.0, npm 11.9.0 y PostgreSQL 16.15.

- `npx vitest run`: 51 archivos aprobados y 3 omitidos; 200 tests aprobados y 34 omitidos por flags/fixtures opcionales.
- `npx tsc --noEmit`: correcto.
- `npm run lint`: 0 errores y 3 advertencias conocidas (TanStack Virtual y navegación de sesión).
- `RUN_DB_TESTS=1 npx vitest run src/lib/db/`: 18 tests aprobados y 14 flujos omitidos por su flag.
- `npm run test:flows`: build de producción correcto; 14/14 flujos HTTP aprobados.
- Base vacía: migraciones verificadas por `seed.integration.test.ts`.
- Actualización desde 0054: verificada en una base temporal hasta `0055_impuestos_sicore_datos.sql`.
- Tests opcionales con `TALON_EJEMPLOS_REALES`: 13/13 aprobados; no imprimen ni copian valores.
- Totales de referencia 202609 y regresiones V1, V4–V8, V2 y P2 permanecen cubiertos por las suites DB y de flujos.

## Pendientes reales

- **NO VERIFICADO:** importación o presentación en aplicativos/servicios reales de ARCA.
- **NO VERIFICADO:** SICORE contra la ayuda oficial interna de SICORE 9.
- **NO VERIFICADO:** ejecución manual de esta entrega en otra PC con Windows.

# Mejoras IVA v7 — 23/10/2026

- X1 — **Resuelto y verificado.** `src/server/impuestos.ts` valida `condicion` y filtra; `src/components/impuestos/impuestos-screen.tsx` ofrece el selector. Tests: `filtra por condición conservando el orden` en `impuestos-screen.test.tsx` y filtros HTTP en `business-flows.integration.test.ts`.
- X2 — **Resuelto y verificado.** `src/lib/impuestos/iva-simple-ajustes/index.ts` valida las cuatro estructuras del PDF; `src/server/impuestos.ts` responde 400 al cargar y 409 al exportar ajustes existentes inválidos. Tests: `X2 combinaciones por estructura` y casos HTTP en `business-flows.integration.test.ts`.
- X3 — **Aviso implementado; tabla oficial pendiente.** `src/lib/impuestos/sicore/index.ts` documenta la falta de una tabla pública confirmada; `src/server/impuestos.ts` devuelve `X-Talon-Warning` también si un código como 999 supera la validación de rango. Test: `advierte cuando un impuesto como 999 sólo supera la validación de rango`. La máscara permanece experimental.
- X4 — **Resuelto.** `src/lib/impuestos/practicadas.ts` agrega `formulario` como décima columna. Test: `genera un CSV alineado y con coma decimal`.
- X5 — **Pendiente de prueba API a 10/70 MB.** El límite de 15 MB sí se prueba por HTTP en `business-flows.integration.test.ts`. Generar 70 MB de registros fiscales por HTTP requiere una base local y tiempo de creación significativo; la alternativa vigente es `avisosTamanoExportacion` en `iva-simple.test.ts`, que cubre ambos umbrales y el tamaño del ZIP.

La prueba `CRLF, ANSI y ZIP legible` en `src/lib/impuestos/libro-iva-digital/index.test.ts` ahora verifica descompresión y CRC con Node, para poder correr dentro del sandbox.

# Mejoras IVA v8 — 23/10/2026

- Y1 — **Resuelto y verificado por HTTP.** `src/server/impuestos.ts` acepta débito tipo 3 y restitución tipo 2 sin `netoCents` ni `impuestoFacturadoCents`, los guarda como cero y nombra los campos obligatorios ausentes. Test: casos HTTP de ajuste exento, edición y exportación en `src/lib/db/business-flows.integration.test.ts`.
- Y2 — **Resuelto y verificado por HTTP.** `src/server/impuestos.ts` avisa en `avisos` al superar 10 MB y responde 413 al superar 70 MB por archivo. El header `X-Talon-Test-Export-Bytes` solo se interpreta con `RUN_FLOW_TESTS=1`, para probar ambos límites sin crear archivos enormes. Tests: cuatro tamaños por HTTP en `business-flows.integration.test.ts` y límites unitarios en `src/lib/impuestos/iva-simple.test.ts`.
- Y3 — **Resuelto y verificado por HTTP.** `src/lib/http.ts` convierte el SQLSTATE 22023 de un período no cerrado en 409 con su mensaje y los otros parámetros inválidos en 400. Tests: reapertura en borrador por HTTP en `business-flows.integration.test.ts` y `errores 22023 de PostgreSQL` en `src/lib/http.test.ts`.
- Y4 — **Resuelto y verificado por HTTP.** `src/lib/impuestos/sicore/index.ts` mantiene el aviso experimental en ASCII para `X-Talon-Warning`. Test: exportación SICORE por HTTP en `business-flows.integration.test.ts` y `X3 códigos no confirmados` en `src/lib/impuestos/sicore/index.test.ts`. La tabla oficial SICORE 9 sigue pendiente.

## Verificación v8

- `npx vitest run`: 208 tests aprobados, 35 omitidos por flags o ejemplos opcionales.
- `npx tsc --noEmit`: correcto.
- `npm run lint`: 0 errores y 3 advertencias preexistentes.
- `RUN_DB_TESTS=1 npx vitest run src/lib/db/`: 18 tests aprobados; 14 flujos omitidos por su flag.
- `npm run test:flows`: compilación de producción y 14 tests HTTP aprobados.
- `npx next build --webpack`: compilación de producción correcta. El comando directo `npx next build` con Turbopack falla en este entorno al intentar abrir un puerto de su worker (`Operation not permitted`); el script `npm run build` usa la opción webpack documentada por Next.js.
- No se realizó validación contra servicios reales de ARCA. La tabla oficial de códigos SICORE 9 sigue pendiente.

# Mejoras IVA v9 — 24/10/2026

- Z1/Z2 — **Resuelto.** Los cinco formularios de Impuestos envían con clic; la carga manual y certificados conservan la referencia al formulario antes del `await`, muestran “Guardando…” y limpian después de guardar. El test de componente hace clic, recibe HTTP 200 y comprueba POST, formulario limpio y ausencia del error de `reset`.
- Z3 — **Resuelto.** Breadcrumbs, retorno al nivel padre y navegación a todas las secciones con resaltado de la activa. “Dar de baja” se muestra en la ficha principal.
- Z4/Z5 — **Resuelto.** Carga manual con hasta diez alícuotas oficiales, cálculo automático de IVA editable, total en vivo, crédito fiscal de compras, conceptos adicionales y parser es-AR compartido. Los importes inválidos se señalan por campo en la carga manual. El servidor conserva la validación fiscal de coherencia del IVA con su tolerancia existente.
- Z6/Z7 — **Resuelto.** Etiquetas visibles en carga manual y certificados; selector de comprobantes de la tabla local ARCA filtrado por libro y por la matriz de condiciones cuando ambas se conocen; vista `PPPPP-NNNNNNNN` y CUIT con dígito verificador.
- Z8/Z9/Z10 — **Resuelto en los flujos afectados.** Certificados validan mes y muestran estados vacíos; Monotributo muestra aviso en Liquidación sin cambiar la lógica fiscal; formularios muestran el envío y los errores. La validación en línea detallada por campo está concentrada en la carga manual; otros formularios conservan su validación nativa o mensaje general.

## Verificación v9

- `npx vitest run`: 214 tests aprobados, 35 omitidos por flags o fixtures opcionales.
- `npx tsc --noEmit`: correcto.
- `npm run lint`: 0 errores; tres advertencias previas.
- `RUN_DB_TESTS=1 npx vitest run src/lib/db/`: 18 tests aprobados; 14 flujos omitidos por su flag.
- `npm run test:flows`: build correcto y 14 flujos HTTP aprobados.
- `npm run build`: build de producción correcto con webpack.
- No se hizo una prueba manual contra servicios reales de ARCA. Continúa pendiente la tabla oficial SICORE 9.

# Mejoras IVA v10 — 24/10/2026

- J1 — **Resuelto.** La ficha de empresa agrupa accesos en Compras, Ventas, IVA, Retenciones y Configuración. Las subpantallas muestran breadcrumb, “Volver” y, solo en Compras/Ventas, accesos del área. Test de componente comprueba que no aparece la botonera de diez accesos.
- J2 — **Resuelto.** Breadcrumb y “Volver” comparten `rutaImpuestos`. Carga y Libro IVA vuelven a Compras o Ventas según la ruta; Importar respeta el origen. Los enlaces a ambos libros incluyen `?libro=`. Se conserva el filtro del listado y el URL del padre al navegar desde él. Tabla de pruebas unitarias y de componente para los destinos.
- N1 — **Resuelto.** Al cambiar la condición IVA, el tipo elegido se conserva si sigue permitido por la matriz. Test comprueba conservación y borrado cuando deja de estar permitido.
- V1/V7 — **Resuelto.** El selector de comprobantes se limita a su columna y el Libro IVA permite desplazamiento horizontal con ancho suficiente para “Otros tributos”.
- Z6 — **Resuelto.** Rótulos visibles y asociados en Retenciones practicadas y ajustes. Los conceptos 1–4 tienen las descripciones del PDF oficial de ARCA citado por la exportación; se usan también para validar el código.
- Opcionales N3, V6 y O1 — **Resueltos.** Certificados muestran el tipo en lenguaje claro; la carga manual distingue éxito y error; el Libro IVA tiene pestañas Compras/Ventas y muestra el libro elegido.

## Verificación v10

- `npx vitest run`: 242 pruebas aprobadas, 35 omitidas por flags o fixtures opcionales.
- `npx tsc --noEmit`: correcto.
- `npm run lint`: sin errores; tres advertencias preexistentes.
- `RUN_DB_TESTS=1 npx vitest run src/lib/db/`: 18 tests aprobados; 14 flujos omitidos por su flag.
- `npm run test:flows`: build de producción correcto y 14 flujos HTTP aprobados.
- `npm run build`: build de producción correcto con webpack.
- Siguen pendientes los opcionales N2, Z10 (validación en blur), V3/V4, O2–O5 y la validación contra servicios reales de ARCA. SICORE conserva su aviso experimental.

import { defaultCompanyMode } from "@/lib/company-setup";
import { createCompany } from "@/lib/domain/company";
import { createHash } from "node:crypto";
import { cookies } from "next/headers";
import { sql } from "drizzle-orm";
import { z } from "zod";
import { getDb } from "@/lib/db/client";
import { getAuth, switchCompany } from "@/lib/auth/session";
import { createCompanySchema } from "@/lib/company-setup";
import { HttpError, ok } from "@/lib/http";
import { readBody } from "@/lib/validation";

export async function companyManagement(
  method: string,
  path: string[],
  req: Request,
) {
  const token = (await cookies()).get("talon_session")?.value;
  if (!token) throw new HttpError(401, "Tenés que iniciar sesión");
  const hash = createHash("sha256").update(token).digest("hex");
  const [valid] = await getDb().execute<{ actor: string | null }>(
    sql`select lifecycle_actor(${hash})::text as actor`,
  );
  if (!valid.actor) throw new HttpError(401, "La sesión venció");
  const [, id, action] = path;
  if (method === "GET" && id === "capacidades") {
    const [row] = await getDb().execute<{ canCreate: boolean; valid: boolean }>(
      sql`select company_can_create(${hash}) as "canCreate", lifecycle_actor(${hash}) is not null as valid`,
    );
    if (!row.valid) throw new HttpError(401, "La sesión venció");
    const auth = await getAuth();
    return ok({
      canCreate: row.canCreate,
      canDestroy: auth?.company.roleKey === "admin",
      defaultMode: defaultCompanyMode(),
    });
  }
  if (method === "POST" && !id) {
    const input = await readBody(req, createCompanySchema);
    const created = await getDb().transaction((tx) =>
      createCompany(tx, hash, input),
    );
    await switchCompany(created.id);
    return ok(created);
  }
  if (method === "POST" && id === "respaldos" && !action) {
    const body = await readBody(
      req,
      z.object({
        companyId: z.string().uuid(),
        kind: z.enum(["manual", "automatico"]).default("manual"),
      }),
    );
    const auth = await getAuth();
    if (!auth || auth.company.companyId !== body.companyId)
      throw new HttpError(403, "Seleccioná la empresa que querés respaldar");
    const [row] = await getDb().execute<{ backupId: string }>(
      sql`select company_backup_create(${hash},${body.companyId}::uuid,${body.kind})::text as "backupId"`,
    );
    return ok({
      backupId: row.backupId,
      downloadUrl: `/api/empresas/respaldos/${row.backupId}`,
    });
  }
  if (
    method === "POST" &&
    id === "respaldos" &&
    action &&
    path[3] === "restaurar"
  ) {
    const parsedId = z.string().uuid().safeParse(action);
    if (!parsedId.success) throw new HttpError(400, "Respaldo inválido");
    const backupId = parsedId.data;
    const body = await readBody(
      req,
      z.object({ confirmation: z.string().min(1).max(120) }),
    );
    const [source] = await getDb().execute<{
      backup: {
        schemaMigrations: string[];
        company: { id: string; name: string };
      } | null;
    }>(
      sql`select company_backup_download(${hash},${backupId}::uuid) as backup`,
    );
    if (!source.backup) throw new HttpError(404, "No encontramos el respaldo");
    const [available] = await getDb().execute<{
      backups: { id: string; restoreName: string; canRestore: boolean }[];
    }>(sql`select company_backups(${hash}) as backups`);
    const metadata = available.backups.find((b) => b.id === backupId);
    if (!metadata?.canRestore)
      throw new HttpError(
        403,
        "Sólo el administrador actual puede recuperar esta empresa",
      );
    if (body.confirmation !== metadata.restoreName)
      throw new HttpError(400, "Escribí el nombre exacto de la empresa");
    const migrations = await getDb().execute<{ id: string }>(
      sql`select id from schema_migrations order by id`,
    );
    if (
      JSON.stringify(source.backup.schemaMigrations) !==
      JSON.stringify(migrations.map((m) => m.id))
    )
      throw new HttpError(
        409,
        "Este respaldo es de otra versión. Requiere una recuperación técnica; no se modificaron los datos.",
      );
    const [restored] = await getDb().execute<{ companyId: string }>(
      sql`select company_backup_restore(${hash},${backupId}::uuid,${body.confirmation})::text as "companyId"`,
    );
    await switchCompany(restored.companyId);
    return ok({ ...restored, userId: valid.actor });
  }
  if (method === "GET" && id === "respaldos" && !action) {
    const [row] = await getDb().execute<{ backups: unknown }>(
      sql`select company_backups(${hash}) as backups`,
    );
    return ok({ items: row.backups });
  }
  if (method === "GET" && id === "respaldos" && action) {
    const backupId = z.string().uuid().safeParse(action);
    if (!backupId.success) throw new HttpError(400, "Respaldo inválido");
    const [row] = await getDb().execute<{ backup: unknown }>(
      sql`select company_backup_download(${hash},${backupId.data}::uuid) as backup`,
    );
    if (!row.backup) throw new HttpError(404, "No encontramos el respaldo");
    return new Response(JSON.stringify(row.backup), {
      headers: {
        "Content-Type": "application/json",
        "Content-Disposition": `attachment; filename="talon-respaldo-${backupId.data}.json"`,
        "Cache-Control": "private, no-store",
      },
    });
  }
  if (
    method === "POST" &&
    id &&
    (action === "vaciar" || action === "eliminar")
  ) {
    if (!z.string().uuid().safeParse(id).success)
      throw new HttpError(400, "Empresa inválida");
    const auth = await getAuth();
    if (!auth || auth.company.companyId !== id)
      throw new HttpError(403, "Seleccioná la empresa que querés administrar");
    const body = await readBody(
      req,
      z.object({ confirmation: z.string().min(1).max(120) }),
    );
    if (body.confirmation !== auth.company.companyName)
      throw new HttpError(400, "Escribí el nombre exacto de la empresa");
    const [row] = await getDb().execute<{ backupId: string }>(
      sql`select company_destroy(${hash},${id}::uuid,${action},${body.confirmation})::text as "backupId"`,
    );
    return ok({
      backupId: row.backupId,
      downloadUrl: `/api/empresas/respaldos/${row.backupId}`,
    });
  }
  throw new HttpError(404, "No existe esa ruta");
}

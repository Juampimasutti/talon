// @vitest-environment happy-dom
import {cleanup,render} from '@testing-library/react';
import {afterEach,expect,it,vi} from 'vitest';
import {LibroScreen} from './libro-screen';
vi.mock('next/navigation',()=>({useSearchParams:()=>new URLSearchParams('libro=compras')}));
vi.mock('next/link',()=>({default:({href,children,...props}:React.ComponentProps<'a'>)=><a href={href} {...props}>{children}</a>}));
vi.mock('@/lib/api/client',()=>({apiSend:vi.fn(async()=>({items:[]}))}));
afterEach(cleanup);
it('muestra las pestañas y el encabezado del libro solicitado',()=>{const view=render(<LibroScreen empresaId="ficticia" libro="compras"/>);expect(view.getByRole('heading',{name:'Libro IVA Compras'})).toBeTruthy();expect(view.getByRole('tab',{name:'Compras'}).getAttribute('aria-selected')).toBe('true');expect(view.getByRole('tab',{name:'Ventas'}).getAttribute('href')).toContain('libro=ventas')});

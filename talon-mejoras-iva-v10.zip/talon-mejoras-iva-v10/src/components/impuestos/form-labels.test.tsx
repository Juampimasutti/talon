// @vitest-environment happy-dom
import {cleanup,render} from '@testing-library/react';
import {afterEach,expect,it,vi} from 'vitest';
import {RetencionesPracticadasScreen} from './retenciones-practicadas-screen';
import {IvaAjustes} from './iva-ajustes';
vi.mock('@tanstack/react-query',()=>({useQuery:()=>({data:{items:[]}}),useQueryClient:()=>({invalidateQueries:vi.fn()})}));
afterEach(cleanup);
it('rotula los campos de retenciones practicadas',()=>{const view=render(<RetencionesPracticadasScreen empresaId="ficticia"/>);for(const label of ['Tipo de comprobante SIRE','F.2003 NIF','SICORE impuesto','SICORE certificado original','Importe retenido $','Aplica CDI','Acrecentamiento'])expect(view.getByLabelText(label)).toBeTruthy()});
it('describe el concepto oficial y rotula los importes del ajuste',()=>{const view=render(<IvaAjustes empresaId="ficticia" periodo="202610"/>);for(const label of ['Lado','Actividad (6 dígitos)','Concepto','Alícuota','Neto','IVA','Dación'])expect(view.getByLabelText(label)).toBeTruthy();expect(view.getByRole('option',{name:/1 · Por Compras de Bienes/})).toBeTruthy()});

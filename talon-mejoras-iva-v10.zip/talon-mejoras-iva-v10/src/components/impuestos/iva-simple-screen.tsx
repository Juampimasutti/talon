"use client";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiGet } from "@/lib/api/client";
import { formatMoney } from "@/lib/format";
import { LiquidacionScreen } from "./liquidacion-screen";
import { ExportarScreen } from "./exportar-screen";
import { IvaAjustes } from "./iva-ajustes";

const current=()=>new Date().toISOString().slice(0,7).replace("-","");
type Resumen={alicuotas:{libro:string;codigo:number;netoCents:number;ivaCents:number}[];certificados:{tipo:string;importeCents:number}[];avisos:string[]};
export function IvaSimpleScreen({empresaId}:{empresaId:string}){
 const[periodo,setPeriodo]=useState(current);const q=useQuery({queryKey:["iva-simple",empresaId,periodo],queryFn:()=>apiGet<Resumen>(`/api/impuestos/iva-simple/resumen?empresa=${empresaId}&periodo=${periodo}`),enabled:/^\d{6}$/.test(periodo)});
 return <div className="space-y-5"><header><h2 className="font-semibold">IVA Simple</h2><input aria-label="Período IVA Simple" className="mt-2 rounded border px-3 py-2" value={periodo} onChange={e=>setPeriodo(e.target.value.replace(/\D/g,"").slice(0,6))}/></header>{q.error?<p className="text-sm text-destructive">{q.error instanceof Error?q.error.message:"No se pudo cargar"}</p>:null}{q.data?.avisos?.map(a=><p key={a} className="rounded border border-amber-200 bg-amber-50 p-3 text-sm">{a}</p>)}<div className="overflow-x-auto rounded border"><table className="w-full text-sm"><thead><tr className="bg-muted"><th className="p-2 text-left">Operación</th><th>Alícuota</th><th>Neto</th><th>IVA</th></tr></thead><tbody>{q.data?.alicuotas.map(a=><tr className="border-t" key={`${a.libro}-${a.codigo}`}><td className="p-2">{a.libro}</td><td className="text-right">{a.codigo}</td><td className="text-right">{formatMoney(a.netoCents)}</td><td className="pr-2 text-right">{formatMoney(a.ivaCents)}</td></tr>)}</tbody></table></div><section><h3 className="font-semibold">Certificados y saldos</h3><ul className="text-sm">{q.data?.certificados.map(c=><li key={c.tipo}>{c.tipo}: {formatMoney(c.importeCents)}</li>)}</ul></section><IvaAjustes empresaId={empresaId} periodo={periodo}/><LiquidacionScreen empresaId={empresaId} ivaSimple/><ExportarScreen empresaId={empresaId}/></div>;
}

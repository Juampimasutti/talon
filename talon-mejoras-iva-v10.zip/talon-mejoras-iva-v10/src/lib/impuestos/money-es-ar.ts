export function parseDecimalEsAr(value: string, campo: string): number {
  const raw=value.trim();
  let normalized:string;
  if (/^-?\d+(?:,\d{1,2})?$/.test(raw)) normalized=raw.replace(',', '.');
  else if (/^-?\d{1,3}(?:\.\d{3})+(?:,\d{1,2})$/.test(raw)) normalized=raw.replaceAll('.', '').replace(',', '.');
  else if (/^-?\d+\.\d{1,2}$/.test(raw)) normalized=raw;
  else throw new Error(`${campo}: ingresá un importe válido`);
  const amount=Number(normalized);
  if (!Number.isFinite(amount)) throw new Error(`${campo}: ingresá un importe válido`);
  return amount;
}
export function centsEsAr(value:string,campo:string):number { return Math.round(parseDecimalEsAr(value,campo)*100); }
export function formatEsAr(value:string,campo:string):string {return parseDecimalEsAr(value,campo).toLocaleString('es-AR',{minimumFractionDigits:2,maximumFractionDigits:2});}
export function periodoValido(value:string):boolean{return /^\d{4}(0[1-9]|1[0-2])$/.test(value)}

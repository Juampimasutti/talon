import { describe,expect,it } from "vitest";import { estadoPercepcionPendiente,sumarMeses,validarPeriodoComputo,validarPeriodoOrigen } from "./retenciones";
describe("cómputo de retenciones y percepciones",()=>{
 it("cruza diciembre y respeta los cinco períodos",()=>{expect(sumarMeses("202612",1)).toBe("202701");expect(validarPeriodoComputo("percepcion","202612","202705")).toBeNull();expect(validarPeriodoComputo("percepcion","202612","202706")).toContain("cinco");});
 it("retención sólo en origen",()=>{expect(validarPeriodoComputo("retencion","202609","202609")).toBeNull();expect(validarPeriodoComputo("retencion","202609","202610")).toContain("origen");});
});
describe("pendientes",()=>{it("valida fecha de origen y marca la ventana",()=>{expect(validarPeriodoOrigen("2026-09-10","202609")).toBeNull();expect(validarPeriodoOrigen("2026-10-10","202609")).toContain("coincidir");expect(estadoPercepcionPendiente("202609","202702","202702").venceEsteMes).toBe(true);});});

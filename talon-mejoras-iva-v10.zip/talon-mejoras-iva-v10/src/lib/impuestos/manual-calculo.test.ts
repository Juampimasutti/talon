import {expect,it} from 'vitest';import {calcularIva,totalManual} from './manual-calculo';
it('suma varias alícuotas y respeta el IVA editado',()=>{const filas=[{codigo:5,netoCents:10000,ivaCents:calcularIva(10000,5)},{codigo:4,netoCents:20000,ivaCents:2099}];expect(filas[0].ivaCents).toBe(2100);expect(totalManual(filas,100,200,300)).toBe(34799)});

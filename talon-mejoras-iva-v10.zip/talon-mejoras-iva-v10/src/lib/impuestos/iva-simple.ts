export type FilaIvaSimple = {
  libro: "ventas" | "compras";
  codigo: number;
  netoCents: number;
  ivaCents: number;
  signo: number;
  tipoCambio: number;
};

export function agregarIvaSimple(rows: FilaIvaSimple[]) {
  const groups = new Map<string, { libro: "ventas" | "compras"; codigo: number; netoCents: number; ivaCents: number }>();
  for (const row of rows) {
    const key = `${row.libro}:${row.codigo}`;
    const group = groups.get(key) ?? { libro: row.libro, codigo: row.codigo, netoCents: 0, ivaCents: 0 };
    group.netoCents += row.signo * Math.round(row.netoCents * row.tipoCambio);
    group.ivaCents += row.signo * Math.round(row.ivaCents * row.tipoCambio);
    groups.set(key, group);
  }
  return [...groups.values()].sort((a, b) => a.libro.localeCompare(b.libro) || a.codigo - b.codigo);
}

export function avisosTamanoExportacion(files: Array<{ name: string; bytes: number }>, zipBytes: number) {
  const avisos: string[] = [];
  for (const file of files) {
    if (file.bytes > 10_000_000 && file.bytes <= 70_000_000) avisos.push(`${file.name} supera 10 MB.`);
  }
  if (zipBytes > 10_000_000) avisos.push("El ZIP supera 10 MB.");
  return avisos;
}

export function bloqueoTamanoExportacion(files:Array<{name:string;bytes:number}>){const file=files.find(item=>item.bytes>70_000_000);return file?`${file.name} supera 70 MB.`:null;}

export function validarTamanoImportacion(bytes:number){return bytes>15_000_000?"El archivo supera 15 MB":null;}

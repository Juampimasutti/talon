import { COMPRAS_ALICUOTAS, COMPRAS_CBTE, COMPRAS_TURIVA_CBTE, IMPORTACION_BIENES_ALICUOTA, VENTAS_ALICUOTAS, VENTAS_CBTE, VENTAS_TURIVA_CBTE, codigoOperacion, discriminaIva, makeTxt, type AlicuotaRow, type LibroRow } from ".";

type Row = Record<string, unknown>;
const IMPORTACION = new Set([66, 67]);
const TURIVA_VENTAS = new Set([195,196,197]);
const TURIVA_COMPRAS = new Set([63,195,196,197]);
const BIENES_USADOS = new Set([30,32,49]);
const n = (v: unknown) => Number(v ?? 0);
const pesos = (value: unknown, cambio: number) => Math.round(n(value) * cambio);

/** Ajusta el campo 21 de Compras para que el LID refleje el destino fiscal elegido. */
export function aplicarDestinoCreditoExportacion(receipts:Row[],rates:Row[],coeficienteBps:number){const iva=new Map<unknown,number>();for(const a of rates)iva.set(a.comprobante_id,(iva.get(a.comprobante_id)??0)+n(a.iva_cents));return receipts.map(r=>{if(r.libro!=="compras")return r;const destino=String(r.destino_credito??"directo_gravado");if(destino==="directo_exento")return{...r,credito_fiscal_computable_cents:0};if(destino==="prorratea")return{...r,credito_fiscal_computable_cents:Math.round((iva.get(r.id)??0)*coeficienteBps/10000)};return r;});}

/**
 * Arma los 5 TXT del Libro IVA Digital a partir de imp_comprobantes / imp_comprobante_alicuotas.
 * Los despachos de importación (tipos 66/67) van en COMPRAS_CBTE con el despacho y sus
 * alícuotas en IMPORTACION_BIENES_ALICUOTA (no en COMPRAS_ALICUOTAS).
 */
export function buildLibroIvaDigital(receipts: Row[], rates: Row[]) {
  const avisos: string[] = [];
  const byReceipt = new Map<unknown, Row[]>();
  for (const rate of rates) byReceipt.set(rate.comprobante_id, [...(byReceipt.get(rate.comprobante_id) ?? []), rate]);
  const ventasCbte: LibroRow[] = []; const ventasAli: AlicuotaRow[] = [];
  const comprasCbte: LibroRow[] = []; const comprasAli: AlicuotaRow[] = []; const importAli: AlicuotaRow[] = [];
  const ventasTuriva:LibroRow[]=[];const comprasTuriva:LibroRow[]=[];
  const bienesUsadosCbte:LibroRow[]=[];const bienesUsadosAli:AlicuotaRow[]=[];
  for (const r of receipts) {
    const tipo = n(r.tipo_cbte); const compras = r.libro === "compras"; const importacion = compras && IMPORTACION.has(tipo);
    const cambio = n(r.tipo_cambio) || 1;
    const alis = (byReceipt.get(r.id) ?? []).map((a) => ({ codigo: n(a.alicuota_codigo), netoCents: pesos(a.neto_cents, cambio), ivaCents: pesos(a.iva_cents, cambio) }));
    // Compras B/C: cantidad de alícuotas 0 y sin registros de alícuotas (instructivo, campo 19).
    const informa = compras ? BIENES_USADOS.has(tipo) || discriminaIva(tipo) : true;
    const alicuotas = informa ? alis : [];
    const despacho = importacion ? String(r.despacho ?? "").trim() || null : null;
    if (importacion && !despacho) avisos.push(`Despacho ${r.punto_venta}-${r.numero_desde}: falta el número de despacho de importación`);
    const row: LibroRow = {
      fecha: String(r.fecha_cbte instanceof Date ? r.fecha_cbte.toISOString() : r.fecha_cbte), tipoCbte: tipo, puntoVenta: n(r.punto_venta),
      numeroDesde: String(r.numero_desde), numeroHasta: String(r.numero_hasta), despacho,
      docTipo: n(r.doc_tipo), docNro: String(r.doc_nro ?? ""), denominacion: String(r.denominacion ?? ""), totalCents: pesos(r.total_cents, cambio),
      noGravadoCents: pesos(r.neto_no_gravado_cents, cambio), exentoCents: pesos(r.exento_cents, cambio), percepIvaCents: pesos(r.percep_iva_cents, cambio),
      percepOtrosNacCents: pesos(r.percep_otros_nac_cents, cambio), percepIibbCents: pesos(r.percep_iibb_cents, cambio), percepMuniCents: pesos(r.percep_municipales_cents, cambio),
      internosCents: pesos(r.impuestos_internos_cents, cambio), otrosTributosCents: pesos(r.otros_tributos_cents, cambio),
      moneda: String(r.moneda ?? "PES"), tipoCambio: cambio, cantidadAlicuotas: alicuotas.length,
      codigoOperacion: informa ? codigoOperacion({ alicuotas, exentoCents: pesos(r.exento_cents, cambio), noGravadoCents: pesos(r.neto_no_gravado_cents, cambio), importacion }) : "0",
      creditoFiscalCents: pesos(r.credito_fiscal_computable_cents, cambio),
      fechaVencimientoPago: r.fecha_vencimiento_pago ? String(r.fecha_vencimiento_pago) : null,
      reintegroCents:pesos(r.reintegro_cents,cambio),
    };
    const ali = alicuotas.map((a) => ({ tipoCbte: tipo, puntoVenta: row.puntoVenta, numero: row.numeroDesde, docTipo: row.docTipo, docNro: row.docNro, despacho, ...a }));
    if(compras&&BIENES_USADOS.has(tipo)){bienesUsadosCbte.push(row);bienesUsadosAli.push(...ali);}
    // El PDF "Diseño de Registro" (págs. 3–4 y 6–7) define cabeceras TurIVA,
    // pero no un archivo de alícuotas propio: remite a VENTAS/COMPRAS_ALICUOTAS comunes.
    // TODO ARCA: confirmar este destino si una versión posterior publica un diseño TurIVA de alícuotas.
    else if((compras?TURIVA_COMPRAS:TURIVA_VENTAS).has(tipo)){(compras?comprasTuriva:ventasTuriva).push(row);(compras?comprasAli:ventasAli).push(...ali);}
    else if (compras) { comprasCbte.push(row); (importacion ? importAli : comprasAli).push(...ali); }
    else { ventasCbte.push(row); ventasAli.push(...ali); }
  }
  return {
    avisos,
    files: {
      LIBRO_IVA_DIGITAL_VENTAS_CBTE: makeTxt(ventasCbte, VENTAS_CBTE),
      LIBRO_IVA_DIGITAL_VENTAS_ALICUOTAS: makeTxt(ventasAli, VENTAS_ALICUOTAS),
      LIBRO_IVA_DIGITAL_COMPRAS_CBTE: makeTxt(comprasCbte, COMPRAS_CBTE),
      LIBRO_IVA_DIGITAL_COMPRAS_ALICUOTAS: makeTxt(comprasAli, COMPRAS_ALICUOTAS),
      LIBRO_IVA_DIGITAL_IMPORTACION_BIENES_ALICUOTA: makeTxt(importAli, IMPORTACION_BIENES_ALICUOTA),
      LIBRO_IVA_DIGITAL_VENTAS_TurIVA_CBTE:makeTxt(ventasTuriva,VENTAS_TURIVA_CBTE),
      LIBRO_IVA_DIGITAL_COMPRAS_TurIVA_CBTE:makeTxt(comprasTuriva,COMPRAS_TURIVA_CBTE),
      LIBRO_IVA_DIGITAL_COMPRAS_BIENES_USADOS_CBTE:makeTxt(bienesUsadosCbte,COMPRAS_CBTE),
      LIBRO_IVA_DIGITAL_COMPRAS_BIENES_USADOS_ALICUOTAS:makeTxt(bienesUsadosAli,COMPRAS_ALICUOTAS),
    },
  };
}

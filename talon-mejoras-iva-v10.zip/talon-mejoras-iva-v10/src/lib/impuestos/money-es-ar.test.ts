import {describe,it,expect} from 'vitest';
import {parseDecimalEsAr,centsEsAr,periodoValido} from './money-es-ar';
describe('importes es-AR',()=>{
 it('admite coma, miles y decimal con punto',()=>{expect(centsEsAr('1234,56','Neto')).toBe(123456);expect(centsEsAr('1.234,56','Neto')).toBe(123456);expect(centsEsAr('1234.56','Neto')).toBe(123456)});
 it('rechaza ambiguos y nombra el campo',()=>{expect(()=>parseDecimalEsAr('1.234','Neto')).toThrow('Neto');expect(()=>parseDecimalEsAr('abc','IVA')).toThrow('IVA')});
 it('valida meses',()=>{expect(periodoValido('202612')).toBe(true);expect(periodoValido('202613')).toBe(false)});
});

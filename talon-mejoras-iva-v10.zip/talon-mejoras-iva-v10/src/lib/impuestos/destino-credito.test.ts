import{describe,expect,it}from"vitest";import{aplicarProrrateo,coeficienteProrrateo}from"./calculos";
describe("destino del crédito",()=>{it("prorratea una compra importada por el coeficiente de ventas",()=>{const coef=coeficienteProrrateo(300000,100000,0);expect(coef).toBe(7500);expect(aplicarProrrateo(2100000,coef)).toBe(1575000);});});

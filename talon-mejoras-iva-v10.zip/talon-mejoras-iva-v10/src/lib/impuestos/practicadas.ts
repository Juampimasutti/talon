export function validarImportePracticado(baseCents:number,alicuotaBps:number,importeCents:number,toleranciaCents=5){
  const esperado=Math.round(baseCents*alicuotaBps/10000);
  return Math.abs(esperado-importeCents)<=toleranciaCents?null:`El importe no coincide con base × alícuota (esperado ${esperado})`;
}

const csvMoney=(value:unknown)=>(Number(value??0)/100).toFixed(2).replace(".",",");
const csvCell=(value:unknown)=>`"${String(value??"").replaceAll('"','""')}"`;

export function csvPracticadas(rows:Record<string,unknown>[]){
  const header="tipo;sujeto_cuit;sujeto;regimen;base;alicuota_bps;importe;fecha;certificado;formulario";
  const lines=rows.map(r=>[
    r.tipo,r.sujetoCuit,r.sujetoDenominacion,r.regimen,csvMoney(r.baseCents),r.alicuotaBps,csvMoney(r.importeCents),String(r.fecha??"").slice(0,10),r.numeroCertificado,r.formulario,
  ].map(csvCell).join(";"));
  return `\uFEFF${header}\r\n${lines.join("\r\n")}${lines.length?"\r\n":""}`;
}

export type Vencimiento = { obligacion:string;periodo:string;terminacionDesde:number;terminacionHasta:number;fecha:string;fuenteUrl:string };
export function proximoVencimiento(cuit:string,obligacion:string,periodo:string,rows:Vencimiento[]){
  const digits=cuit.replace(/\D/g,"");if(digits.length!==11)return null;const end=Number(digits.at(-1));
  return rows.find(r=>r.obligacion===obligacion&&r.periodo===periodo&&end>=r.terminacionDesde&&end<=r.terminacionHasta)??null;
}

export function vencidoSinConfirmar(fecha:string,estado:"abierto"|"cerrado"|null,hoy:string){
  return fecha<hoy&&estado!=="cerrado";
}
export function fechaHoyBuenosAires(now=new Date()){const parts=new Intl.DateTimeFormat("en-US",{timeZone:"America/Argentina/Buenos_Aires",year:"numeric",month:"2-digit",day:"2-digit"}).formatToParts(now);const get=(type:string)=>parts.find(x=>x.type===type)?.value??"";return `${get("year")}-${get("month")}-${get("day")}`;}
export function ordenarEmpresasPorVencimiento<T extends {nombre:string;proximaFecha?:string|null;estadoPeriodo?:string|null}>(rows:T[],hoy:string){return [...rows].sort((a,b)=>{const fa=a.proximaFecha?String(a.proximaFecha).slice(0,10):null,fb=b.proximaFecha?String(b.proximaFecha).slice(0,10):null;const estadoA=a.estadoPeriodo as "abierto"|"cerrado"|null,estadoB=b.estadoPeriodo as "abierto"|"cerrado"|null;const pa=fa&&vencidoSinConfirmar(fa,estadoA,hoy)?0:fa&&estadoA!=="cerrado"?1:fa?2:3;const pb=fb&&vencidoSinConfirmar(fb,estadoB,hoy)?0:fb&&estadoB!=="cerrado"?1:fb?2:3;return pa-pb||(fa??"9999").localeCompare(fb??"9999")||a.nombre.localeCompare(b.nombre,"es");});}

export type VencimientoEstado=Vencimiento&{estado:"abierto"|"cerrado"|null};
export function obligacionParaCondicion(condicion:string,flujo?:string){
  if(condicion==="exento")return "lid_exento";
  if(condicion!=="ri")return null;
  return flujo==="f2002_lid"?"f2002":"iva_simple";
}
export function seleccionarVencimiento(rows:VencimientoEstado[],condicion:string,hoy:string,flujo?:string){
  const obligacion=obligacionParaCondicion(condicion,flujo);if(!obligacion)return null;
  const candidates=rows.filter(r=>r.obligacion===obligacion).sort((a,b)=>a.fecha.localeCompare(b.fecha));
  return candidates.find(r=>r.fecha<hoy&&r.estado!=="cerrado")??candidates.find(r=>r.fecha>=hoy)??null;
}

import { describe, expect, it } from "vitest";
import { parsePeriodo } from "./periodo";

describe("parsePeriodo",()=>{
  it.each(["202613","abc",null])("rechaza %s con 400",value=>{
    const url=new URL("http://talon.test/api"+(value===null?"":`?periodo=${value}`));
    expect(()=>parsePeriodo(url)).toThrowError(expect.objectContaining({status:400,message:"Período inválido"}));
  });
  it("acepta límites válidos",()=>{
    expect(parsePeriodo(new URL("http://talon.test/api?periodo=200001"))).toBe("200001");
    expect(parsePeriodo(new URL("http://talon.test/api?periodo=210012"))).toBe("210012");
  });
});

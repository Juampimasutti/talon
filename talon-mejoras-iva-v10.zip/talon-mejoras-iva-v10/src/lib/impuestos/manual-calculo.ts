export const ALICUOTAS = [{codigo:5,bps:2100,label:'21%'},{codigo:4,bps:1050,label:'10,5%'},{codigo:6,bps:2700,label:'27%'},{codigo:8,bps:500,label:'5%'},{codigo:9,bps:250,label:'2,5%'},{codigo:3,bps:0,label:'0%'}] as const;
export type FilaManual={codigo:number;netoCents:number;ivaCents:number};
export function calcularIva(netoCents:number,codigo:number):number {const tasa=ALICUOTAS.find(a=>a.codigo===codigo);if(!tasa)throw new Error('Alícuota inválida');return Math.round(netoCents*tasa.bps/10000)}
export function totalManual(filas:FilaManual[],noGravadoCents:number,exentoCents:number,tributosCents:number):number{return filas.reduce((sum,f)=>sum+f.netoCents+f.ivaCents,0)+noGravadoCents+exentoCents+tributosCents}

import { describe, expect, it } from "vitest";
import { withErrors } from "./http";

describe("errores 22023 de PostgreSQL",()=>{
  it("devuelve 409 cuando el período no está cerrado",async()=>{const response=await withErrors(async()=>{throw new Error("Falló la consulta",{cause:Object.assign(new Error("El período no está cerrado"),{code:"22023"})});});expect(response.status).toBe(409);expect((await response.json()).error).toBe("El período no está cerrado");});
  it("devuelve 400 para otros parámetros rechazados por las migraciones",async()=>{const response=await withErrors(async()=>{throw new Error("Falló la consulta",{cause:Object.assign(new Error("Tipo de respaldo inválido"),{code:"22023"})});});expect(response.status).toBe(400);expect((await response.json()).error).toBe("Tipo de respaldo inválido");});
});

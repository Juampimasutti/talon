CREATE TABLE imp_iva_ajustes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), company_id uuid NOT NULL REFERENCES companies(id), empresa_cliente_id uuid NOT NULL,
  periodo char(6) NOT NULL, lado text NOT NULL CHECK(lado IN ('debito','credito')), clase text NOT NULL CHECK(clase IN ('genera','restituye')),
  actividad char(6), concepto smallint, tipo_operacion smallint, tipo_sujeto smallint, alicuota_codigo smallint,
  neto_cents bigint NOT NULL DEFAULT 0, impuesto_facturado_cents bigint NOT NULL DEFAULT 0, impuesto_computable_cents bigint NOT NULL DEFAULT 0,
  exento_cents bigint NOT NULL DEFAULT 0, estado text NOT NULL DEFAULT 'vigente' CHECK(estado IN ('vigente','anulado')),
  created_by uuid REFERENCES users(id), created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY(company_id,empresa_cliente_id) REFERENCES imp_empresas(company_id,id)
);
CREATE INDEX imp_iva_ajustes_periodo_idx ON imp_iva_ajustes(company_id,empresa_cliente_id,periodo) WHERE estado='vigente';
ALTER TABLE imp_iva_ajustes ENABLE ROW LEVEL SECURITY; ALTER TABLE imp_iva_ajustes FORCE ROW LEVEL SECURITY;
CREATE POLICY imp_iva_ajustes_select ON imp_iva_ajustes FOR SELECT USING(company_id=app_company_id() AND app_has_permission('impuestos.ver'));
CREATE POLICY imp_iva_ajustes_insert ON imp_iva_ajustes FOR INSERT WITH CHECK(company_id=app_company_id() AND app_has_permission('impuestos.crear'));
CREATE POLICY imp_iva_ajustes_update ON imp_iva_ajustes FOR UPDATE USING(company_id=app_company_id() AND (app_has_permission('impuestos.editar') OR app_has_permission('impuestos.anular')));
CREATE POLICY imp_iva_ajustes_scope ON imp_iva_ajustes AS RESTRICTIVE FOR ALL USING(empresa_cliente_id=app_imp_empresa_id()) WITH CHECK(empresa_cliente_id=app_imp_empresa_id());
GRANT SELECT,INSERT,UPDATE ON imp_iva_ajustes TO talon_app;

CREATE OR REPLACE FUNCTION imp_ajuste_periodo_guard() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN
 IF EXISTS(SELECT 1 FROM imp_periodos WHERE company_id=OLD.company_id AND empresa_cliente_id=OLD.empresa_cliente_id AND periodo IN(OLD.periodo,NEW.periodo) AND estado='cerrado') THEN RAISE EXCEPTION 'No se puede modificar un ajuste de un período confirmado' USING ERRCODE='55000'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER imp_ajuste_periodo_guard_trigger BEFORE UPDATE OR DELETE ON imp_iva_ajustes FOR EACH ROW EXECUTE FUNCTION imp_ajuste_periodo_guard();

CREATE TABLE imp_importacion_servicios (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),company_id uuid NOT NULL REFERENCES companies(id),empresa_cliente_id uuid NOT NULL,periodo char(6) NOT NULL,
 tipo_cbte smallint NOT NULL,descripcion varchar(20),identificacion varchar(20) NOT NULL,fecha date NOT NULL,monto_original_cents bigint NOT NULL,moneda char(3) NOT NULL,tipo_cambio numeric(10,6) NOT NULL,
 prestador_cuit char(11) NOT NULL,prestador_nif varchar(20) NOT NULL,prestador_nombre varchar(30) NOT NULL,alicuota_bps smallint NOT NULL,fecha_ingreso date NOT NULL,
 impuesto_ingresado_cents bigint NOT NULL,impuesto_computable_cents bigint NOT NULL,pago_identificacion varchar(20) NOT NULL,entidad_pago_cuit char(11) NOT NULL,
 estado text NOT NULL DEFAULT 'vigente',created_by uuid REFERENCES users(id),created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(company_id,empresa_cliente_id) REFERENCES imp_empresas(company_id,id)
);
ALTER TABLE imp_importacion_servicios ENABLE ROW LEVEL SECURITY; ALTER TABLE imp_importacion_servicios FORCE ROW LEVEL SECURITY;
CREATE POLICY imp_servicios_select ON imp_importacion_servicios FOR SELECT USING(company_id=app_company_id() AND app_has_permission('impuestos.ver'));
CREATE POLICY imp_servicios_insert ON imp_importacion_servicios FOR INSERT WITH CHECK(company_id=app_company_id() AND app_has_permission('impuestos.crear'));
CREATE POLICY imp_servicios_update ON imp_importacion_servicios FOR UPDATE USING(company_id=app_company_id() AND app_has_permission('impuestos.editar'));
CREATE POLICY imp_servicios_scope ON imp_importacion_servicios AS RESTRICTIVE FOR ALL USING(empresa_cliente_id=app_imp_empresa_id()) WITH CHECK(empresa_cliente_id=app_imp_empresa_id());
GRANT SELECT,INSERT,UPDATE ON imp_importacion_servicios TO talon_app;

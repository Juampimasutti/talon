-- Ajustes IVA Simple: el débito por dación en pago es un concepto independiente.
ALTER TABLE imp_iva_ajustes ADD COLUMN dacion_pago_cents bigint NOT NULL DEFAULT 0;

-- V1: el historial distingue una importación confirmada de una deshecha.
ALTER TABLE imp_import_jobs DROP CONSTRAINT IF EXISTS imp_import_jobs_estado_check;
ALTER TABLE imp_import_jobs ADD CONSTRAINT imp_import_jobs_estado_check
  CHECK (estado IN ('procesando','previsualizado','confirmado','error','deshecho'));

-- V8: editar o anular lógicamente importaciones de servicios.
DROP POLICY IF EXISTS imp_servicios_update ON imp_importacion_servicios;
CREATE POLICY imp_servicios_update ON imp_importacion_servicios FOR UPDATE
 USING(company_id=app_company_id() AND (app_has_permission('impuestos.editar') OR app_has_permission('impuestos.anular')));

ALTER TABLE imp_importacion_servicios
  ADD COLUMN updated_at timestamptz NOT NULL DEFAULT now();

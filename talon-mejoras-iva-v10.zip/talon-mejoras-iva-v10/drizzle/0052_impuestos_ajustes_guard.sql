-- V5: la guardia contempla INSERT, UPDATE y DELETE sin desreferenciar OLD/NEW.
CREATE OR REPLACE FUNCTION imp_ajuste_periodo_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  cid uuid := coalesce(NEW.company_id, OLD.company_id);
  eid uuid := coalesce(NEW.empresa_cliente_id, OLD.empresa_cliente_id);
BEGIN
  IF EXISTS(
    SELECT 1 FROM imp_periodos
    WHERE company_id=cid AND empresa_cliente_id=eid
      AND periodo IN (coalesce(OLD.periodo, NEW.periodo), coalesce(NEW.periodo, OLD.periodo))
      AND estado='cerrado'
  ) THEN
    RAISE EXCEPTION 'No se puede modificar un ajuste de un período confirmado' USING ERRCODE='55000';
  END IF;
  RETURN coalesce(NEW, OLD);
END $$;

DROP TRIGGER IF EXISTS imp_ajuste_periodo_guard_trigger ON imp_iva_ajustes;
CREATE TRIGGER imp_ajuste_periodo_guard_trigger
  BEFORE INSERT OR UPDATE OR DELETE ON imp_iva_ajustes
  FOR EACH ROW EXECUTE FUNCTION imp_ajuste_periodo_guard();

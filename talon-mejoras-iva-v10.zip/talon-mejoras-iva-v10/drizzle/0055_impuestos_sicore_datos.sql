-- W4: datos propios de SICORE; formulario 0 identifica registros exclusivos de ese exportador.
ALTER TABLE imp_retenciones_practicadas DROP CONSTRAINT IF EXISTS imp_retenciones_practicadas_formulario_check;
ALTER TABLE imp_retenciones_practicadas ADD CONSTRAINT imp_retenciones_practicadas_formulario_check CHECK(formulario IN (0,2003,2004,2005));
ALTER TABLE imp_retenciones_practicadas
  ADD COLUMN sicore_impuesto smallint,
  ADD COLUMN sicore_operacion smallint,
  ADD COLUMN sicore_condicion smallint,
  ADD COLUMN sicore_tipo_documento smallint,
  ADD COLUMN certificado_original varchar(14);

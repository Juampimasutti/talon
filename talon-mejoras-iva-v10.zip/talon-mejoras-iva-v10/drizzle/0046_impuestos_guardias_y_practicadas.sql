CREATE OR REPLACE FUNCTION imp_retencion_periodo_guard() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM imp_periodos
    WHERE company_id=OLD.company_id AND empresa_cliente_id=OLD.empresa_cliente_id
      AND periodo IN (OLD.periodo_computo, NEW.periodo_computo) AND estado='cerrado'
  ) THEN
    RAISE EXCEPTION 'No se puede modificar un certificado de un período confirmado' USING ERRCODE='55000';
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS imp_retencion_periodo_guard_trigger ON imp_retenciones_percepciones;
CREATE TRIGGER imp_retencion_periodo_guard_trigger BEFORE UPDATE OR DELETE ON imp_retenciones_percepciones
FOR EACH ROW EXECUTE FUNCTION imp_retencion_periodo_guard();

DROP POLICY IF EXISTS imp_practicadas_update ON imp_retenciones_practicadas;
CREATE POLICY imp_practicadas_update ON imp_retenciones_practicadas FOR UPDATE
USING(company_id=app_company_id() AND (app_has_permission('impuestos.editar') OR app_has_permission('impuestos.anular')))
WITH CHECK(company_id=app_company_id() AND (app_has_permission('impuestos.editar') OR app_has_permission('impuestos.anular')));
GRANT DELETE ON imp_retenciones_practicadas TO talon_app;

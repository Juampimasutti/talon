-- V4: guardia de período para altas, cambios y borrados de importaciones de servicios.
CREATE OR REPLACE FUNCTION imp_servicio_periodo_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE cid uuid:=coalesce(NEW.company_id,OLD.company_id);eid uuid:=coalesce(NEW.empresa_cliente_id,OLD.empresa_cliente_id);
BEGIN
 IF EXISTS(SELECT 1 FROM imp_periodos WHERE company_id=cid AND empresa_cliente_id=eid
   AND periodo IN (coalesce(OLD.periodo,NEW.periodo),coalesce(NEW.periodo,OLD.periodo)) AND estado='cerrado')
 THEN RAISE EXCEPTION 'No se puede modificar una importación de servicios de un período confirmado' USING ERRCODE='55000'; END IF;
 RETURN coalesce(NEW,OLD);
END $$;
DROP TRIGGER IF EXISTS imp_servicio_periodo_guard_trigger ON imp_importacion_servicios;
CREATE TRIGGER imp_servicio_periodo_guard_trigger BEFORE INSERT OR UPDATE OR DELETE ON imp_importacion_servicios FOR EACH ROW EXECUTE FUNCTION imp_servicio_periodo_guard();

DROP POLICY IF EXISTS imp_servicios_delete ON imp_importacion_servicios;
CREATE POLICY imp_servicios_delete ON imp_importacion_servicios FOR DELETE
 USING(company_id=app_company_id() AND app_has_permission('impuestos.anular'));
GRANT DELETE ON imp_importacion_servicios TO talon_app;

-- IVA v4 A/B: conservar historial anulado y proteger ambos períodos de certificados.
ALTER TABLE imp_comprobantes DROP CONSTRAINT IF EXISTS imp_comprobantes_empresa_identity;
DROP INDEX IF EXISTS imp_comprobantes_empresa_identity;
CREATE UNIQUE INDEX imp_comprobantes_empresa_identity
  ON imp_comprobantes(company_id,empresa_cliente_id,libro,doc_nro_emisor,tipo_cbte,punto_venta,numero_desde)
  WHERE estado='vigente';

CREATE OR REPLACE FUNCTION imp_retencion_periodo_guard() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM imp_periodos
    WHERE company_id=OLD.company_id AND empresa_cliente_id=OLD.empresa_cliente_id
      AND periodo IN (OLD.periodo_computo, CASE WHEN TG_OP='DELETE' THEN OLD.periodo_computo ELSE NEW.periodo_computo END)
      AND estado='cerrado'
  ) THEN
    RAISE EXCEPTION 'No se puede modificar un certificado de un período confirmado' USING ERRCODE='55000';
  END IF;
  RETURN COALESCE(NEW,OLD);
END $$;

CREATE OR REPLACE FUNCTION imp_practicada_periodo_guard() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM imp_periodos
    WHERE company_id=OLD.company_id AND empresa_cliente_id=OLD.empresa_cliente_id
      AND periodo IN (to_char(OLD.fecha,'YYYYMM'), CASE WHEN TG_OP='DELETE' THEN to_char(OLD.fecha,'YYYYMM') ELSE to_char(NEW.fecha,'YYYYMM') END)
      AND estado='cerrado'
  ) THEN
    RAISE EXCEPTION 'No se puede modificar una retención practicada de un período confirmado' USING ERRCODE='55000';
  END IF;
  RETURN COALESCE(NEW,OLD);
END $$;

DROP TRIGGER IF EXISTS imp_practicada_periodo_guard_trigger ON imp_retenciones_practicadas;
CREATE TRIGGER imp_practicada_periodo_guard_trigger BEFORE UPDATE OR DELETE ON imp_retenciones_practicadas
FOR EACH ROW EXECUTE FUNCTION imp_practicada_periodo_guard();

-- Datos específicos necesarios para exportar SIRE F.2003, F.2004 y F.2005.
ALTER TABLE imp_retenciones_practicadas
  ADD COLUMN formulario smallint NOT NULL DEFAULT 2005 CHECK(formulario IN (2003,2004,2005)),
  ADD COLUMN tipo_comprobante smallint NOT NULL DEFAULT 9,
  ADD COLUMN fecha_comprobante date,
  ADD COLUMN numero_comprobante varchar(16),
  ADD COLUMN importe_comprobante_cents bigint,
  ADD COLUMN ordenante_cuit char(11),
  ADD COLUMN aplica_cdi boolean NOT NULL DEFAULT false,
  ADD COLUMN codigo_alicuota smallint,
  ADD COLUMN aplica_acrecentamiento boolean NOT NULL DEFAULT false,
  ADD COLUMN retenido_nif varchar(50),
  ADD COLUMN retenido_domicilio varchar(60),
  ADD COLUMN retenido_pais smallint,
  ADD COLUMN retenido_tipo_persona char(1) CHECK(retenido_tipo_persona IN ('F','J')),
  ADD COLUMN nacimiento_pais smallint,
  ADD COLUMN nacimiento_fecha date;

UPDATE imp_retenciones_practicadas
SET fecha_comprobante=fecha,numero_comprobante=numero_certificado,importe_comprobante_cents=base_cents
WHERE fecha_comprobante IS NULL;

import { LibroImpresion } from "@/components/impuestos/impresion-impuestos";
export default async function Page({params,searchParams}:{params:Promise<{libro:string;periodo:string}>;searchParams:Promise<{empresa?:string}>}){const {libro,periodo}=await params;const {empresa}=await searchParams;return <LibroImpresion libro={libro} periodo={periodo} empresa={empresa}/>;}

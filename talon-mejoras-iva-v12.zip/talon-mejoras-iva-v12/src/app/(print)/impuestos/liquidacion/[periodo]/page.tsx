import { LiquidacionImpresion } from "@/components/impuestos/impresion-impuestos";
export default async function Page({params,searchParams}:{params:Promise<{periodo:string}>;searchParams:Promise<{empresa?:string}>}){const {periodo}=await params;const {empresa}=await searchParams;return <LiquidacionImpresion periodo={periodo} empresa={empresa}/>;}

import { sql } from "drizzle-orm";
import { z } from "zod";
import { can } from "@/lib/auth/permissions";
import { requirePermission } from "@/lib/auth/session";
import { ImportValidationError } from "@/lib/impuestos/mis-comprobantes";
import { withTenant } from "@/lib/db/tenant";
import type { Tx } from "@/lib/db/tenant";
import type { AuthContext } from "@/lib/auth/session";
import { HttpError, ok } from "@/lib/http";
import { cuitDigits, formatCuit, isValidCuit } from "@/lib/fiscal/cuit";
import { writeAudit } from "@/lib/domain/audit";
import { readBody, readBodyWithEmptyMessage } from "@/lib/validation";
import { aplicarProrrateo, calcularLiquidacion, coeficienteProrrateo, coeficienteProrrateoVentas, convertirCentsAPesos, itemsLiquidacion, periodoAnterior, saldosQueArrastra } from "@/lib/impuestos/calculos";
import { importarMisComprobantes } from "@/lib/impuestos/importar";
import { traerDeTalon } from "@/lib/impuestos/traer-de-talon";
import { toAnsi } from "@/lib/impuestos/libro-iva-digital";
import { aplicarDestinoCreditoExportacion, buildLibroIvaDigital } from "@/lib/impuestos/libro-iva-digital/build";
import { makeZip } from "@/lib/impuestos/libro-iva-digital/zip";
import * as XLSX from "xlsx";
import { esErrorPeriodoCerrado, mensajePeriodoCerrado, parsePeriodo, periodoSchema, reglaFechaImportada } from "@/lib/impuestos/periodo";
import { condicionIvaSchema, puedeLiquidarF2002 } from "@/lib/impuestos/condicion-iva";
import { estadoPercepcionPendiente, validarPeriodoComputo, validarPeriodoOrigen } from "@/lib/impuestos/retenciones";
import { validarComprobanteManual } from "@/lib/impuestos/comprobante-manual";
import { avisoEsquema, esquemaParaPeriodo } from "@/lib/impuestos/esquema";
import { avisosTamanoExportacion, bloqueoTamanoExportacion, validarTamanoImportacion } from "@/lib/impuestos/iva-simple";
import { csvPracticadas, validarImportePracticado } from "@/lib/impuestos/practicadas";
import { sire2003, sire2004, sire2005, sireTxt } from "@/lib/impuestos/sire";
import { SICORE_CODES_WARNING, sicoreTxt, validarCodigosSicore } from "@/lib/impuestos/sicore";
import { csvAjustes, validarAjuste, type Ajuste } from "@/lib/impuestos/iva-simple-ajustes";
import { archivoImportacionServicios, type ImportacionServicio } from "@/lib/impuestos/importacion-servicios";

const period=periodoSchema;
const importSchema=z.object({fileName:z.string().min(1).max(200),base64:z.string().min(1),periodo:period,crearEnTalon:z.boolean().default(false)});
const cents=z.number().int().min(0).max(1e15);
// Saldos anteriores: si vienen vacíos se toman de la liquidación confirmada del período anterior.
const confirmSchema=z.object({periodo:period,seguridadSocialCents:cents.default(0),saldoTecnicoAnteriorCents:cents.nullish(),saldoLibreAnteriorCents:cents.nullish(),retencionesCents:cents.default(0),percepcionesCents:cents.default(0),pagosCuentaCents:cents.default(0),confirmar:z.boolean().default(false)});
const PERIODO_CONFIRMADO="El período ya está confirmado. Para recalcularlo, primero reabrilo indicando el motivo.";
const fmtPeriodo=(p:string)=>`${p.slice(4)}/${p.slice(0,4)}`;
const reopenSchema=z.object({periodo:period,motivo:z.string().trim().min(5).max(1000)});
const empresaSchema=z.object({
  nombre:z.string().trim().min(1).max(120),
  razonSocial:z.string().trim().min(1).max(160),
  cuit:z.string().trim().refine(isValidCuit,"CUIT inválido"),
  condicionIva:condicionIvaSchema,
  rubro:z.string().trim().max(120).nullish(),
});
const empresaConfigSchema=z.object({
  toleranciaCents:z.number().int().min(0).max(10000),
  crearEnTalonDefault:z.boolean(),
  esquemaIva:z.enum(["iva_simple","f2002_lid"]).default("iva_simple"),
  ivaSimpleDesde:periodoSchema.nullable().default("202511"),
  coeficienteProrrateoBps:z.number().int().min(0).max(10000).nullable().default(null),
  puntosVenta:z.array(z.number().int().min(1).max(99999)).max(100).refine(v=>new Set(v).size===v.length,"Hay puntos de venta repetidos"),
  actividades:z.array(z.object({codigo:z.string().trim().min(1).max(30),descripcion:z.string().trim().min(1).max(160),principal:z.boolean()})).max(100)
    .refine(v=>new Set(v.map(a=>a.codigo)).size===v.length,"Hay códigos de actividad repetidos")
    .refine(v=>v.filter(a=>a.principal).length<=1,"Sólo puede haber una actividad principal"),
});
const rpSchema=z.object({tipo:z.enum(["retencion","percepcion"]),regimen:z.string().trim().min(1).max(40),agenteCuit:z.string().trim().refine(isValidCuit,"CUIT inválido"),agenteDenominacion:z.string().trim().min(1).max(160),fecha:z.string().date(),numeroCertificado:z.string().trim().min(1).max(80),importeCents:z.number().int().positive(),periodoOrigen:periodoSchema,periodoComputo:periodoSchema,comprobanteId:z.string().uuid().nullable().default(null)});
const manualSchema=z.object({libro:z.enum(["ventas","compras"]),fecha:z.string().date(),periodo:periodoSchema,tipoCbte:z.number().int(),puntoVenta:z.number().int().min(0).max(99999),numero:z.string().regex(/^\d+$/),docTipo:z.number().int(),docNro:z.string().trim().min(1).max(20),denominacion:z.string().trim().min(1).max(160),moneda:z.string().trim().length(3).default("PES"),tipoCambio:z.number().positive().default(1),noGravadoCents:cents.default(0),exentoCents:cents.default(0),tributosCents:cents.default(0),totalCents:z.number().int(),creditoFiscalCents:cents.default(0),destinoCredito:z.enum(["directo_gravado","directo_exento","prorratea"]).default("directo_gravado"),alicuotas:z.array(z.object({codigo:z.number().int(),netoCents:z.number().int(),ivaCents:z.number().int()})).max(10)});
const practicadaSchema=z.object({tipo:z.enum(["retencion","percepcion"]),sujetoCuit:z.string().refine(isValidCuit,"CUIT inválido"),sujetoDenominacion:z.string().trim().min(1).max(160),regimen:z.string().trim().min(1).max(40),baseCents:cents,alicuotaBps:z.number().int().min(0).max(100000),importeCents:cents,fecha:z.string().date(),comprobanteId:z.string().uuid().nullable().default(null),numeroCertificado:z.string().trim().min(1).max(80),formulario:z.union([z.literal(0),z.literal(2003),z.literal(2004),z.literal(2005)]).default(2005),tipoComprobante:z.number().int().min(0).max(99).default(9),fechaComprobante:z.string().date().optional(),numeroComprobante:z.string().trim().max(16).optional(),importeComprobanteCents:cents.optional(),ordenanteCuit:z.string().refine(isValidCuit,"CUIT ordenante inválido").optional(),aplicaCdi:z.boolean().default(false),codigoAlicuota:z.number().int().min(0).max(9999).optional(),aplicaAcrecentamiento:z.boolean().default(false),retenidoNif:z.string().trim().max(50).optional(),retenidoDomicilio:z.string().trim().max(60).optional(),retenidoPais:z.number().int().min(0).max(999).optional(),retenidoTipoPersona:z.enum(["F","J"]).optional(),nacimientoPais:z.number().int().min(0).max(999).optional(),nacimientoFecha:z.string().date().optional(),sicoreImpuesto:z.number().int().min(1).max(9999).optional(),sicoreOperacion:z.number().int().min(1).max(9).optional(),sicoreCondicion:z.number().int().min(0).max(99).optional(),sicoreTipoDocumento:z.number().int().min(0).max(99).optional(),certificadoOriginal:z.string().regex(/^\d{1,14}$/).optional()}).superRefine((x,ctx)=>{if(x.formulario===0){for(const key of ["sicoreImpuesto","sicoreOperacion","sicoreCondicion","sicoreTipoDocumento","certificadoOriginal"] as const)if(x[key]==null)ctx.addIssue({code:z.ZodIssueCode.custom,path:[key],message:"Dato obligatorio para SICORE"});}});
const ajusteSchema=z.object({periodo:period,lado:z.enum(["debito","credito"]),clase:z.enum(["genera","restituye"]),actividad:z.string().regex(/^\d{6}$/).nullish(),concepto:z.number().int().min(1).max(4).nullish(),tipoOperacion:z.number().int().min(1).max(3).nullish(),tipoSujeto:z.number().int().min(1).max(3).nullish(),alicuotaCodigo:z.number().int().nullish(),netoCents:z.number().int().optional(),impuestoFacturadoCents:z.number().int().optional(),impuestoComputableCents:z.number().int().optional(),dacionPagoCents:z.number().int().default(0),exentoCents:z.number().int().optional()}).superRefine((value,ctx)=>{const exento=value.lado==="debito"&&value.tipoOperacion===(value.clase==="genera"?3:2);for(const campo of (["netoCents","impuestoFacturadoCents"] as const)){if(!exento&&value[campo]===undefined)ctx.addIssue({code:z.ZodIssueCode.custom,path:[campo],message:`${campo} obligatorio`});}if(exento&&value.exentoCents===undefined)ctx.addIssue({code:z.ZodIssueCode.custom,path:["exentoCents"],message:"exentoCents obligatorio"});if(value.lado==="credito"&&value.clase==="genera"&&value.impuestoComputableCents===undefined)ctx.addIssue({code:z.ZodIssueCode.custom,path:["impuestoComputableCents"],message:"impuestoComputableCents obligatorio"});}).transform(value=>({...value,netoCents:value.netoCents??0,impuestoFacturadoCents:value.impuestoFacturadoCents??0,impuestoComputableCents:value.impuestoComputableCents??0,exentoCents:value.exentoCents??0}));
const servicioSchema=z.object({periodo:period,tipoCbte:z.number().int().min(1).max(3),descripcion:z.string().trim().max(20).nullish(),identificacion:z.string().trim().min(1).max(20),fecha:z.string().date(),montoOriginalCents:z.number().int().positive(),moneda:z.string().length(3),tipoCambio:z.number().positive(),prestadorCuit:z.string().refine(isValidCuit,"CUIT inválido"),prestadorNif:z.string().trim().min(1).max(20),prestadorNombre:z.string().trim().min(1).max(30),alicuotaBps:z.union([z.literal(1050),z.literal(2100)]),fechaIngreso:z.string().date(),impuestoIngresadoCents:z.number().int().positive(),impuestoComputableCents:z.number().int().nonnegative(),pagoIdentificacion:z.string().trim().min(1).max(20),entidadPagoCuit:z.string().refine(isValidCuit,"CUIT inválido")}).refine(x=>x.tipoCbte!==3||Boolean(x.descripcion),"Falta descripción para tipo Otros");

type EmpresaFiscal={id:string;nombre:string;razonSocial:string;cuit:string;condicionIva:string;rubro:string|null;activa:boolean};

async function flujoFiscal(tx:Tx,empresa:EmpresaFiscal,periodo:string){
  const [config]=await tx.execute<{esquemaIva:"iva_simple"|"f2002_lid";ivaSimpleDesde:string|null}>(sql`select esquema_iva "esquemaIva",iva_simple_desde "ivaSimpleDesde" from imp_config limit 1`);
  const flujo=esquemaParaPeriodo(config??{},periodo,empresa.condicionIva);
  if(flujo==="no_corresponde")throw new HttpError(409,"La liquidación de IVA no corresponde a la condición fiscal de la empresa");
  return {flujo,aviso:avisoEsquema(periodo,flujo)};
}

async function withImpuestos<T>(auth:AuthContext,url:URL,fn:(tx:Tx,empresa:EmpresaFiscal)=>Promise<T>,lock:"shared"|"exclusive"="shared"){
  return withTenant(auth.company.companyId,auth.user.id,async tx=>{
    const requested=url.searchParams.get("empresa");
    if(requested&&!z.string().uuid().safeParse(requested).success) throw new HttpError(400,"Empresa cliente inválida");
    const rows=await tx.execute<EmpresaFiscal>(requested?sql`
      select id,nombre,razon_social "razonSocial",cuit,condicion_iva "condicionIva",rubro,activa
      from imp_empresas where id=${requested}::uuid and activa`:sql`
      select id,nombre,razon_social "razonSocial",cuit,condicion_iva "condicionIva",rubro,activa
      from imp_empresas where activa order by nombre limit 2`);
    if(rows.length===0) throw new HttpError(404,"No existe esa empresa cliente activa");
    if(!requested&&rows.length!==1) throw new HttpError(400,"Elegí la empresa cliente sobre la que querés trabajar");
    const empresa=rows[0];
    await tx.execute(sql`select set_config('app.imp_empresa_id',${empresa.id},true)`);
    return fn(tx,empresa);
  },lock);
}

export async function impuestos(method:string,path:string[],req:Request){
  const [,resource,action,detail]=path; const url=new URL(req.url);
  if(resource==="iva-simple"){
    if(action==="liquidacion") return impuestos(method,["impuestos","liquidacion"],req);
    if(action==="reabrir") return impuestos(method,["impuestos","reabrir"],req);
    if(action==="exportar") return impuestos(method,["impuestos","exportar"],req);
    if(method==="GET"&&action==="resumen"){
      const auth=await requirePermission("impuestos","ver");const periodo=parsePeriodo(url);
      return withImpuestos(auth,url,async(tx,empresa)=>{
        if(empresa.condicionIva!=="ri")throw new HttpError(409,"IVA Simple corresponde a responsables inscriptos");
        const esquema=await flujoFiscal(tx,empresa,periodo);if(esquema.flujo!=="iva_simple")throw new HttpError(409,"El período seleccionado no usa IVA Simple");
        const alicuotas=await tx.execute(sql`select c.libro,a.alicuota_codigo "codigo",sum(t.signo*round(a.neto_cents*c.tipo_cambio))::float8 "netoCents",sum(t.signo*round(a.iva_cents*c.tipo_cambio))::float8 "ivaCents" from imp_comprobantes c join imp_tipos_comprobante t on t.codigo=c.tipo_cbte join imp_comprobante_alicuotas a on a.comprobante_id=c.id where c.periodo=${periodo} and c.estado='vigente' group by c.libro,a.alicuota_codigo order by c.libro,a.alicuota_codigo`);
        const certificados=await tx.execute(sql`select tipo,sum(importe_cents)::float8 "importeCents" from imp_retenciones_percepciones where periodo_computo=${periodo} and estado='vigente' group by tipo`);
        const [liquidacion]=await tx.execute(sql`select estado,totales from imp_liquidaciones where periodo=${periodo}`);
        return ok({formulario:"F.2051",periodo,flujo:esquema.flujo,avisos:esquema.aviso?[esquema.aviso]:[],alicuotas,certificados,liquidacion:liquidacion??null});
      });
    }
    throw new HttpError(404,"No existe esa ruta de IVA Simple");
  }
  if(resource==="empresas"){
    const auth=await requirePermission("impuestos",method==="GET"?"ver":method==="POST"?"crear":method==="PATCH"?"editar":"anular");
    if(method==="GET"&&!action) {
      const condicion=url.searchParams.get("condicion");
      if(condicion!==null&&!(["ri","exento","monotributo"].includes(condicion)))throw new HttpError(400,"Condición inválida");
      return withTenant(auth.company.companyId,auth.user.id,async tx=>ok({items:await tx.execute(sql`
      select e.id,e.nombre,e.razon_social "razonSocial",e.cuit,e.condicion_iva "condicionIva",e.rubro,e.activa,
        v.obligacion "proximaObligacion",v.periodo "proximoPeriodo",v.fecha "proximaFecha",
        coalesce(p.estado,'abierto') "estadoPeriodo"
      from imp_empresas e left join lateral(
        select v.* from imp_vencimientos v
        left join imp_periodos px on px.empresa_cliente_id=e.id and px.periodo=v.periodo
        where right(e.cuit,1)::int between v.terminacion_desde and v.terminacion_hasta
          and ((e.condicion_iva='ri' and v.obligacion in ('iva_simple','f2002')) or (e.condicion_iva='exento' and v.obligacion='lid_exento'))
        order by (coalesce(px.estado,'abierto')<>'cerrado' and v.fecha<current_date) desc,v.fecha limit 1
      )v on e.condicion_iva in ('ri','exento')
      left join imp_periodos p on p.empresa_cliente_id=e.id and p.periodo=v.periodo
      where e.activa and (${condicion}::text is null or e.condicion_iva=${condicion}) order by e.nombre,e.cuit`)}));
    }
    if(method==="POST"&&!action){
      const body=await readBody(req,empresaSchema);
      return withTenant(auth.company.companyId,auth.user.id,async tx=>{
        try{
          const [row]=await tx.execute<EmpresaFiscal>(sql`insert into imp_empresas(company_id,nombre,razon_social,cuit,condicion_iva,rubro,created_by)
            values(${auth.company.companyId},${body.nombre},${body.razonSocial},${cuitDigits(body.cuit)},${body.condicionIva},${body.rubro||null},${auth.user.id})
            returning id,nombre,razon_social "razonSocial",cuit,condicion_iva "condicionIva",rubro,activa`);
          await writeAudit(tx,{companyId:auth.company.companyId,userId:auth.user.id,action:"impuestos.empresa.crear",entity:"imp_empresa",entityId:row.id,summary:`Empresa impositiva creada: ${row.nombre}`,metadata:{cuit:formatCuit(row.cuit)}});
          return ok(row);
        }catch(error){if((error as {code?:string}).code==="23505") throw new HttpError(409,"Ya existe una empresa cliente con ese CUIT");throw error;}
      },"exclusive");
    }
    if(action&&z.string().uuid().safeParse(action).success&&method==="GET"){
      url.searchParams.set("empresa",action);
      return withImpuestos(auth,url,async(tx,empresa)=>{
        const [counts]=await tx.execute<{compras:number;ventas:number;periodos:number;liquidaciones:number}>(sql`select
          (select count(*)::int from imp_comprobantes where libro='compras') compras,
          (select count(*)::int from imp_comprobantes where libro='ventas') ventas,
          (select count(*)::int from imp_periodos) periodos,
          (select count(*)::int from imp_liquidaciones) liquidaciones`);
        const [config]=await tx.execute<{toleranciaCents:number;crearEnTalonDefault:boolean;esquemaIva:"iva_simple"|"f2002_lid";ivaSimpleDesde:string|null;coeficienteProrrateoBps:number|null}>(sql`select tolerancia_cents::int "toleranciaCents",crear_en_talon_default "crearEnTalonDefault",esquema_iva "esquemaIva",iva_simple_desde "ivaSimpleDesde",coeficiente_prorrateo_bps "coeficienteProrrateoBps" from imp_config limit 1`);
        const puntosVenta=await tx.execute<{numero:number;sistema:string}>(sql`select numero,sistema from imp_puntos_venta where activo order by numero`);
        const actividades=await tx.execute<{codigo:string;descripcion:string;principal:boolean}>(sql`select codigo,descripcion,principal from imp_actividades order by principal desc,codigo`);
        const vencimientos=await tx.execute<{obligacion:string;periodo:string;fecha:string;estado:string}>(sql`select v.obligacion,v.periodo,v.fecha,coalesce(p.estado,'abierto') estado from imp_vencimientos v left join imp_periodos p on p.periodo=v.periodo where right(${empresa.cuit},1)::int between v.terminacion_desde and v.terminacion_hasta order by v.fecha desc limit 12`);
        return ok({empresa,counts,seccion:detail??null,config:config??{toleranciaCents:5,crearEnTalonDefault:false,esquemaIva:"iva_simple",ivaSimpleDesde:"202511",coeficienteProrrateoBps:null},puntosVenta,actividades,vencimientos});
      });
    }
    if(action&&z.string().uuid().safeParse(action).success&&detail==="configuracion"&&method==="PATCH"){
      const body=await readBody(req,empresaConfigSchema);
      url.searchParams.set("empresa",action);
      return withImpuestos(auth,url,async(tx,empresa)=>{
        await tx.execute(sql`insert into imp_config(company_id,empresa_cliente_id,tolerancia_cents,crear_en_talon_default,esquema_iva,iva_simple_desde,coeficiente_prorrateo_bps)
          values(${auth.company.companyId},${empresa.id}::uuid,${body.toleranciaCents},${body.crearEnTalonDefault},${body.esquemaIva},${body.ivaSimpleDesde},${body.coeficienteProrrateoBps})
          on conflict(company_id,empresa_cliente_id) do update set tolerancia_cents=excluded.tolerancia_cents,crear_en_talon_default=excluded.crear_en_talon_default,esquema_iva=excluded.esquema_iva,iva_simple_desde=excluded.iva_simple_desde,coeficiente_prorrateo_bps=excluded.coeficiente_prorrateo_bps,updated_at=now()`);
        await tx.execute(sql`delete from imp_puntos_venta`);
        for(const numero of body.puntosVenta) await tx.execute(sql`insert into imp_puntos_venta(company_id,empresa_cliente_id,numero,sistema) values(${auth.company.companyId},${empresa.id}::uuid,${numero},'manual')`);
        await tx.execute(sql`delete from imp_actividades`);
        for(const actividad of body.actividades) await tx.execute(sql`insert into imp_actividades(company_id,empresa_cliente_id,codigo,descripcion,principal) values(${auth.company.companyId},${empresa.id}::uuid,${actividad.codigo},${actividad.descripcion},${actividad.principal})`);
        await writeAudit(tx,{companyId:auth.company.companyId,userId:auth.user.id,action:"impuestos.configuracion.editar",entity:"imp_empresa",entityId:empresa.id,summary:`Configuración fiscal actualizada: ${empresa.nombre}`,metadata:{toleranciaCents:body.toleranciaCents,esquemaIva:body.esquemaIva,ivaSimpleDesde:body.ivaSimpleDesde,puntosVenta:body.puntosVenta,actividades:body.actividades.map(a=>a.codigo)}});
        return ok({saved:true});
      },"exclusive");
    }
    if(action&&z.string().uuid().safeParse(action).success&&method==="PATCH"){
      const body=await readBody(req,empresaSchema);
      return withTenant(auth.company.companyId,auth.user.id,async tx=>{
        const [before]=await tx.execute<EmpresaFiscal>(sql`select id,nombre,razon_social "razonSocial",cuit,condicion_iva "condicionIva",rubro,activa from imp_empresas where id=${action}::uuid`);
        if(!before) throw new HttpError(404,"No existe esa empresa cliente");
        try{
          const [row]=await tx.execute<EmpresaFiscal>(sql`update imp_empresas set nombre=${body.nombre},razon_social=${body.razonSocial},cuit=${cuitDigits(body.cuit)},condicion_iva=${body.condicionIva},rubro=${body.rubro||null},updated_at=now() where id=${action}::uuid returning id,nombre,razon_social "razonSocial",cuit,condicion_iva "condicionIva",rubro,activa`);
          await writeAudit(tx,{companyId:auth.company.companyId,userId:auth.user.id,action:"impuestos.empresa.editar",entity:"imp_empresa",entityId:row.id,summary:`Empresa impositiva actualizada: ${row.nombre}`,metadata:{antes:before,despues:row}});
          return ok(row);
        }catch(error){if((error as {code?:string}).code==="23505") throw new HttpError(409,"Ya existe una empresa cliente con ese CUIT");throw error;}
      },"exclusive");
    }
    if(action&&z.string().uuid().safeParse(action).success&&method==="DELETE") return withTenant(auth.company.companyId,auth.user.id,async tx=>{
      const [row]=await tx.execute<EmpresaFiscal>(sql`update imp_empresas set activa=false,updated_at=now() where id=${action}::uuid and activa returning id,nombre,razon_social "razonSocial",cuit,condicion_iva "condicionIva",rubro,activa`);
      if(!row) throw new HttpError(404,"No existe esa empresa cliente activa");
      await writeAudit(tx,{companyId:auth.company.companyId,userId:auth.user.id,action:"impuestos.empresa.baja",entity:"imp_empresa",entityId:row.id,summary:`Empresa impositiva desactivada: ${row.nombre}`,metadata:{cuit:formatCuit(row.cuit)}});
      return ok({deleted:true});
    },"exclusive");
    throw new HttpError(404,"No existe esa ruta de empresas impositivas");
  }
  if(resource==="retenciones-practicadas"){
    const auth=await requirePermission("impuestos",method==="GET"?"ver":method==="POST"?"crear":method==="PATCH"?"editar":"anular");
    if(method==="GET")return withImpuestos(auth,url,async(tx,empresa)=>{
      const periodo=url.searchParams.has("periodo")?parsePeriodo(url):null;
      const items=await tx.execute<Record<string,unknown>>(sql`select id,tipo,sujeto_cuit "sujetoCuit",sujeto_denominacion "sujetoDenominacion",regimen,base_cents::float8 "baseCents",alicuota_bps "alicuotaBps",importe_cents::float8 "importeCents",fecha,comprobante_id "comprobanteId",numero_certificado "numeroCertificado",estado,formulario,tipo_comprobante "tipoComprobante",fecha_comprobante "fechaComprobante",numero_comprobante "numeroComprobante",importe_comprobante_cents::float8 "importeComprobanteCents",ordenante_cuit "ordenanteCuit",aplica_cdi "aplicaCdi",codigo_alicuota "codigoAlicuota",aplica_acrecentamiento "aplicaAcrecentamiento",retenido_nif "retenidoNif",retenido_domicilio "retenidoDomicilio",retenido_pais "retenidoPais",retenido_tipo_persona "retenidoTipoPersona",nacimiento_pais "nacimientoPais",nacimiento_fecha "nacimientoFecha",sicore_impuesto "sicoreImpuesto",sicore_operacion "sicoreOperacion",sicore_condicion "sicoreCondicion",sicore_tipo_documento "sicoreTipoDocumento",certificado_original "certificadoOriginal" from imp_retenciones_practicadas where estado='vigente' and (${periodo}::text is null or to_char(fecha,'YYYYMM')=${periodo}) order by fecha,numero_certificado`);
      const formato=url.searchParams.get("formato");
      if(formato==="csv")return new Response(csvPracticadas(items),{headers:{"Content-Type":"text/csv; charset=utf-8","Content-Disposition":'attachment; filename="retenciones-practicadas.csv"'}});
      if(formato==="sire-f2003"||formato==="sire-f2004"){
        const formulario=formato==="sire-f2003"?2003:2004;const selected=items.filter(r=>Number(r.formulario)===formulario);const errors:string[]=[];const lines:string[]=[];
        for(const r of selected){const label=String(r.numeroCertificado);const regimen=Number(String(r.regimen??"").replace(/\D/g,""));const fecha=String(r.fecha??"").slice(0,10);const fechaCbte=String(r.fechaComprobante??"").slice(0,10);const numero=String(r.numeroComprobante??"");const importe=Number(r.importeComprobanteCents);if(!regimen)errors.push(`${label}: régimen inválido`);if(!fechaCbte||!numero||!Number.isFinite(importe))errors.push(`${label}: faltan datos del comprobante`);if(fecha.slice(0,7).replace("-","")!==periodo)errors.push(`${label}: fecha fuera del período`);if(formulario===2003&&(!r.ordenanteCuit||!r.retenidoNif||!r.retenidoDomicilio||!r.retenidoPais||!r.retenidoTipoPersona||!r.codigoAlicuota))errors.push(`${label}: faltan datos específicos de F.2003`);if(formulario===2003&&r.retenidoTipoPersona==="F"&&!r.nacimientoFecha)errors.push(`${label}: C29 fecha de nacimiento obligatoria para persona física`);if(errors.some(e=>e.startsWith(`${label}:`)))continue;const common={agenteCuit:empresa.cuit,regimen,retenidoCuit:String(r.sujetoCuit),fechaRetencion:fecha,tipoComprobante:Number(r.tipoComprobante),fechaComprobante:fechaCbte,numeroComprobante:numero,importeComprobanteCents:importe,importeRetencionCents:Number(r.importeCents),baseCents:Number(r.baseCents)};lines.push(formulario===2003?sire2003({...common,ordenanteCuit:String(r.ordenanteCuit),aplicaCdi:Boolean(r.aplicaCdi),codigoAlicuota:Number(r.codigoAlicuota),aplicaAcrecentamiento:Boolean(r.aplicaAcrecentamiento),retenidoNif:String(r.retenidoNif),retenidoNombre:String(r.sujetoDenominacion),retenidoDomicilio:String(r.retenidoDomicilio),retenidoPais:Number(r.retenidoPais),retenidoTipoPersona:r.retenidoTipoPersona as "F"|"J",nacimientoPais:r.nacimientoPais==null?undefined:Number(r.nacimientoPais),nacimientoFecha:r.nacimientoFecha?String(r.nacimientoFecha).slice(0,10):undefined}):sire2004(common));}
        if(!selected.length)errors.push(`No hay registros configurados para F.${formulario}`);if(errors.length)throw new HttpError(409,`Hay registros que no validan para F.${formulario}`,errors);return new Response(new Uint8Array(toAnsi(sireTxt(lines))),{headers:{"Content-Type":"text/plain; charset=iso-8859-1","Content-Disposition":`attachment; filename="SIRE-F${formulario}-${periodo}.txt"`}});
      }
      if(formato==="sire-f2005"){
        const errors:string[]=[];const lines:string[]=[];const selected=items.filter(r=>Number(r.formulario)===2005);
        for(const r of selected){const rowErrors:string[]=[];const regimen=Number(String(r.regimen??"").replace(/\D/g,""));const fecha=String(r.fecha??"").slice(0,10);if(!regimen)rowErrors.push(`${r.numeroCertificado}: régimen inválido`);if(!isValidCuit(String(r.sujetoCuit)))rowErrors.push(`${r.numeroCertificado}: CUIT inválido`);if(Number(r.importeCents)<=0)rowErrors.push(`${r.numeroCertificado}: importe debe ser mayor que cero`);if(fecha.slice(0,7).replace("-","")!==periodo)rowErrors.push(`${r.numeroCertificado}: fecha fuera del período`);errors.push(...rowErrors);if(!rowErrors.length)lines.push(sire2005({agenteCuit:empresa.cuit,regimen,retenidoCuit:String(r.sujetoCuit),fechaRetencion:fecha,tipoComprobante:Number(r.tipoComprobante),fechaComprobante:String(r.fechaComprobante).slice(0,10),numeroComprobante:String(r.numeroComprobante),importeComprobanteCents:Number(r.importeComprobanteCents),importeRetencionCents:Number(r.importeCents),baseCents:Number(r.baseCents)}));}
        if(!selected.length)errors.push("No hay registros configurados para F.2005");
        if(errors.length)throw new HttpError(409,"Hay retenciones que no validan para SIRE",errors);return new Response(new Uint8Array(toAnsi(sireTxt(lines))),{headers:{"Content-Type":"text/plain; charset=iso-8859-1","Content-Disposition":`attachment; filename="SIRE-F2005-${periodo}.txt"`}});
      }
      if(formato==="sicore"){
        if(process.env.IMP_SICORE_EXPERIMENTAL!=="1")throw new HttpError(409,"Exportación SICORE no disponible: diseño a confirmar");
        const selected=items.filter(r=>Number(r.formulario)===0);if(!selected.length)throw new HttpError(409,"No hay registros configurados para SICORE");const rows=selected.map(r=>({comprobante:Number(r.tipoComprobante),fechaComprobante:String(r.fechaComprobante).slice(0,10),numeroComprobante:String(r.numeroComprobante),importeComprobanteCents:Number(r.importeComprobanteCents),impuesto:Number(r.sicoreImpuesto),regimen:Number(String(r.regimen).replace(/\D/g,"")),operacion:Number(r.sicoreOperacion),baseCents:Number(r.baseCents),fechaRetencion:String(r.fecha).slice(0,10),condicion:Number(r.sicoreCondicion),importeRetencionCents:Number(r.importeCents),tipoDocumento:Number(r.sicoreTipoDocumento),numeroDocumento:String(r.sujetoCuit),certificadoOriginal:String(r.certificadoOriginal)}));const errors=rows.flatMap(validarCodigosSicore);if(errors.length)throw new HttpError(409,"Hay registros que no validan para SICORE",errors);const txt=sicoreTxt(rows);return new Response(new Uint8Array(toAnsi(txt)),{headers:{"Content-Type":"text/plain; charset=iso-8859-1","Content-Disposition":`attachment; filename="SICORE-EXPERIMENTAL-${periodo}.txt"`,"X-Talon-Warning":SICORE_CODES_WARNING}});
      }
      return ok({items});
    });
    if(method==="POST"||method==="PATCH"){const body=await readBody(req,practicadaSchema);return withImpuestos(auth,url,async(tx,empresa)=>{
      const periodo=body.fecha.slice(0,7).replace("-","");
      if(method==="PATCH") {const[current]=await tx.execute<{periodo:string}>(sql`select to_char(fecha,'YYYYMM') periodo from imp_retenciones_practicadas where id=${action}::uuid and estado='vigente'`);if(!current)throw new HttpError(404,"No existe la retención practicada");const[oldClosed]=await tx.execute<{closed:boolean}>(sql`select exists(select 1 from imp_periodos where periodo=${current.periodo} and estado='cerrado') closed`);if(oldClosed.closed)throw new HttpError(409,`El período original (${fmtPeriodo(current.periodo)}) está confirmado. Reabrilo para continuar.`);}
      const [closed]=await tx.execute<{closed:boolean}>(sql`select exists(select 1 from imp_periodos where periodo=${periodo} and estado='cerrado') closed`);if(closed.closed)throw new HttpError(409,method==="PATCH"?`El período nuevo (${fmtPeriodo(periodo)}) está confirmado. Reabrilo para continuar.`:mensajePeriodoCerrado(periodo));
      const [config]=await tx.execute<{tolerancia:number}>(sql`select tolerancia_cents::int tolerancia from imp_config limit 1`);const importeError=validarImportePracticado(body.baseCents,body.alicuotaBps,body.importeCents,config?.tolerancia??5);if(importeError)throw new HttpError(400,importeError);
      if(body.comprobanteId){const [cbte]=await tx.execute(sql`select id from imp_comprobantes where id=${body.comprobanteId}::uuid and libro='ventas'`);if(!cbte)throw new HttpError(400,"El comprobante de venta no pertenece a la empresa seleccionada");}
      try{const[row]=method==="POST"?await tx.execute<{id:string}>(sql`insert into imp_retenciones_practicadas(company_id,tipo,sujeto_cuit,sujeto_denominacion,regimen,base_cents,alicuota_bps,importe_cents,fecha,comprobante_id,numero_certificado,formulario,tipo_comprobante,fecha_comprobante,numero_comprobante,importe_comprobante_cents,ordenante_cuit,aplica_cdi,codigo_alicuota,aplica_acrecentamiento,retenido_nif,retenido_domicilio,retenido_pais,retenido_tipo_persona,nacimiento_pais,nacimiento_fecha,sicore_impuesto,sicore_operacion,sicore_condicion,sicore_tipo_documento,certificado_original,created_by) values(${auth.company.companyId},${body.tipo},${cuitDigits(body.sujetoCuit)},${body.sujetoDenominacion},${body.regimen},${body.baseCents},${body.alicuotaBps},${body.importeCents},${body.fecha}::date,${body.comprobanteId}::uuid,${body.numeroCertificado},${body.formulario},${body.tipoComprobante},${body.fechaComprobante??body.fecha}::date,${body.numeroComprobante??body.numeroCertificado},${body.importeComprobanteCents??body.baseCents},${body.ordenanteCuit?cuitDigits(body.ordenanteCuit):null},${body.aplicaCdi},${body.codigoAlicuota??null},${body.aplicaAcrecentamiento},${body.retenidoNif??null},${body.retenidoDomicilio??null},${body.retenidoPais??null},${body.retenidoTipoPersona??null},${body.nacimientoPais??null},${body.nacimientoFecha??null}::date,${body.sicoreImpuesto??null},${body.sicoreOperacion??null},${body.sicoreCondicion??null},${body.sicoreTipoDocumento??null},${body.certificadoOriginal??null},${auth.user.id}::uuid) returning id`):await tx.execute<{id:string}>(sql`update imp_retenciones_practicadas set tipo=${body.tipo},sujeto_cuit=${cuitDigits(body.sujetoCuit)},sujeto_denominacion=${body.sujetoDenominacion},regimen=${body.regimen},base_cents=${body.baseCents},alicuota_bps=${body.alicuotaBps},importe_cents=${body.importeCents},fecha=${body.fecha}::date,comprobante_id=${body.comprobanteId}::uuid,numero_certificado=${body.numeroCertificado},formulario=${body.formulario},tipo_comprobante=${body.tipoComprobante},fecha_comprobante=${body.fechaComprobante??body.fecha}::date,numero_comprobante=${body.numeroComprobante??body.numeroCertificado},importe_comprobante_cents=${body.importeComprobanteCents??body.baseCents},ordenante_cuit=${body.ordenanteCuit?cuitDigits(body.ordenanteCuit):null},aplica_cdi=${body.aplicaCdi},codigo_alicuota=${body.codigoAlicuota??null},aplica_acrecentamiento=${body.aplicaAcrecentamiento},retenido_nif=${body.retenidoNif??null},retenido_domicilio=${body.retenidoDomicilio??null},retenido_pais=${body.retenidoPais??null},retenido_tipo_persona=${body.retenidoTipoPersona??null},nacimiento_pais=${body.nacimientoPais??null},nacimiento_fecha=${body.nacimientoFecha??null}::date,sicore_impuesto=${body.sicoreImpuesto??null},sicore_operacion=${body.sicoreOperacion??null},sicore_condicion=${body.sicoreCondicion??null},sicore_tipo_documento=${body.sicoreTipoDocumento??null},certificado_original=${body.certificadoOriginal??null} where id=${action}::uuid and estado='vigente' returning id`);if(!row)throw new HttpError(404,"No existe la retención practicada");await writeAudit(tx,{companyId:auth.company.companyId,userId:auth.user.id,action:`impuestos.retencion_practicada.${method==="POST"?"crear":"editar"}`,entity:"imp_retencion_practicada",entityId:row.id,summary:`Retención practicada ${body.numeroCertificado}`,metadata:{empresa:empresa.id,periodo}});return ok(row);}catch(e){if((e as{code?:string}).code==="23505")throw new HttpError(409,"El certificado ya existe");throw e;}},"exclusive");}
    if(method==="DELETE"&&action){const body=await readBody(req,z.object({motivo:z.string().trim().min(5).max(500)}));return withImpuestos(auth,url,async tx=>{const[row]=await tx.execute<{id:string;periodo:string}>(sql`select id,to_char(fecha,'YYYYMM') periodo from imp_retenciones_practicadas where id=${action}::uuid and estado='vigente'`);if(!row)throw new HttpError(404,"No existe la retención practicada");const[closed]=await tx.execute<{closed:boolean}>(sql`select exists(select 1 from imp_periodos where periodo=${row.periodo} and estado='cerrado') closed`);if(closed.closed)throw new HttpError(409,mensajePeriodoCerrado(row.periodo));await tx.execute(sql`update imp_retenciones_practicadas set estado='anulado' where id=${row.id}::uuid`);await writeAudit(tx,{companyId:auth.company.companyId,userId:auth.user.id,action:"impuestos.retencion_practicada.anular",entity:"imp_retencion_practicada",entityId:row.id,summary:"Retención practicada anulada",metadata:{motivo:body.motivo}});return ok({deleted:true});},"exclusive");}
    throw new HttpError(404,"No existe esa ruta de retenciones practicadas");
  }
  if(resource==="iva-ajustes"){
    const auth=await requirePermission("impuestos",method==="GET"?"ver":method==="POST"?"crear":method==="PATCH"?"editar":"anular");
    const periodo=parsePeriodo(url);
    if(method==="GET")return withImpuestos(auth,url,async tx=>ok({items:await tx.execute(sql`select id,periodo,lado,clase,actividad,concepto,tipo_operacion "tipoOperacion",tipo_sujeto "tipoSujeto",alicuota_codigo "alicuotaCodigo",neto_cents::float8 "netoCents",impuesto_facturado_cents::float8 "impuestoFacturadoCents",impuesto_computable_cents::float8 "impuestoComputableCents",dacion_pago_cents::float8 "dacionPagoCents",exento_cents::float8 "exentoCents" from imp_iva_ajustes where periodo=${periodo} and estado='vigente' order by lado,created_at`)}));
    if(method==="POST"||method==="PATCH"){const body=await readBody(req,ajusteSchema);const errors=validarAjuste(body as Ajuste);if(errors.length)throw new HttpError(400,errors.join(". "));return withImpuestos(auth,url,async(tx,empresa)=>{if(method==="PATCH"){const[current]=await tx.execute<{periodo:string}>(sql`select periodo from imp_iva_ajustes where id=${action}::uuid and estado='vigente'`);if(!current)throw new HttpError(404,"No existe el ajuste");const[oldClosed]=await tx.execute<{closed:boolean}>(sql`select exists(select 1 from imp_periodos where periodo=${current.periodo} and estado='cerrado') closed`);if(oldClosed.closed)throw new HttpError(409,mensajePeriodoCerrado(current.periodo));}const [closed]=await tx.execute<{closed:boolean}>(sql`select exists(select 1 from imp_periodos where periodo=${body.periodo} and estado='cerrado') closed`);if(closed.closed)throw new HttpError(409,mensajePeriodoCerrado(body.periodo));try{const[row]=method==="POST"?await tx.execute<{id:string}>(sql`insert into imp_iva_ajustes(company_id,empresa_cliente_id,periodo,lado,clase,actividad,concepto,tipo_operacion,tipo_sujeto,alicuota_codigo,neto_cents,impuesto_facturado_cents,impuesto_computable_cents,dacion_pago_cents,exento_cents,created_by) values(${auth.company.companyId},${empresa.id},${body.periodo},${body.lado},${body.clase},${body.actividad??null},${body.concepto??null},${body.tipoOperacion??null},${body.tipoSujeto??null},${body.alicuotaCodigo??null},${body.netoCents},${body.impuestoFacturadoCents},${body.impuestoComputableCents},${body.dacionPagoCents},${body.exentoCents},${auth.user.id}) returning id`):await tx.execute<{id:string}>(sql`update imp_iva_ajustes set periodo=${body.periodo},lado=${body.lado},clase=${body.clase},actividad=${body.actividad??null},concepto=${body.concepto??null},tipo_operacion=${body.tipoOperacion??null},tipo_sujeto=${body.tipoSujeto??null},alicuota_codigo=${body.alicuotaCodigo??null},neto_cents=${body.netoCents},impuesto_facturado_cents=${body.impuestoFacturadoCents},impuesto_computable_cents=${body.impuestoComputableCents},dacion_pago_cents=${body.dacionPagoCents},exento_cents=${body.exentoCents},updated_at=now() where id=${action}::uuid and estado='vigente' returning id`);if(!row)throw new HttpError(404,"No existe el ajuste");await writeAudit(tx,{companyId:auth.company.companyId,userId:auth.user.id,action:`impuestos.ajuste.${method==="POST"?"crear":"editar"}`,entity:"imp_iva_ajuste",entityId:row.id,summary:`Ajuste de IVA ${body.lado}`,metadata:{periodo:body.periodo}});return ok(row);}catch(e){if(esErrorPeriodoCerrado(e))throw new HttpError(409,mensajePeriodoCerrado(body.periodo));throw e;}},"exclusive");}
    if(method==="DELETE"&&action){const body=await readBodyWithEmptyMessage(req,z.object({motivo:z.string().trim().min(5)}),"Indicá el motivo de la anulación");return withImpuestos(auth,url,async tx=>{const[current]=await tx.execute<{id:string;periodo:string}>(sql`select id,periodo from imp_iva_ajustes where id=${action}::uuid and estado='vigente'`);if(!current)throw new HttpError(404,"No existe el ajuste");const[closed]=await tx.execute<{closed:boolean}>(sql`select exists(select 1 from imp_periodos where periodo=${current.periodo} and estado='cerrado') closed`);if(closed.closed)throw new HttpError(409,mensajePeriodoCerrado(current.periodo));try{const[row]=await tx.execute<{id:string}>(sql`update imp_iva_ajustes set estado='anulado',updated_at=now() where id=${current.id}::uuid and estado='vigente' returning id`);if(!row)throw new HttpError(404,"No existe el ajuste");await writeAudit(tx,{companyId:auth.company.companyId,userId:auth.user.id,action:"impuestos.ajuste.anular",entity:"imp_iva_ajuste",entityId:row.id,summary:"Ajuste de IVA anulado",metadata:{motivo:body.motivo,periodo:current.periodo}});return ok({deleted:true});}catch(e){if(esErrorPeriodoCerrado(e))throw new HttpError(409,mensajePeriodoCerrado(current.periodo));throw e;}},"exclusive");}
  }
  if(resource==="importacion-servicios"){
    const auth=await requirePermission("impuestos",method==="GET"?"ver":method==="POST"?"crear":method==="PATCH"?"editar":"anular");const periodo=parsePeriodo(url);
    if(method==="GET")return withImpuestos(auth,url,async tx=>ok({items:await tx.execute(sql`select * from imp_importacion_servicios where periodo=${periodo} and estado='vigente' order by fecha,id`)}));
    if(method==="POST"){const b=await readBody(req,servicioSchema);if(b.periodo!==periodo)throw new HttpError(400,"El período del cuerpo no coincide con el de la URL");return withImpuestos(auth,url,async(tx,empresa)=>{const[closed]=await tx.execute<{closed:boolean}>(sql`select exists(select 1 from imp_periodos where periodo=${b.periodo} and estado='cerrado') closed`);if(closed.closed)throw new HttpError(409,mensajePeriodoCerrado(b.periodo));const[row]=await tx.execute<{id:string}>(sql`insert into imp_importacion_servicios(company_id,empresa_cliente_id,periodo,tipo_cbte,descripcion,identificacion,fecha,monto_original_cents,moneda,tipo_cambio,prestador_cuit,prestador_nif,prestador_nombre,alicuota_bps,fecha_ingreso,impuesto_ingresado_cents,impuesto_computable_cents,pago_identificacion,entidad_pago_cuit,created_by) values(${auth.company.companyId},${empresa.id},${b.periodo},${b.tipoCbte},${b.descripcion??null},${b.identificacion},${b.fecha},${b.montoOriginalCents},${b.moneda},${b.tipoCambio},${cuitDigits(b.prestadorCuit)},${b.prestadorNif},${b.prestadorNombre},${b.alicuotaBps},${b.fechaIngreso},${b.impuestoIngresadoCents},${b.impuestoComputableCents},${b.pagoIdentificacion},${cuitDigits(b.entidadPagoCuit)},${auth.user.id}) returning id`);await writeAudit(tx,{companyId:auth.company.companyId,userId:auth.user.id,action:"impuestos.importacion_servicio.crear",entity:"imp_importacion_servicio",entityId:row.id,summary:"Importación de servicio cargada",metadata:{periodo}});return ok(row);},"exclusive");}
    if(method==="PATCH"&&action){const b=await readBody(req,servicioSchema);return withImpuestos(auth,url,async tx=>{const[current]=await tx.execute<{id:string;periodo:string}>(sql`select id,periodo from imp_importacion_servicios where id=${action}::uuid and estado='vigente'`);if(!current)throw new HttpError(404,"No existe la importación de servicio");for(const p of new Set([current.periodo,b.periodo])){const[closed]=await tx.execute<{closed:boolean}>(sql`select exists(select 1 from imp_periodos where periodo=${p} and estado='cerrado') closed`);if(closed.closed)throw new HttpError(409,mensajePeriodoCerrado(p));}try{await tx.execute(sql`update imp_importacion_servicios set periodo=${b.periodo},tipo_cbte=${b.tipoCbte},descripcion=${b.descripcion??null},identificacion=${b.identificacion},fecha=${b.fecha},monto_original_cents=${b.montoOriginalCents},moneda=${b.moneda},tipo_cambio=${b.tipoCambio},prestador_cuit=${cuitDigits(b.prestadorCuit)},prestador_nif=${b.prestadorNif},prestador_nombre=${b.prestadorNombre},alicuota_bps=${b.alicuotaBps},fecha_ingreso=${b.fechaIngreso},impuesto_ingresado_cents=${b.impuestoIngresadoCents},impuesto_computable_cents=${b.impuestoComputableCents},pago_identificacion=${b.pagoIdentificacion},entidad_pago_cuit=${cuitDigits(b.entidadPagoCuit)},updated_at=now() where id=${current.id}::uuid`);}catch(e){if(esErrorPeriodoCerrado(e))throw new HttpError(409,mensajePeriodoCerrado(b.periodo));throw e;}await writeAudit(tx,{companyId:auth.company.companyId,userId:auth.user.id,action:"impuestos.importacion_servicio.editar",entity:"imp_importacion_servicio",entityId:current.id,summary:"Importación de servicio editada",metadata:{periodo:b.periodo}});return ok({id:current.id});},"exclusive");}
    if(method==="DELETE"&&action){const b=await readBodyWithEmptyMessage(req,z.object({motivo:z.string().trim().min(5).max(500)}),"Indicá el motivo de la anulación");return withImpuestos(auth,url,async tx=>{const[current]=await tx.execute<{id:string;periodo:string}>(sql`select id,periodo from imp_importacion_servicios where id=${action}::uuid and estado='vigente'`);if(!current)throw new HttpError(404,"No existe la importación de servicio");const[closed]=await tx.execute<{closed:boolean}>(sql`select exists(select 1 from imp_periodos where periodo=${current.periodo} and estado='cerrado') closed`);if(closed.closed)throw new HttpError(409,mensajePeriodoCerrado(current.periodo));try{await tx.execute(sql`update imp_importacion_servicios set estado='anulado',updated_at=now() where id=${current.id}::uuid`);}catch(e){if(esErrorPeriodoCerrado(e))throw new HttpError(409,mensajePeriodoCerrado(current.periodo));throw e;}await writeAudit(tx,{companyId:auth.company.companyId,userId:auth.user.id,action:"impuestos.importacion_servicio.anular",entity:"imp_importacion_servicio",entityId:current.id,summary:"Importación de servicio anulada",metadata:{periodo:current.periodo,motivo:b.motivo}});return ok({deleted:true});},"exclusive");}
  }
  if(resource==="comprobantes"){
    const auth=await requirePermission("impuestos",method==="GET"?"ver":method==="POST"?"crear":method==="PATCH"?"editar":"anular");
    if(method==="PATCH"&&detail==="destino") {const body=await readBody(req,z.object({destinoCredito:z.enum(["directo_gravado","directo_exento","prorratea"])}));return withImpuestos(auth,url,async tx=>{const[row]=await tx.execute<{id:string;periodo:string}>(sql`select id,periodo from imp_comprobantes where id=${action}::uuid and estado='vigente'`);if(!row)throw new HttpError(404,"No existe el comprobante");const[closed]=await tx.execute<{closed:boolean}>(sql`select exists(select 1 from imp_periodos where periodo=${row.periodo} and estado='cerrado') closed`);if(closed.closed)throw new HttpError(409,mensajePeriodoCerrado(row.periodo));await tx.execute(sql`update imp_comprobantes set destino_credito=${body.destinoCredito},prorratea=${body.destinoCredito==="prorratea"},updated_at=now() where id=${row.id}::uuid`);await writeAudit(tx,{companyId:auth.company.companyId,userId:auth.user.id,action:"impuestos.comprobante.destino",entity:"imp_comprobante",entityId:row.id,summary:"Destino del crédito fiscal actualizado",metadata:{destinoCredito:body.destinoCredito}});return ok({saved:true});},"exclusive");}
    if(method==="PATCH"&&action==="destinos") {const body=await readBody(req,z.object({ids:z.array(z.string().uuid()).min(1).max(500),destinoCredito:z.enum(["directo_gravado","directo_exento","prorratea"])}));return withImpuestos(auth,url,async tx=>{const rows:{id:string;periodo:string}[]=[];for(const id of body.ids){const[row]=await tx.execute<{id:string;periodo:string}>(sql`select id,periodo from imp_comprobantes where id=${id}::uuid and estado='vigente'`);if(!row)throw new HttpError(404,"Uno o más comprobantes no existen");rows.push(row);}for(const row of rows){const[closed]=await tx.execute<{closed:boolean}>(sql`select exists(select 1 from imp_periodos where periodo=${row.periodo} and estado='cerrado') closed`);if(closed.closed)throw new HttpError(409,"Uno de los períodos está confirmado. Reabrilo para continuar.");}for(const row of rows)await tx.execute(sql`update imp_comprobantes set destino_credito=${body.destinoCredito},prorratea=${body.destinoCredito==="prorratea"},updated_at=now() where id=${row.id}::uuid`);for(const row of rows)await writeAudit(tx,{companyId:auth.company.companyId,userId:auth.user.id,action:"impuestos.comprobante.destino",entity:"imp_comprobante",entityId:row.id,summary:"Destino del crédito fiscal actualizado en lote",metadata:{destinoCredito:body.destinoCredito}});return ok({updated:rows.length});},"exclusive");}
    if(method==="POST"||method==="PATCH"){
      const body=await readBody(req,manualSchema);
      return withImpuestos(auth,url,async(tx,empresa)=>{
        const [config]=await tx.execute<{tolerancia:number}>(sql`select tolerancia_cents::int tolerancia from imp_config limit 1`);
        const errors=validarComprobanteManual({...body,creditoFiscalCents:body.creditoFiscalCents},config?.tolerancia??5);
        const fechaPeriodo=reglaFechaImportada(body.libro,body.fecha,body.periodo);
        if(fechaPeriodo.rechazo) errors.push(fechaPeriodo.rechazo);
        if(errors.length) throw new HttpError(400,errors.join(". "));
        const [tipo]=await tx.execute<{ok:boolean}>(sql`select true ok from imp_tipos_comprobante where codigo=${body.tipoCbte}`);if(!tipo)throw new HttpError(400,"Tipo de comprobante inexistente");
        const [closed]=await tx.execute<{closed:boolean}>(sql`select exists(select 1 from imp_periodos where periodo=${body.periodo} and estado='cerrado') closed`);if(closed.closed)throw new HttpError(409,mensajePeriodoCerrado(body.periodo));
        let row:{id:string}|undefined;
        try{
          if(method==="PATCH"){
            const [current]=await tx.execute<{origen:string;periodo:string}>(sql`select origen,periodo from imp_comprobantes where id=${action}::uuid`);if(!current)throw new HttpError(404,"No existe el comprobante");if(current.origen!=="manual")throw new HttpError(409,"Sólo se pueden editar comprobantes cargados manualmente");
            const [oldClosed]=await tx.execute<{closed:boolean}>(sql`select exists(select 1 from imp_periodos where periodo=${current.periodo} and estado='cerrado') closed`);if(oldClosed.closed)throw new HttpError(409,mensajePeriodoCerrado(current.periodo));
            [row]=await tx.execute<{id:string}>(sql`update imp_comprobantes set libro=${body.libro},fecha_cbte=${body.fecha}::date,periodo=${body.periodo},tipo_cbte=${body.tipoCbte},punto_venta=${body.puntoVenta},numero_desde=${body.numero}::bigint,numero_hasta=${body.numero}::bigint,doc_nro_emisor=${body.libro==="ventas"?empresa.cuit:cuitDigits(body.docNro)},doc_tipo=${body.docTipo},doc_nro=${cuitDigits(body.docNro)},denominacion=${body.denominacion},moneda=${body.moneda},tipo_cambio=${body.tipoCambio},neto_no_gravado_cents=${body.noGravadoCents},exento_cents=${body.exentoCents},otros_tributos_cents=${body.tributosCents},total_cents=${body.totalCents},credito_fiscal_computable_cents=${body.creditoFiscalCents},destino_credito=${body.destinoCredito},prorratea=${body.destinoCredito==="prorratea"},requiere_revision=${Boolean(fechaPeriodo.aviso)},avisos=${JSON.stringify(fechaPeriodo.aviso?[fechaPeriodo.aviso]:[])}::jsonb,updated_at=now() where id=${action}::uuid returning id`);
            await tx.execute(sql`delete from imp_comprobante_alicuotas where comprobante_id=${row.id}::uuid`);
          }else [row]=await tx.execute<{id:string}>(sql`insert into imp_comprobantes(company_id,libro,origen,fecha_cbte,periodo,tipo_cbte,punto_venta,numero_desde,numero_hasta,doc_nro_emisor,doc_tipo,doc_nro,denominacion,moneda,tipo_cambio,neto_no_gravado_cents,exento_cents,otros_tributos_cents,total_cents,credito_fiscal_computable_cents,destino_credito,prorratea,requiere_revision,avisos,created_by) values(${auth.company.companyId},${body.libro},'manual',${body.fecha}::date,${body.periodo},${body.tipoCbte},${body.puntoVenta},${body.numero}::bigint,${body.numero}::bigint,${body.libro==="ventas"?empresa.cuit:cuitDigits(body.docNro)},${body.docTipo},${cuitDigits(body.docNro)},${body.denominacion},${body.moneda},${body.tipoCambio},${body.noGravadoCents},${body.exentoCents},${body.tributosCents},${body.totalCents},${body.creditoFiscalCents},${body.destinoCredito},${body.destinoCredito==="prorratea"},${Boolean(fechaPeriodo.aviso)},${JSON.stringify(fechaPeriodo.aviso?[fechaPeriodo.aviso]:[])}::jsonb,${auth.user.id}::uuid) returning id`);
          for(const a of body.alicuotas)await tx.execute(sql`insert into imp_comprobante_alicuotas(company_id,comprobante_id,alicuota_codigo,neto_cents,iva_cents) values(${auth.company.companyId},${row.id}::uuid,${a.codigo},${a.netoCents},${a.ivaCents})`);
          await writeAudit(tx,{companyId:auth.company.companyId,userId:auth.user.id,action:`impuestos.comprobante.${method==="POST"?"crear":"editar"}`,entity:"imp_comprobante",entityId:row.id,summary:`Comprobante manual ${body.puntoVenta}-${body.numero}`,metadata:{libro:body.libro,periodo:body.periodo}});
          return ok(row);
        }catch(e){if((e as {code?:string}).code==="23505")throw new HttpError(409,"El comprobante ya existe");if(esErrorPeriodoCerrado(e))throw new HttpError(409,mensajePeriodoCerrado(body.periodo));throw e;}
      },"exclusive");
    }
    if(method==="DELETE"&&action){const body=await readBodyWithEmptyMessage(req,z.object({motivo:z.string().trim().min(5).max(500)}),"Indicá el motivo de la anulación");return withImpuestos(auth,url,async tx=>{const [row]=await tx.execute<{id:string;periodo:string}>(sql`select id,periodo from imp_comprobantes where id=${action}::uuid and estado='vigente'`);if(!row)throw new HttpError(404,"No existe el comprobante");try{await tx.execute(sql`update imp_comprobantes set estado='anulado',avisos=avisos||${JSON.stringify([body.motivo])}::jsonb,updated_at=now() where id=${row.id}::uuid`);}catch(e){if(esErrorPeriodoCerrado(e))throw new HttpError(409,mensajePeriodoCerrado(row.periodo));throw e;}await writeAudit(tx,{companyId:auth.company.companyId,userId:auth.user.id,action:"impuestos.comprobante.anular",entity:"imp_comprobante",entityId:row.id,summary:"Comprobante impositivo anulado",metadata:{motivo:body.motivo,periodo:row.periodo}});return ok({deleted:true});},"exclusive");}
  }
  if(resource==="retenciones-percepciones"){
    const auth=await requirePermission("impuestos",method==="GET"?"ver":method==="POST"?"crear":method==="PATCH"?"editar":"anular");
    if(method==="GET"&&action==="pendientes") {const actual=url.searchParams.has("actual")?parsePeriodo(url,"actual"):url.searchParams.has("periodo")?parsePeriodo(url):new Date().toISOString().slice(0,7).replace("-","");return withImpuestos(auth,url,async tx=>{const rows=await tx.execute<Record<string,unknown>>(sql`select id,tipo,regimen,agente_denominacion "agenteDenominacion",fecha,numero_certificado "numeroCertificado",importe_cents::float8 "importeCents",periodo_origen "periodoOrigen",periodo_computo "periodoComputo" from imp_retenciones_percepciones where tipo='percepcion' and estado='vigente' and periodo_computo>=${actual} order by periodo_computo,fecha`);return ok({items:rows.map(r=>({...r,...estadoPercepcionPendiente(String(r.periodoOrigen),String(r.periodoComputo),actual)}))});});}
    if(method==="GET"){
      const periodo=url.searchParams.has("periodo")?parsePeriodo(url):null;
      return withImpuestos(auth,url,async tx=>ok({items:await tx.execute(sql`select id,tipo,regimen,agente_cuit "agenteCuit",agente_denominacion "agenteDenominacion",fecha,numero_certificado "numeroCertificado",importe_cents::float8 "importeCents",periodo_origen "periodoOrigen",periodo_computo "periodoComputo",comprobante_id "comprobanteId",origen,estado
        from imp_retenciones_percepciones where estado='vigente' and (${periodo}::text is null or periodo_computo=${periodo}) order by fecha,numero_certificado`)}));
    }
    if(method==="POST"||method==="PATCH"){
      const body=await readBody(req,rpSchema); const error=validarPeriodoComputo(body.tipo,body.periodoOrigen,body.periodoComputo)??validarPeriodoOrigen(body.fecha,body.periodoOrigen); if(error) throw new HttpError(400,error);
      return withImpuestos(auth,url,async(tx,empresa)=>{
        const [current]=method==="PATCH"?await tx.execute<{periodo:string}>(sql`select periodo_computo periodo from imp_retenciones_percepciones where id=${action}::uuid and estado='vigente'`):[];
        if(method==="PATCH"&&!current)throw new HttpError(404,"No existe el certificado");
        if(current){const [oldClosed]=await tx.execute<{closed:boolean}>(sql`select exists(select 1 from imp_periodos where periodo=${current.periodo} and estado='cerrado') closed`);if(oldClosed.closed)throw new HttpError(409,`El período original (${fmtPeriodo(current.periodo)}) está confirmado. Reabrilo para continuar.`);}
        const [closed]=await tx.execute<{closed:boolean}>(sql`select exists(select 1 from imp_periodos where periodo=${body.periodoComputo} and estado='cerrado') closed`);
        if(closed.closed) throw new HttpError(409,method==="POST"?mensajePeriodoCerrado(body.periodoComputo):`El período nuevo (${fmtPeriodo(body.periodoComputo)}) está confirmado. Reabrilo para continuar.`);
        try{
          const [row]=method==="POST"
            ?await tx.execute<{id:string}>(sql`insert into imp_retenciones_percepciones(company_id,tipo,regimen,agente_cuit,agente_denominacion,fecha,numero_certificado,importe_cents,periodo_origen,periodo_computo,comprobante_id,created_by) values(${auth.company.companyId},${body.tipo},${body.regimen},${cuitDigits(body.agenteCuit)},${body.agenteDenominacion},${body.fecha}::date,${body.numeroCertificado},${body.importeCents},${body.periodoOrigen},${body.periodoComputo},${body.comprobanteId}::uuid,${auth.user.id}::uuid) returning id`)
            :await tx.execute<{id:string}>(sql`update imp_retenciones_percepciones set tipo=${body.tipo},regimen=${body.regimen},agente_cuit=${cuitDigits(body.agenteCuit)},agente_denominacion=${body.agenteDenominacion},fecha=${body.fecha}::date,numero_certificado=${body.numeroCertificado},importe_cents=${body.importeCents},periodo_origen=${body.periodoOrigen},periodo_computo=${body.periodoComputo},comprobante_id=${body.comprobanteId}::uuid,updated_at=now() where id=${action}::uuid returning id`);
          if(!row) throw new HttpError(404,"No existe el certificado");
          await writeAudit(tx,{companyId:auth.company.companyId,userId:auth.user.id,action:`impuestos.certificado.${method==="POST"?"crear":"editar"}`,entity:"imp_retencion_percepcion",entityId:row.id,summary:`Certificado actualizado: ${body.numeroCertificado}`,metadata:{empresa:empresa.id,tipo:body.tipo,periodoComputo:body.periodoComputo}});
          return ok(row);
        }catch(e){if((e as {code?:string}).code==="23505") throw new HttpError(409,"El certificado ya fue cargado");throw e;}
      },"exclusive");
    }
    if(method==="DELETE"&&action) {const body=await readBody(req,z.object({motivo:z.string().trim().min(5).max(500)}));return withImpuestos(auth,url,async tx=>{
      const [row]=await tx.execute<{id:string;periodo:string}>(sql`select id,periodo_computo periodo from imp_retenciones_percepciones where id=${action}::uuid and estado='vigente'`);if(!row)throw new HttpError(404,"No existe el certificado");
      const [closed]=await tx.execute<{closed:boolean}>(sql`select exists(select 1 from imp_periodos where periodo=${row.periodo} and estado='cerrado') closed`);if(closed.closed)throw new HttpError(409,mensajePeriodoCerrado(row.periodo));
      await tx.execute(sql`update imp_retenciones_percepciones set estado='anulado',updated_at=now() where id=${row.id}::uuid`);await writeAudit(tx,{companyId:auth.company.companyId,userId:auth.user.id,action:"impuestos.certificado.anular",entity:"imp_retencion_percepcion",entityId:row.id,summary:"Certificado impositivo anulado",metadata:{motivo:body.motivo,periodo:row.periodo}});return ok({deleted:true});
    },"exclusive");}
  }
  if(method==="GET"&&resource==="importar-rechazos"&&action){
    const auth=await requirePermission("impuestos","importar");
    return withImpuestos(auth,url,async tx=>{
      const rows=await tx.execute<{fila:number;motivo:string|null;raw:unknown}>(sql`select fila,motivo,raw from imp_import_rows where job_id=${action}::uuid and estado='rechazado' order by fila`);
      const quote=(value:unknown)=>`"${String(value??"").replaceAll('"','""')}"`;
      const csv=`\uFEFFfila;motivo;valores\r\n${rows.map(r=>`${r.fila};${quote(r.motivo)};${quote(JSON.stringify(r.raw))}`).join("\r\n")}${rows.length?"\r\n":""}`;
      return new Response(csv,{headers:{"Content-Type":"text/csv; charset=utf-8","Content-Disposition":`attachment; filename="rechazos-${action}.csv"`,"Cache-Control":"private, no-store"}});
    });
  }
  if(method==="GET"&&resource==="importaciones"){
    const auth=await requirePermission("impuestos","ver");return withImpuestos(auth,url,async tx=>ok({items:await tx.execute(sql`select id,tipo,archivo_nombre "archivoNombre",estado,resumen,created_at "createdAt",(select count(*)::int from imp_import_rows r join imp_comprobantes c on c.id=r.comprobante_id where r.job_id=j.id and c.estado='vigente') vigentes from imp_import_jobs j order by created_at desc limit 50`)}));
  }
  if(method==="POST"&&resource==="deshacer-importacion"&&action){
    const auth=await requirePermission("impuestos","anular");const body=await readBody(req,z.object({motivo:z.string().trim().min(5).max(500)}));
    return withImpuestos(auth,url,async tx=>{try{
      const [job]=await tx.execute<{estado:string}>(sql`select estado from imp_import_jobs where id=${action}::uuid`);
      if(!job)throw new HttpError(404,"No existe la importación");
      if(job.estado==="deshecho")throw new HttpError(409,"La importación ya fue deshecha");
      const rows=await tx.execute<{id:string}>(sql`update imp_comprobantes c set estado='anulado',avisos=c.avisos||${JSON.stringify([body.motivo])}::jsonb,updated_at=now() from imp_import_rows r where r.job_id=${action}::uuid and r.comprobante_id=c.id and c.estado='vigente' returning c.id`);
      await tx.execute(sql`update imp_import_jobs set estado='deshecho' where id=${action}::uuid`);
      await writeAudit(tx,{companyId:auth.company.companyId,userId:auth.user.id,action:"impuestos.importacion.deshacer",entity:"imp_import_job",entityId:action,summary:`Importación anulada: ${rows.length} comprobantes`,metadata:{motivo:body.motivo}});return ok({anulados:rows.length});
    }catch(e){if(esErrorPeriodoCerrado(e))throw new HttpError(409,"La importación contiene comprobantes de un período confirmado. Reabrilo antes de deshacer.");throw e;}},"exclusive");
  }
  if(method==="GET"&&resource==="libro"){
    const auth=await requirePermission("impuestos","ver"); const libro=action;
    if(libro!=="ventas"&&libro!=="compras") throw new HttpError(400,"Libro inválido");
    const periodo=parsePeriodo(url);
    return withImpuestos(auth,url,async tx=>ok({items:await tx.execute(sql`
      select c.*,t.signo,t.descripcion tipo_descripcion,t.letra,coalesce(jsonb_agg(jsonb_build_object('codigo',a.alicuota_codigo,'netoCents',a.neto_cents,'ivaCents',a.iva_cents)
        order by a.alicuota_codigo) filter(where a.id is not null),'[]') alicuotas
      from imp_comprobantes c join imp_tipos_comprobante t on t.codigo=c.tipo_cbte left join imp_comprobante_alicuotas a on a.comprobante_id=c.id
      where c.libro=${libro} and c.periodo=${periodo} group by c.id,t.signo,t.descripcion,t.letra order by c.fecha_cbte,c.punto_venta,c.numero_desde`)}));
  }
  if(method==="POST"&&resource==="traer-de-talon"){
    const auth=await requirePermission("impuestos","importar"); const body=await readBody(req,z.object({periodo:period}));
    return withImpuestos(auth,url,async tx=>ok(await traerDeTalon(tx,auth.company.companyId,auth.user.id,body.periodo)),"exclusive");
  }
  if(method==="POST"&&resource==="importar"){
    const auth=await requirePermission("impuestos","importar"); const body=await readBody(req,importSchema);
    const file=Buffer.from(body.base64,"base64"); const sizeError=validarTamanoImportacion(file.length);if(sizeError)throw new HttpError(413,sizeError);
    try {
      return await withImpuestos(auth,url,async (tx,empresa)=>{const result=await importarMisComprobantes(tx,{
        companyId:auth.company.companyId,userId:auth.user.id,companyCuit:formatCuit(empresa.cuit),
        canCreateCustomer:can(auth.permissions,"clientes","crear"),canCreateSupplier:can(auth.permissions,"proveedores","crear"),
      },file,body.fileName,body.periodo,body.crearEnTalon);await writeAudit(tx,{companyId:auth.company.companyId,userId:auth.user.id,action:"impuestos.importacion.confirmar",entity:"imp_import_job",entityId:result.jobId,summary:`Importación confirmada: ${body.fileName}`,metadata:{periodo:body.periodo,crearEnTalon:body.crearEnTalon,resumen:result}});return ok(result);},"exclusive");
    } catch(error) {
      if(error instanceof ImportValidationError) throw new HttpError(error.status,error.message);
      if(esErrorPeriodoCerrado(error)) throw new HttpError(409,mensajePeriodoCerrado(body.periodo));
      throw error;
    }
  }
  if(method==="GET"&&resource==="exportar"){
    const auth=await requirePermission("impuestos","exportar"); const periodo=parsePeriodo(url);
    return withImpuestos(auth,url,async(tx,empresa)=>{
      const esquema=await flujoFiscal(tx,empresa,periodo);
      const receipts=await tx.execute<Record<string,unknown>>(sql`select c.*,t.signo from imp_comprobantes c join imp_tipos_comprobante t on t.codigo=c.tipo_cbte where c.periodo=${periodo} and c.estado='vigente' order by c.libro,c.fecha_cbte,c.punto_venta,c.numero_desde,c.id`);
      const rates=await tx.execute<Record<string,unknown>>(sql`select a.* from imp_comprobante_alicuotas a join imp_comprobantes c on c.id=a.comprobante_id where c.periodo=${periodo} and c.estado='vigente' order by a.alicuota_codigo`);
      const [prorrateo]=await tx.execute<{coeficiente:number|null}>(sql`select coeficiente_prorrateo_bps coeficiente from imp_config limit 1`);
      const ventas=receipts.filter(r=>r.libro==="ventas");
      const cambios=new Map(receipts.map(r=>[r.id,Number(r.tipo_cambio??1)]));
      const ventasRates=new Map<unknown,number>();
      for(const a of rates)ventasRates.set(a.comprobante_id,(ventasRates.get(a.comprobante_id)??0)+Number(a.neto_cents??0)*(cambios.get(a.comprobante_id)??1));
      const coeficiente=prorrateo?.coeficiente??coeficienteProrrateoVentas(ventas.map(r=>({signo:Number(r.signo??1),gravadasCents:ventasRates.get(r.id)??0,exentasCents:Number(r.exento_cents??0)*Number(r.tipo_cambio??1),noGravadasCents:Number(r.neto_no_gravado_cents??0)*Number(r.tipo_cambio??1)})));
      const exportReceipts=aplicarDestinoCreditoExportacion(receipts,rates,coeficiente);
      const built=buildLibroIvaDigital(exportReceipts,rates);
      const adjustmentRows=await tx.execute<Record<string,unknown>>(sql`select lado,clase,actividad,concepto,tipo_operacion "tipoOperacion",tipo_sujeto "tipoSujeto",alicuota_codigo "alicuotaCodigo",neto_cents::float8 "netoCents",impuesto_facturado_cents::float8 "impuestoFacturadoCents",impuesto_computable_cents::float8 "impuestoComputableCents",dacion_pago_cents::float8 "dacionPagoCents",exento_cents::float8 "exentoCents" from imp_iva_ajustes where periodo=${periodo} and estado='vigente'`);
      const servicioRows=await tx.execute<Record<string,unknown>>(sql`select tipo_cbte "tipoCbte",descripcion,identificacion,fecha,monto_original_cents::float8 "montoOriginalCents",moneda,tipo_cambio::float8 "tipoCambio",prestador_cuit "prestadorCuit",prestador_nif "prestadorNif",prestador_nombre "prestadorNombre",alicuota_bps "alicuotaBps",fecha_ingreso "fechaIngreso",impuesto_ingresado_cents::float8 "impuestoIngresadoCents",impuesto_computable_cents::float8 "impuestoComputableCents",pago_identificacion "pagoIdentificacion",entidad_pago_cuit "entidadPagoCuit" from imp_importacion_servicios where periodo=${periodo} and estado='vigente' order by fecha,id`);
      const extra:Record<string,string>={};if(adjustmentRows.length){const invalid=adjustmentRows.flatMap((row,index)=>validarAjuste(row as Ajuste).map(error=>`Ajuste ${index+1}: ${error}`));if(invalid.length)throw new HttpError(409,"Hay ajustes inválidos",invalid);const csv=csvAjustes(adjustmentRows as unknown as Ajuste[]);if(csv.debito)extra.IVA_SIMPLE_DEBITO=csv.debito;if(csv.restitucionDebito)extra.IVA_SIMPLE_RESTITUCION_DEBITO=csv.restitucionDebito;if(csv.credito)extra.IVA_SIMPLE_CREDITO=csv.credito;if(csv.restitucionCredito)extra.IVA_SIMPLE_RESTITUCION_CREDITO=csv.restitucionCredito;}if(servicioRows.length)extra.LIBRO_IVA_DIGITAL_IMPORTACION_SERVICIOS_CREDITO_FISCAL=archivoImportacionServicios(servicioRows as unknown as ImportacionServicio[]);
      const allFiles={...built.files,...extra};
      const fileSizes=Object.entries(allFiles).map(([name,content])=>({name,bytes:toAnsi(content).byteLength}));
      // Inyección de tamaños reservada a la suite HTTP: no se activa en una ejecución normal.
      if(process.env.RUN_FLOW_TESTS==="1"){
        const simulated=req.headers.get("X-Talon-Test-Export-Bytes");
        if(simulated!==null){const bytes=Number(simulated);if(!Number.isSafeInteger(bytes)||bytes<0)throw new HttpError(400,"Tamaño de prueba inválido");if(fileSizes.length)fileSizes[0].bytes=bytes;}
      }
      const blocked=bloqueoTamanoExportacion(fileSizes);if(blocked)throw new HttpError(413,blocked);
      const zip=makeZip(Object.entries(allFiles).filter(([,content])=>content.length>0).map(([name,content])=>({name:`${name}_${periodo}.${name.startsWith("IVA_SIMPLE")?"csv":"txt"}`,data:toAnsi(content)})));
      if(url.searchParams.get("formato")==="zip") return new Response(new Uint8Array(zip),{headers:{"Content-Type":"application/zip","Content-Disposition":`attachment; filename="libro-iva-digital-${periodo}.zip"`,"Cache-Control":"private, no-store"}});
      const spreadsheetRows=receipts.map(r=>({Libro:r.libro,Fecha:String(r.fecha_cbte).slice(0,10),Tipo:r.tipo_cbte,"Punto de venta":r.punto_venta,Número:r.numero_desde,Contraparte:r.denominacion,Moneda:r.moneda,"Tipo de cambio":Number(r.tipo_cambio),Total:convertirCentsAPesos(Number(r.total_cents),Number(r.tipo_cambio))/100,"Crédito fiscal":convertirCentsAPesos(Number(r.credito_fiscal_computable_cents),Number(r.tipo_cambio))/100}));
      const csv=`\uFEFFLibro;Fecha;Tipo;Punto de venta;Número;Contraparte;Moneda;Tipo de cambio;Total;Crédito fiscal\r\n${spreadsheetRows.map(r=>Object.entries(r).map(([key,v])=>`"${((key==="Tipo"||key==="Punto de venta"||key==="Número")?String(v):typeof v==="number"?v.toFixed(2).replace(".",","):String(v??"")).replaceAll('"','""')}"`).join(";")).join("\r\n")}${spreadsheetRows.length?"\r\n":""}`;
      const workbook=XLSX.utils.book_new(); XLSX.utils.book_append_sheet(workbook,XLSX.utils.json_to_sheet(spreadsheetRows),"Libro IVA");
      const avisos=[...built.avisos,...(esquema.aviso?[esquema.aviso]:[]),...avisosTamanoExportacion(fileSizes,zip.byteLength)];
      if(empresa.condicionIva==="exento")avisos.push("NO VERIFICADO: el diseño oficial para sujetos exentos no pudo obtenerse; se conserva el LID común.");
      return ok({periodo,flujo:esquema.flujo,files:allFiles,avisos,zipBase64:zip.toString("base64"),csv,xlsxBase64:XLSX.write(workbook,{type:"base64",bookType:"xlsx"})});
    });
  }
  if(method==="GET"&&resource==="liquidacion"){
    const auth=await requirePermission("impuestos","ver"); const periodo=parsePeriodo(url);
    return withImpuestos(auth,url,async(tx,empresa)=>{
      const esquema=await flujoFiscal(tx,empresa,periodo);
      const [liq]=await tx.execute<Record<string,unknown>>(sql`select * from imp_liquidaciones where periodo=${periodo}`);
      if(!liq) return ok({liquidacion:null,items:[],flujo:esquema.flujo,avisos:esquema.aviso?[esquema.aviso]:[]});
      const items=await tx.execute(sql`select rubro,concepto,importe_cents::float8 "importeCents",origen from imp_liquidacion_items where liquidacion_id=${liq.id as string}::uuid order by posicion`);
      return ok({liquidacion:liq,items,flujo:esquema.flujo,avisos:esquema.aviso?[esquema.aviso]:[]});
    });
  }
  if(method==="POST"&&resource==="liquidacion"){
    const auth=await requirePermission("impuestos","crear"); const body=await readBody(req,confirmSchema);
    return withImpuestos(auth,url,async(tx,empresa)=>{
      if(!puedeLiquidarF2002(empresa.condicionIva)) throw new HttpError(409,"La liquidación de IVA corresponde a responsables inscriptos");
      const esquema=await flujoFiscal(tx,empresa,body.periodo);
      const rows=await tx.execute<{libro:"ventas"|"compras";signo:number;iva:string;neto:string;credito:string;percep:string;tipoCambio:number;destino:string;exento:string;noGravado:string}>(sql`
        select c.libro,t.signo,coalesce(a.iva_cents,0)::text iva,coalesce(a.neto_cents,0)::text neto,
          (case when coalesce(sum(a.iva_cents) over(partition by c.id),0)=0 then c.credito_fiscal_computable_cents else round(coalesce(a.iva_cents,0)::numeric*c.credito_fiscal_computable_cents/sum(a.iva_cents) over(partition by c.id)) end)::text credito,
          (case when row_number() over(partition by c.id order by a.id nulls first)=1 then c.percep_iva_cents else 0 end)::text percep,
          c.tipo_cambio::float8 "tipoCambio",c.destino_credito destino,
          (case when row_number() over(partition by c.id order by a.id nulls first)=1 then c.exento_cents else 0 end)::text exento,
          (case when row_number() over(partition by c.id order by a.id nulls first)=1 then c.neto_no_gravado_cents else 0 end)::text "noGravado"
        from imp_comprobantes c join imp_tipos_comprobante t on t.codigo=c.tipo_cbte left join imp_comprobante_alicuotas a on a.comprobante_id=c.id
        where c.periodo=${body.periodo} and c.estado='vigente'`);
      const [actual]=await tx.execute<{estado:string}>(sql`select estado from imp_liquidaciones where periodo=${body.periodo}`);
      if(actual?.estado==="confirmada") throw new HttpError(409,PERIODO_CONFIRMADO);
      const anterior=periodoAnterior(body.periodo); const avisos:string[]=esquema.aviso?[esquema.aviso]:[];
      const [prev]=await tx.execute<{totales:Record<string,unknown>}>(sql`select totales from imp_liquidaciones where periodo=${anterior} and estado='confirmada'`);
      const arrastre=prev?saldosQueArrastra(prev.totales):null;
      if(!prev) avisos.push(`No hay liquidación confirmada de ${fmtPeriodo(anterior)}: cargá a mano los saldos a favor del período anterior si corresponde.`);
      else if(arrastre?.formatoViejo) avisos.push(`La liquidación de ${fmtPeriodo(anterior)} es de una versión anterior: su saldo a favor se tomó como libre disponibilidad. Revisalo.`);
      const tecnicoManual=body.saldoTecnicoAnteriorCents!=null&&body.saldoTecnicoAnteriorCents!==(arrastre?.saldoTecnicoAnteriorCents??0);
      const libreManual=body.saldoLibreAnteriorCents!=null&&body.saldoLibreAnteriorCents!==(arrastre?.saldoLibreAnteriorCents??0);
      if(prev&&(tecnicoManual||libreManual)) avisos.push(`Los saldos anteriores cargados a mano difieren de la liquidación confirmada de ${fmtPeriodo(anterior)}.`);
      const certificados=await tx.execute<{tipo:"retencion"|"percepcion";total:number}>(sql`select tipo,sum(importe_cents)::float8 total from imp_retenciones_percepciones where periodo_computo=${body.periodo} and estado='vigente' group by tipo`);
      const automatico=(tipo:"retencion"|"percepcion")=>certificados.find(r=>r.tipo===tipo)?.total??0;
      const ventas=rows.filter(r=>r.libro==="ventas");
      const gravadas=ventas.reduce((n,r)=>n+convertirCentsAPesos(Number(r.neto),r.tipoCambio)*r.signo,0);
      const exentas=ventas.reduce((n,r)=>n+convertirCentsAPesos(Number(r.exento),r.tipoCambio)*r.signo,0);
      const noGravadas=ventas.reduce((n,r)=>n+convertirCentsAPesos(Number(r.noGravado),r.tipoCambio)*r.signo,0);
      const [prorrateoConfig]=await tx.execute<{coeficiente:number|null}>(sql`select coeficiente_prorrateo_bps coeficiente from imp_config limit 1`);
      const coeficienteUsado=prorrateoConfig?.coeficiente??coeficienteProrrateo(gravadas,exentas,noGravadas);
      const ajustes={...body,retencionesCents:body.retencionesCents+automatico("retencion"),percepcionesCents:body.percepcionesCents+automatico("percepcion"),saldoTecnicoAnteriorCents:body.saldoTecnicoAnteriorCents??arrastre?.saldoTecnicoAnteriorCents??0,saldoLibreAnteriorCents:body.saldoLibreAnteriorCents??arrastre?.saldoLibreAnteriorCents??0};
      const adjustmentRows=await tx.execute<{lado:"debito"|"credito";clase:"genera"|"restituye";facturado:number;computable:number}>(sql`select lado,clase,impuesto_facturado_cents::float8 facturado,impuesto_computable_cents::float8 computable from imp_iva_ajustes where periodo=${body.periodo} and estado='vigente'`);
      const serviceRows=await tx.execute<{computable:number}>(sql`select impuesto_computable_cents::float8 computable from imp_importacion_servicios where periodo=${body.periodo} and estado='vigente'`);
      const lineas=[...rows.map(r=>({libro:r.libro,signo:r.signo as 1|-1,ivaCents:Number(r.iva),creditoComputableCents:r.libro==="compras"?(r.destino==="directo_exento"?0:r.destino==="prorratea"?aplicarProrrateo(Number(r.iva),coeficienteUsado):Number(r.credito)):undefined,percepIvaCents:Number(r.percep),tipoCambio:Number(r.tipoCambio)})),...adjustmentRows.map(r=>({libro:r.lado==="debito"?"ventas" as const:"compras" as const,signo:(r.clase==="genera"?1:-1) as 1|-1,ivaCents:r.facturado,creditoComputableCents:r.lado==="credito"?(r.clase==="restituye"?r.facturado:r.computable):undefined,tipoCambio:1})),...serviceRows.map(r=>({libro:"compras" as const,signo:1 as const,ivaCents:r.computable,creditoComputableCents:r.computable,tipoCambio:1}))];
      const totals={...calcularLiquidacion(lineas,ajustes),coeficienteProrrateoBps:coeficienteUsado,periodoAnterior:anterior,saldosAnterioresAutomaticos:Boolean(prev)&&!tecnicoManual&&!libreManual};
      const items=itemsLiquidacion(totals,{saldoTecnicoAnterior:tecnicoManual||(!prev&&ajustes.saldoTecnicoAnteriorCents>0),saldoLibreAnterior:libreManual||(!prev&&ajustes.saldoLibreAnteriorCents>0),percepciones:body.percepcionesCents>0,retenciones:body.retencionesCents>0,pagosCuenta:body.pagosCuentaCents>0,seguridadSocial:body.seguridadSocialCents>0},{percepcionesCents:automatico("percepcion"),retencionesCents:automatico("retencion")});
      const state=body.confirmar?"confirmada":"borrador"; const snapshot=body.confirmar?JSON.stringify({totals,inputs:ajustes,items}):null;
      let saved:Record<string,unknown>;
      try{
        [saved]=await tx.execute<Record<string,unknown>>(sql`insert into imp_liquidaciones(company_id,periodo,estado,totales,snapshot,confirmada_por,confirmada_at,created_by)
        values(${auth.company.companyId},${body.periodo},${state},${JSON.stringify(totals)}::jsonb,${snapshot}::jsonb,${body.confirmar?auth.user.id:null}::uuid,${body.confirmar?new Date().toISOString():null}::timestamptz,${auth.user.id}::uuid)
        on conflict(company_id,empresa_cliente_id,periodo) do update set estado=excluded.estado,totales=excluded.totales,snapshot=excluded.snapshot,confirmada_por=excluded.confirmada_por,confirmada_at=excluded.confirmada_at,updated_at=now() returning *`);
      }catch(error){ if((error as {code?:string}).code==="55000"||(error as {cause?:{code?:string}}).cause?.code==="55000") throw new HttpError(409,PERIODO_CONFIRMADO); throw error; }
      await tx.execute(sql`delete from imp_liquidacion_items where liquidacion_id=${saved.id as string}::uuid`);
      for(const [posicion,item] of items.entries()) await tx.execute(sql`insert into imp_liquidacion_items(company_id,liquidacion_id,rubro,concepto,importe_cents,origen,posicion)
        values(${auth.company.companyId},${saved.id as string}::uuid,${item.rubro},${item.concepto},${item.importeCents},${item.origen},${posicion})`);
      if(body.confirmar)await writeAudit(tx,{companyId:auth.company.companyId,userId:auth.user.id,action:"impuestos.liquidacion.confirmar",entity:"imp_liquidacion",entityId:saved.id as string,summary:`Liquidación confirmada ${body.periodo}`,metadata:{periodo:body.periodo,flujo:esquema.flujo}});
      return ok({...saved,flujo:esquema.flujo,items,avisos});
    },"exclusive");
  }
  if(method==="POST"&&resource==="reabrir"){
    const auth=await requirePermission("impuestos","anular"); const body=await readBody(req,reopenSchema);
    return withImpuestos(auth,url,async tx=>{const [row]=await tx.execute<{warning:boolean}>(sql`select imp_reabrir_periodo(${body.periodo},${body.motivo}) warning`);return ok({reopened:true,saldoPosteriorDesactualizado:row.warning});},"exclusive");
  }
  throw new HttpError(404,"No existe esa ruta de impuestos");
}

// @vitest-environment happy-dom
import {cleanup,fireEvent,render,waitFor} from '@testing-library/react';
import {afterEach,expect,it,vi} from 'vitest';
import {LiquidacionScreen} from './liquidacion-screen';

const calls:unknown[][]=[];
vi.mock('@/lib/api/client',()=>({apiSend:(...args:unknown[])=>{calls.push(args);return Promise.resolve(args[1]==='GET'?{liquidacion:null,items:[]}:{estado:'borrador',items:[],avisos:[]})}}));
afterEach(()=>{cleanup();calls.length=0});

it('calcula el período controlado por IVA Simple sin un segundo selector',async()=>{
 const view=render(<LiquidacionScreen empresaId="ficticia" ivaSimple periodo="202603"/>);
 expect(view.queryByLabelText('Período')).toBeNull();
 expect(view.getByRole('link',{name:'Imprimir'}).getAttribute('href')).toBe('/impuestos/liquidacion/202603?empresa=ficticia');
 fireEvent.click(view.getByRole('button',{name:'Calcular borrador'}));
 await waitFor(()=>expect(calls).toContainEqual(['/api/impuestos/liquidacion?empresa=ficticia','POST',expect.objectContaining({periodo:'202603',confirmar:false})]));
});

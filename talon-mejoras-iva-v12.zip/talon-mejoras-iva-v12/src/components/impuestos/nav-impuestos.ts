export type GrupoImpuestos = {
  label: string;
  items: { key: string; label: string; path: string }[];
};

/** Navegación fiscal compartida entre el sidebar y el resumen de empresa. */
export const ARBOL_IMPUESTOS: GrupoImpuestos[] = [
  { label: "Compras", items: [
    { key: "compras", label: "Listado", path: "compras" },
    { key: "carga-compras", label: "Carga manual", path: "carga-compras" },
    { key: "importar", label: "Importar", path: "importar" },
    { key: "certificados", label: "Retenciones y percepciones sufridas", path: "certificados" },
  ] },
  { label: "Ventas", items: [
    { key: "ventas", label: "Listado", path: "ventas" },
    { key: "carga-ventas", label: "Carga manual", path: "carga-ventas" },
    { key: "retenciones-practicadas", label: "Retenciones practicadas", path: "retenciones-practicadas" },
  ] },
  { label: "IVA", items: [
    { key: "libro-iva", label: "Libro de IVA", path: "libro-iva?libro=compras" },
    { key: "liquidacion", label: "Liquidación", path: "liquidacion" },
  ] },
  { label: "Configuración", items: [{ key: "configuracion", label: "Configuración", path: "configuracion" }] },
];

export function enlacesArbolImpuestos(empresaId: string) {
  const base = `/impuestos/empresas/${encodeURIComponent(empresaId)}`;
  return ARBOL_IMPUESTOS.map((group) => ({ ...group, items: group.items.map((item) => ({ ...item, href: `${base}/${item.path}` })) }));
}

export function grupoDeSeccion(seccion: string | undefined) {
  return ARBOL_IMPUESTOS.find((group) => group.items.some((item) => item.key === seccion))?.label;
}

// @vitest-environment happy-dom
import {cleanup,render,waitFor} from '@testing-library/react';
import {afterEach,expect,it,vi} from 'vitest';
import {LibroImpresion,LiquidacionImpresion} from './impresion-impuestos';

const calls:unknown[][]=[];
vi.mock('@/lib/api/client',()=>({apiSend:(...args:unknown[])=>{calls.push(args);return Promise.resolve({items:[],liquidacion:null})}}));
afterEach(()=>{cleanup();calls.length=0});

it('reenvía empresa al API desde ambas impresiones',async()=>{
 render(<><LibroImpresion libro="compras" periodo="202603" empresa="ficticia"/><LiquidacionImpresion periodo="202603" empresa="ficticia"/></>);
 await waitFor(()=>expect(calls).toContainEqual(['/api/impuestos/libro/compras?periodo=202603&empresa=ficticia','GET']));
 expect(calls).toContainEqual(['/api/impuestos/liquidacion?periodo=202603&empresa=ficticia','GET']);
});

// @vitest-environment happy-dom
import {cleanup,fireEvent,render,waitFor} from '@testing-library/react';
import {afterEach,expect,it,vi} from 'vitest';
import {LibroScreen} from './libro-screen';
vi.mock('next/navigation',()=>({useSearchParams:()=>new URLSearchParams('libro=compras')}));
vi.mock('next/link',()=>({default:({href,children,...props}:React.ComponentProps<'a'>)=><a href={href} {...props}>{children}</a>}));
const calls:unknown[][]=[];
vi.mock('@/lib/api/client',()=>({apiSend:(...args:unknown[])=>{calls.push(args);return Promise.resolve({items:[]})}}));
afterEach(()=>{cleanup();calls.length=0});
it('muestra las pestañas y el encabezado del libro solicitado',()=>{const view=render(<LibroScreen empresaId="ficticia" libro="compras"/>);expect(view.getByRole('heading',{name:'Libro IVA Compras'})).toBeTruthy();expect(view.getByRole('tab',{name:'Compras'}).getAttribute('aria-selected')).toBe('true');expect(view.getByRole('tab',{name:'Ventas'}).getAttribute('href')).toContain('libro=ventas')});
it('envía empresa al traer e imprimir desde una ficha',async()=>{const view=render(<LibroScreen empresaId="ficticia" libro="compras"/>);fireEvent.click(view.getByRole('button',{name:'Traer de Talón'}));await waitFor(()=>expect(calls.some(call=>call[0]==='/api/impuestos/traer-de-talon?empresa=ficticia'&&call[1]==='POST')).toBe(true));expect(view.getByRole('link',{name:'Imprimir'}).getAttribute('href')).toContain('?empresa=ficticia')});

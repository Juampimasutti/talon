import {SECCIONES_IMPUESTOS,type SeccionImpuestos} from './empresa-types';
export type Miga={label:string;href:string};
/** Una única ruta para el breadcrumb y el enlace Volver. */
export function rutaImpuestos(id:string,nombre:string,seccion:SeccionImpuestos|undefined,params:URLSearchParams){
 const base=`/impuestos/empresas/${encodeURIComponent(id)}`;
 const requested=params.get('libro');
 const libro:'compras'|'ventas'=requested==='compras'||(!requested&&params.get('volver')?.startsWith(`${base}/compras`))?'compras':'ventas';
 const parent:SeccionImpuestos|undefined=seccion==='carga-compras'||seccion==='certificados'?'compras':seccion==='carga-ventas'||seccion==='retenciones-practicadas'?'ventas':seccion==='libro-iva'?libro:seccion==='importar'&&params.get('origen')==='ventas'?'ventas':seccion==='importar'?'compras':undefined;
 const listBack=params.get('volver');
 const listado=listBack&&/^\/impuestos(?:\?(?:[\w%=&-]+))?$/.test(listBack)?listBack:'/impuestos';
 const crumbs:Miga[]=[{label:'Empresas',href:listado},{label:nombre,href:base}];
 if(parent)crumbs.push({label:SECCIONES_IMPUESTOS.find(x=>x.key===parent)!.label,href:`${base}/${parent}`});
 if(seccion)crumbs.push({label:seccion==='libro-iva'?`Libro IVA ${libro==='compras'?'Compras':'Ventas'}`:SECCIONES_IMPUESTOS.find(x=>x.key===seccion)!.label,href:`${base}/${seccion}`});
 const back=params.get('volver');
 if(seccion&&back&&parent&&back.startsWith(`${base}/${parent}?`))crumbs[crumbs.length-2].href=back;
 return {crumbs,volver:crumbs.at(-2)!.href,parent,libro};
}

// @vitest-environment happy-dom
import {cleanup,render,within} from '@testing-library/react';
import {afterEach,expect,it,vi} from 'vitest';
import {EmpresaDetailScreen} from './empresa-detail-screen';
const detail={empresa:{id:'ficticia',nombre:'Empresa Ficticia',razonSocial:'Empresa Ficticia SA',cuit:'20123456786',condicionIva:'ri'},counts:{compras:0,ventas:0,periodos:0,liquidaciones:0},vencimientos:[],config:{esquemaIva:'iva_simple'},puntosVenta:[],actividades:[]};
vi.mock('@tanstack/react-query',()=>({useQuery:()=>({data:detail,isLoading:false}),useQueryClient:()=>({invalidateQueries:vi.fn()})}));
let queryString='';
vi.mock('next/navigation',()=>({useRouter:()=>({push:vi.fn()}),useSearchParams:()=>new URLSearchParams(queryString)}));
vi.mock('./empresa-tax-config',()=>({EmpresaTaxConfig:()=>null}));
vi.mock('./certificados-screen',()=>({CertificadosScreen:()=>null}));
vi.mock('./comprobante-manual-screen',()=>({ComprobanteManualScreen:()=>null}));
vi.mock('./libro-screen',()=>({LibroScreen:()=>null}));
vi.mock('./liquidacion-screen',()=>({LiquidacionScreen:()=>null}));
vi.mock('./exportar-screen',()=>({ExportarScreen:()=>null}));
vi.mock('./iva-simple-screen',()=>({IvaSimpleScreen:()=>null}));
vi.mock('./retenciones-practicadas-screen',()=>({RetencionesPracticadasScreen:()=>null}));
vi.mock('./importar-screen',()=>({ImportarScreen:()=>null}));
vi.mock('next/link',()=>({default:({href,children,...props}:React.ComponentProps<'a'>)=><a href={href} {...props}>{children}</a>}));
afterEach(cleanup);
it('muestra el resumen con cuatro grupos y sin Retenciones suelto',()=>{const view=render(<EmpresaDetailScreen id="ficticia"/>);const nav=view.getByRole('navigation',{name:'Áreas de la empresa'});expect(within(nav).getAllByRole('heading').map(x=>x.textContent)).toEqual(['Compras','Ventas','IVA','Configuración']);expect(view.queryByRole('heading',{name:'Retenciones'})).toBeNull();expect(within(nav).getByRole('link',{name:'Retenciones y percepciones sufridas'})).toBeTruthy();expect(within(nav).getByRole('link',{name:'Retenciones practicadas'})).toBeTruthy();expect(view.getByText('Períodos')).toBeTruthy();expect(view.getByText('Liquidaciones')).toBeTruthy();expect(view.queryByRole('navigation',{name:'Secciones de la empresa'})).toBeNull()});
it('no muestra la botonera de diez accesos en subpantallas',()=>{const view=render(<EmpresaDetailScreen id="ficticia" seccion="compras"/>);expect(view.queryByRole('navigation',{name:'Áreas de la empresa'})).toBeNull();expect(view.queryByRole('navigation',{name:'Secciones de la empresa'})).toBeNull();expect(view.getByRole('link',{name:'← Volver'}).getAttribute('href')).toBe('/impuestos/empresas/ficticia')});

it.each([
 ['carga-compras','', '/impuestos/empresas/ficticia/compras'],
 ['carga-ventas','', '/impuestos/empresas/ficticia/ventas'],
 ['libro-iva','libro=compras', '/impuestos/empresas/ficticia/compras'],
 ['libro-iva','libro=ventas', '/impuestos/empresas/ficticia/ventas'],
 ['importar','origen=ventas', '/impuestos/empresas/ficticia/ventas'],
 ['liquidacion','', '/impuestos/empresas/ficticia'],
 ['configuracion','', '/impuestos/empresas/ficticia'],
 ['certificados','', '/impuestos/empresas/ficticia/compras'],
 ['retenciones-practicadas','', '/impuestos/empresas/ficticia/ventas'],
] as const)('la pantalla %s usa el penúltimo breadcrumb en Volver',(seccion,query,expected)=>{
 queryString=query;
 const view=render(<EmpresaDetailScreen id="ficticia" seccion={seccion}/>);
 const route=view.getByRole('navigation',{name:'Ruta de navegación'});
 const links=within(route).getAllByRole('link');
 expect(links.at(-1)?.getAttribute('href')).toBe(expected);
 expect(view.getByRole('link',{name:'← Volver'}).getAttribute('href')).toBe(expected);
 cleanup();queryString='';
});

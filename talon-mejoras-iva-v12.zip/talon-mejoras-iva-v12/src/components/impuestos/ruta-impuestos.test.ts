import {expect,it} from 'vitest';
import {rutaImpuestos} from './ruta-impuestos';
import type {SeccionImpuestos} from './empresa-types';
const id='ficticia',nombre='Empresa Ficticia',base=`/impuestos/empresas/${id}`;
it.each<[SeccionImpuestos|undefined,string,string]>([
 ['carga-compras','',`${base}/compras`],['carga-ventas','',`${base}/ventas`],['libro-iva','libro=compras',`${base}/compras`],['libro-iva','libro=ventas',`${base}/ventas`],['importar','',`${base}/compras`],['importar','origen=ventas',`${base}/ventas`],['liquidacion','',base],['configuracion','',base],['certificados','',`${base}/compras`],['retenciones-practicadas','',`${base}/ventas`],[undefined,'','/impuestos'],
])('Volver desde %s (%s) apunta al penúltimo nivel', (seccion,query,expected)=>{const ruta=rutaImpuestos(id,nombre,seccion,new URLSearchParams(query));expect(ruta.volver).toBe(expected);expect(ruta.crumbs.at(-2)?.href).toBe(expected)});
it('deduce Compras desde el enlace de origen si falta libro',()=>{const ruta=rutaImpuestos(id,nombre,'libro-iva',new URLSearchParams({volver:`${base}/compras?periodo=202610`}));expect(ruta.libro).toBe('compras');expect(ruta.volver).toBe(`${base}/compras?periodo=202610`)});
it('conserva el filtro del padre y el listado',()=>{const parent=`${base}/compras?periodo=202610`;const ruta=rutaImpuestos(id,nombre,'carga-compras',new URLSearchParams({volver:parent}));expect(ruta.volver).toBe(parent);expect(rutaImpuestos(id,nombre,undefined,new URLSearchParams({volver:'/impuestos?condicion=ri'})).volver).toBe('/impuestos?condicion=ri')});

import {expect,it} from 'vitest';
import {enlacesArbolImpuestos,grupoDeSeccion} from './nav-impuestos';

it('define el árbol completo y los destinos de cada sección',()=>{
 const tree=enlacesArbolImpuestos('empresa-ficticia');
 expect(tree.map(group=>group.label)).toEqual(['Compras','Ventas','IVA','Configuración']);
 expect(tree.flatMap(group=>group.items.map(item=>item.href))).toEqual([
  '/impuestos/empresas/empresa-ficticia/compras','/impuestos/empresas/empresa-ficticia/carga-compras','/impuestos/empresas/empresa-ficticia/importar','/impuestos/empresas/empresa-ficticia/certificados',
  '/impuestos/empresas/empresa-ficticia/ventas','/impuestos/empresas/empresa-ficticia/carga-ventas','/impuestos/empresas/empresa-ficticia/retenciones-practicadas',
  '/impuestos/empresas/empresa-ficticia/libro-iva?libro=compras','/impuestos/empresas/empresa-ficticia/liquidacion','/impuestos/empresas/empresa-ficticia/configuracion',
 ]);
 expect(grupoDeSeccion('certificados')).toBe('Compras');
 expect(grupoDeSeccion('retenciones-practicadas')).toBe('Ventas');
 expect(grupoDeSeccion('liquidacion')).toBe('IVA');
});

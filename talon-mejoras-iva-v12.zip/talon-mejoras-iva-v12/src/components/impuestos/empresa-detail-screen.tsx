"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useSearchParams } from "next/navigation";
import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apiGet, apiSend } from "@/lib/api/client";
import { formatCuit } from "@/lib/fiscal/cuit";
import { rememberEmpresa } from "@/lib/impuestos/seleccion";
import { Button } from "@/components/ui/button";
import { EmpresaTaxConfig } from "./empresa-tax-config";
import { CertificadosScreen } from "./certificados-screen";
import { ComprobanteManualScreen } from "./comprobante-manual-screen";
import { LibroScreen } from "./libro-screen";
import { LiquidacionScreen } from "./liquidacion-screen";
import { ExportarScreen } from "./exportar-screen";
import { IvaSimpleScreen } from "./iva-simple-screen";
import { RetencionesPracticadasScreen } from "./retenciones-practicadas-screen";
import { ImportarScreen } from "./importar-screen";
import { type EmpresaImpositivaDetalle, type SeccionImpuestos } from "./empresa-types";
import {rutaImpuestos} from "./ruta-impuestos";
import { enlacesArbolImpuestos } from "./nav-impuestos";

export function EmpresaDetailScreen({ id, seccion }: { id: string; seccion?: SeccionImpuestos }) {
  const router = useRouter();
  const searchParams=useSearchParams();
  const queryClient = useQueryClient();
  const query = useQuery({ queryKey: ["impuestos-empresa", id], queryFn: () => apiGet<EmpresaImpositivaDetalle>(`/api/impuestos/empresas/${id}`) });
  useEffect(() => rememberEmpresa(id), [id]);
  if (query.isLoading) return <main className="p-6 text-sm text-muted-foreground">Cargando empresa…</main>;
  if (!query.data) return <main className="p-6 text-sm text-destructive">{query.error instanceof Error ? query.error.message : "No se encontró la empresa"}</main>;
  const { empresa, counts } = query.data;
  const title = seccion?rutaImpuestos(id,empresa.nombre,seccion,new URLSearchParams(searchParams.toString())).crumbs.at(-1)?.label:undefined;

  async function deactivate() {
    if (!window.confirm(`¿Dar de baja ${empresa.nombre}? Sus datos fiscales se conservarán.`)) return;
    await apiSend(`/api/impuestos/empresas/${id}`, "DELETE");
    await queryClient.invalidateQueries({ queryKey: ["impuestos-empresas"] });
    router.push("/impuestos");
  }

  const base=`/impuestos/empresas/${id}`;
  const ruta=rutaImpuestos(id,empresa.nombre,seccion,new URLSearchParams(searchParams.toString()));
  const source=seccion?`${base}/${seccion}${searchParams.size?`?${searchParams.toString()}`:''}`:base;
  const child=(path:string,query?:Record<string,string>)=>{const params=new URLSearchParams({...query,volver:source});return `${base}/${path}?${params.toString()}`};
  const groups=enlacesArbolImpuestos(id).map(group=>[group.label,group.items.map(item=>[item.href,item.label] as [string,string])] as [string,[string,string][]]);
  return <main className="space-y-4 p-4 sm:p-6">
    <nav aria-label="Ruta de navegación" className="flex flex-wrap items-center gap-2 text-sm">{ruta.crumbs.map((item,index)=><span key={item.href} className="flex items-center gap-2">{index>0&&<span>›</span>}{index===ruta.crumbs.length-1?<span aria-current="page">{item.label}</span>:<Link href={item.href} className="underline">{item.label}</Link>}</span>)}</nav>
    <Link className="inline-block text-sm text-primary underline" href={ruta.volver}>← Volver</Link>
    <header className="rounded border bg-card p-4">
      <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Empresa seleccionada</p>
      <div className="mt-1 flex flex-wrap items-start justify-between gap-3">
        <div><h1 className="text-xl font-semibold">{empresa.nombre}</h1><p className="text-sm text-muted-foreground">{empresa.razonSocial} · {formatCuit(empresa.cuit)}</p></div>
        <div className="flex gap-2"><Link className="inline-flex h-8 items-center rounded-lg border px-3 text-sm" href={`/impuestos/empresas/${id}/editar`}>Editar</Link>{!seccion&&<Button variant="destructive" onClick={deactivate}>Dar de baja</Button>}</div>
      </div>
    </header>
    {!seccion ? <><nav aria-label="Áreas de la empresa" className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{groups.map(([group,links])=><section key={group} className="rounded border bg-card p-3"><h2 className="font-semibold">{group}</h2><InternalLinks links={links}/></section>)}</nav><section className="grid gap-2 text-sm sm:grid-cols-4"><Stat label="Compras" value={counts.compras} /><Stat label="Ventas" value={counts.ventas} /><Stat label="Períodos" value={counts.periodos} /><Stat label="Liquidaciones" value={counts.liquidaciones} /></section>{query.data.vencimientos.length ? <section className="rounded border bg-card p-4"><h2 className="font-semibold">Vencimientos publicados</h2><ul className="mt-2 divide-y text-sm">{query.data.vencimientos.map(item=><li key={`${item.obligacion}-${item.periodo}`} className={`flex justify-between gap-3 py-2 ${String(item.fecha).slice(0,10)<new Date().toISOString().slice(0,10)&&item.estado!=="cerrado"?"bg-red-50 text-red-800":""}`}><span>{item.obligacion.replaceAll("_"," ")} · {item.periodo.slice(4)}/{item.periodo.slice(0,4)} · {item.estado}</span><time>{String(item.fecha).slice(0,10).split("-").reverse().join("/")}</time></li>)}</ul></section>:null}</> :
      <section className="space-y-4 rounded border bg-card p-4">
        <h2 className="font-semibold">{title}</h2>
        {seccion === "configuracion" ? <EmpresaTaxConfig id={id} data={query.data} /> : seccion === "certificados" ? <CertificadosScreen empresaId={id} /> : seccion === "retenciones-practicadas" ? <RetencionesPracticadasScreen empresaId={id}/>:seccion === "importar"?<ImportarScreen empresaId={id}/>:seccion === "carga-ventas" ? <ComprobanteManualScreen empresaId={id} libro="ventas" condicionIva={empresa.condicionIva} /> : seccion === "carga-compras" ? <ComprobanteManualScreen empresaId={id} libro="compras" condicionIva={empresa.condicionIva} /> : seccion==="libro-iva"?<><LibroScreen empresaId={id} libro={ruta.libro}/><ExportarScreen empresaId={id}/></>:seccion==="liquidacion"?(empresa.condicionIva==="monotributo"?<p role="status" className="rounded border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">Esta empresa es Monotributo; IVA Simple corresponde a responsables inscriptos. Revisá su configuración antes de liquidar.</p>:query.data.config.esquemaIva==="iva_simple"?<IvaSimpleScreen empresaId={id}/>:<LiquidacionScreen empresaId={id}/>): <>
          <p className="text-sm text-muted-foreground">Los datos de esta sección corresponden exclusivamente a {empresa.nombre}.</p>
          {seccion === "ventas" ? <InternalLinks links={[
            [child("libro-iva",{libro:"ventas"}), "Libro IVA Ventas"],
            [child("carga-ventas"), "Carga manual de ventas"],
            [child("importar",{origen:"ventas"}), "Importar"],
          ]} /> : null}
          {seccion === "compras" ? <InternalLinks links={[[child("libro-iva",{libro:"compras"}), "Libro IVA Compras"],[child("carga-compras"), "Carga manual de compras"],[child("importar"),"Importar"]]} /> : null}
          {seccion === "ventas" ? <div className="grid gap-2 text-sm sm:grid-cols-2"><Stat label="Comprobantes de ventas" value={counts.ventas} /><Stat label="Liquidaciones" value={counts.liquidaciones} /></div> :
            seccion === "compras" ? <div className="grid gap-2 text-sm sm:grid-cols-2"><Stat label="Comprobantes de compras" value={counts.compras} /></div> :
              <div className="grid gap-2 text-sm sm:grid-cols-4"><Stat label="Compras" value={counts.compras} /><Stat label="Ventas" value={counts.ventas} /><Stat label="Períodos" value={counts.periodos} /><Stat label="Liquidaciones" value={counts.liquidaciones} /></div>}
        </>}
      </section>}
  </main>;
}

function InternalLinks({ links }: { links: [string, string][] }) {
  return <nav className="flex flex-wrap gap-2" aria-label="Navegación de la sección">{links.map(([href, label]) => <Link key={href} href={href} className="inline-flex h-8 items-center rounded-lg border px-3 text-sm text-primary hover:bg-muted">{label}</Link>)}</nav>;
}

function Stat({ label, value }: { label: string; value: number }) {
  return <div className="rounded border p-3"><span className="block text-xs text-muted-foreground">{label}</span><strong className="text-lg">{value}</strong></div>;
}

// @vitest-environment happy-dom
import {cleanup,fireEvent,render} from '@testing-library/react';
import {afterEach,expect,it,vi} from 'vitest';
import {IvaSimpleScreen} from './iva-simple-screen';

vi.mock('@tanstack/react-query',()=>({useQuery:()=>({data:{alicuotas:[],certificados:[],avisos:[]}})}));
vi.mock('./iva-ajustes',()=>({IvaAjustes:()=>null}));
vi.mock('./liquidacion-screen',()=>({LiquidacionScreen:({periodo}:{periodo:string})=><output data-testid="liquidacion">{periodo}</output>}));
vi.mock('./exportar-screen',()=>({ExportarScreen:({periodo}:{periodo:string})=><output data-testid="exportar">{periodo}</output>}));
afterEach(cleanup);

it('propaga un único período a liquidación y exportación',()=>{
 const view=render(<IvaSimpleScreen empresaId="ficticia"/>);
 fireEvent.change(view.getByLabelText('Período IVA Simple'),{target:{value:'202603'}});
 expect(view.getByTestId('liquidacion').textContent).toBe('202603');
 expect(view.getByTestId('exportar').textContent).toBe('202603');
});

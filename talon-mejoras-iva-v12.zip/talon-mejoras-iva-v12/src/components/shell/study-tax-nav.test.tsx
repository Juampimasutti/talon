// @vitest-environment happy-dom
import {cleanup,render,within} from '@testing-library/react';
import {afterEach,expect,it,vi} from 'vitest';
import {empresaParaSidebar,StudyTaxNav} from './panel-shell';

vi.mock('next/link',()=>({default:({href,children,...props}:React.ComponentProps<'a'>)=><a href={href} {...props}>{children}</a>}));
afterEach(cleanup);

it('muestra el árbol completo y marca la sección activa',()=>{
 const view=render(<StudyTaxNav pathname="/impuestos/empresas/ficticia/certificados" close={vi.fn()} selected={{id:'ficticia',nombre:'Empresa Ficticia',razonSocial:'Empresa Ficticia SA',cuit:'20123456786',condicionIva:'ri',rubro:null,activa:true}}/>);
 const impuestos=view.getByText('Impuestos').closest('details')!;
 for(const [label,href] of [
  ['Listado','/impuestos/empresas/ficticia/compras'],['Carga manual','/impuestos/empresas/ficticia/carga-compras'],['Importar','/impuestos/empresas/ficticia/importar'],['Retenciones y percepciones sufridas','/impuestos/empresas/ficticia/certificados'],
  ['Retenciones practicadas','/impuestos/empresas/ficticia/retenciones-practicadas'],['Libro de IVA','/impuestos/empresas/ficticia/libro-iva?libro=compras'],['Liquidación','/impuestos/empresas/ficticia/liquidacion'],['Configuración','/impuestos/empresas/ficticia/configuracion'],
 ] as const)expect(impuestos.querySelector(`a[href="${href}"]`)?.textContent).toBe(label);
 expect(within(impuestos).getByRole('link',{name:'Retenciones y percepciones sufridas'}).getAttribute('aria-current')).toBe('page');
 expect(within(impuestos).getByText('Compras').closest('details')?.open).toBe(true);
});
it('conserva un árbol de carga al abrir una empresa fuera del listado cacheado',()=>{const empresa=empresaParaSidebar('ficticia',null,[],undefined);expect(empresa?.id).toBe('ficticia');expect(empresa?.nombre).toBe('Cargando empresa…');expect(empresa).not.toBeNull()});

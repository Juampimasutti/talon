import {expect,it} from 'vitest';
import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';

it('pasa PORT al servidor local y conserva 4317 como default',()=>{
 const source=readFileSync(resolve(process.cwd(),'scripts/local.ts'),'utf8');
 expect(source).toContain('process.env.PORT ?? "4317"');
});

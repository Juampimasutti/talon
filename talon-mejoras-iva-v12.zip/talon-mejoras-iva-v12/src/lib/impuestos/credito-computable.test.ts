import {expect,it} from 'vitest';
import {calcularLiquidacion} from './calculos';

it('liquida una compra con crédito fiscal computable parcial',()=>{
 const liquidacion=calcularLiquidacion([{libro:'compras',ivaCents:21_000,creditoComputableCents:5_000}]);
 expect(liquidacion.creditoComprasCents).toBe(5_000);
});

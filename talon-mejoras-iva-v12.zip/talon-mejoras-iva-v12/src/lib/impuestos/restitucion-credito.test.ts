import {expect,it} from 'vitest';
import {calcularLiquidacion} from './calculos';
import {validarAjuste} from './iva-simple-ajustes';

it('descuenta restitución de crédito sin completar el campo computable del CSV',()=>{
 const result=calcularLiquidacion([
  {libro:'compras',ivaCents:21_000,creditoComputableCents:21_000},
  {libro:'compras',ivaCents:2_100,creditoComputableCents:2_100,signo:-1},
 ]);
 expect(result.creditoComprasCents).toBe(18_900);
 expect(validarAjuste({lado:'credito',clase:'restituye',concepto:1,alicuotaCodigo:5,netoCents:10_000,impuestoFacturadoCents:2_100,impuestoComputableCents:0})).toEqual([]);
});

/** ARCA, "LID-Ajustes-y-otros-conceptos-para-generar-la-DJ", estructuras 1–4, págs. 2–6, PDF 29/05/2025. */
export type Ajuste={lado:"debito"|"credito";clase:"genera"|"restituye";actividad?:string|null;concepto?:number|null;tipoOperacion?:number|null;tipoSujeto?:number|null;alicuotaCodigo?:number|null;netoCents:number;impuestoFacturadoCents:number;impuestoComputableCents?:number;dacionPagoCents?:number;exentoCents?:number};
const rates=new Set([3,9,8,4,5,6]);
/** Los ejemplos oficiales de las págs. 3, 4, 5 y 6 usan decimales variables (21; 10,5). */
const money=(n:number)=>{const s=(n/100).toFixed(2).replace(".",",");return s.endsWith(",00")?s.slice(0,-3):s.endsWith("0")?s.slice(0,-1):s;};
export function validarAjuste(a:Ajuste){
  const errors:string[]=[];
  const has=(value:number|null|undefined)=>value!=null;
  const money=(value:number|undefined)=>value!==undefined&&Number.isSafeInteger(value)&&value>=0;
  if(a.lado==="debito"){
    if(!/^\d{6}$/.test(a.actividad??""))errors.push("actividad inválida");
    const exempt=a.clase==="genera"?3:2;
    const allowed=a.clase==="genera"?[1,2,3]:[1,2];
    if(!allowed.includes(a.tipoOperacion??0))errors.push("tipoOperacion inválido");
    if(a.tipoOperacion===exempt){
      if(!money(a.exentoCents))errors.push("exentoCents obligatorio");
      if(has(a.tipoSujeto))errors.push("tipoSujeto debe estar vacío");
      if(has(a.alicuotaCodigo))errors.push("alicuotaCodigo debe estar vacío");
      if(a.netoCents!==0)errors.push("netoCents debe estar vacío");
      if(a.impuestoFacturadoCents!==0)errors.push("impuestoFacturadoCents debe estar vacío");
      if((a.dacionPagoCents??0)!==0)errors.push("dacionPagoCents debe estar vacío");
    }else{
      if(![1,2,3].includes(a.tipoSujeto??0))errors.push("tipoSujeto obligatorio o inválido");
      if(!rates.has(a.alicuotaCodigo??0))errors.push("Código de alícuota inexistente");
      if(!money(a.netoCents))errors.push("netoCents obligatorio");
      if(!money(a.impuestoFacturadoCents))errors.push("impuestoFacturadoCents obligatorio");
      if((a.exentoCents??0)!==0)errors.push("exentoCents debe estar vacío");
      if(a.clase==="restituye"&&(a.dacionPagoCents??0)!==0)errors.push("dacionPagoCents debe estar vacío");
    }
  }else{
    if(![1,2,3,4].includes(a.concepto??0))errors.push("concepto inválido");
    if(!rates.has(a.alicuotaCodigo??0))errors.push("Código de alícuota inexistente");
    if(!money(a.netoCents))errors.push("netoCents obligatorio");
    if(!money(a.impuestoFacturadoCents))errors.push("impuestoFacturadoCents obligatorio");
    if(a.clase==="genera"&&!money(a.impuestoComputableCents))errors.push("impuestoComputableCents obligatorio");
    if(a.clase==="restituye"&&(a.impuestoComputableCents??0)!==0)errors.push("impuestoComputableCents debe estar vacío");
    if((a.exentoCents??0)!==0)errors.push("exentoCents debe estar vacío");
  }
  return errors;
}
const exact=(fields:(string|number)[])=>`${fields.join(";")}\r\n`;const trailing=(fields:(string|number)[])=>`${fields.join(";")};\r\n`;
export type CsvAjustes={debito:string;restitucionDebito:string;credito:string;restitucionCredito:string};
export function csvAjustes(rows:Ajuste[]):CsvAjustes{const out:CsvAjustes={debito:"",restitucionDebito:"",credito:"",restitucionCredito:""};for(const a of rows){const errors=validarAjuste(a);if(errors.length)throw new Error(errors.join(". "));if(a.lado==="debito"&&a.clase==="genera"){const exento=a.tipoOperacion===3;out.debito+=exact(exento?[a.actividad!,3,"","","","","",money(a.exentoCents??0)]:[a.actividad!,a.tipoOperacion!,a.tipoSujeto!,a.alicuotaCodigo!,money(a.netoCents),money(a.impuestoFacturadoCents),a.dacionPagoCents?money(a.dacionPagoCents):"",""]);}if(a.lado==="debito"&&a.clase==="restituye"){const exento=a.tipoOperacion===2;out.restitucionDebito+=exact(exento?[a.actividad!,2,"","","","","",money(a.exentoCents??0)]:[a.actividad!,a.tipoOperacion!,a.tipoSujeto!,a.alicuotaCodigo!,money(a.netoCents),money(a.impuestoFacturadoCents),"",""]);}if(a.lado==="credito"&&a.clase==="genera")out.credito+=trailing([a.concepto!,a.alicuotaCodigo!,money(a.netoCents),money(a.impuestoFacturadoCents),money(a.impuestoComputableCents??0)]);if(a.lado==="credito"&&a.clase==="restituye")out.restitucionCredito+=trailing([a.concepto!,a.alicuotaCodigo!,money(a.netoCents),money(a.impuestoFacturadoCents)]);}return out;}

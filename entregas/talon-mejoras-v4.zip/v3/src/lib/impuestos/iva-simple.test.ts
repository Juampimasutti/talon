import { describe, expect, it } from "vitest";
import { agregarIvaSimple, avisosTamanoExportacion } from "./iva-simple";

describe("IVA Simple", () => {
  it("aplica signo y convierte moneda por alícuota", () => {
    expect(agregarIvaSimple([
      { libro: "ventas", codigo: 5, netoCents: 10000, ivaCents: 2100, signo: 1, tipoCambio: 1 },
      { libro: "ventas", codigo: 5, netoCents: 2000, ivaCents: 420, signo: -1, tipoCambio: 1 },
      { libro: "compras", codigo: 5, netoCents: 100, ivaCents: 21, signo: 1, tipoCambio: 1050.5 },
    ])).toEqual([
      { libro: "compras", codigo: 5, netoCents: 105050, ivaCents: 22061 },
      { libro: "ventas", codigo: 5, netoCents: 8000, ivaCents: 1680 },
    ]);
  });

  it("avisa topes de TXT y ZIP", () => {
    expect(avisosTamanoExportacion([{ name: "a.txt", bytes: 70_000_001 }], 10_000_001)).toEqual([
      "a.txt supera 70 MB.", "El ZIP supera 10 MB.",
    ]);
  });
});

export type Vencimiento = { obligacion:string;periodo:string;terminacionDesde:number;terminacionHasta:number;fecha:string;fuenteUrl:string };
export function proximoVencimiento(cuit:string,obligacion:string,periodo:string,rows:Vencimiento[]){
  const digits=cuit.replace(/\D/g,"");if(digits.length!==11)return null;const end=Number(digits.at(-1));
  return rows.find(r=>r.obligacion===obligacion&&r.periodo===periodo&&end>=r.terminacionDesde&&end<=r.terminacionHasta)??null;
}

export function vencidoSinConfirmar(fecha:string,estado:"abierto"|"cerrado"|null,hoy:string){
  return fecha<hoy&&estado!=="cerrado";
}

export type VencimientoEstado=Vencimiento&{estado:"abierto"|"cerrado"|null};
export function obligacionParaCondicion(condicion:string,flujo?:string){
  if(condicion==="exento")return "lid_exento";
  if(condicion!=="ri")return null;
  return flujo==="f2002_lid"?"f2002":"iva_simple";
}
export function seleccionarVencimiento(rows:VencimientoEstado[],condicion:string,hoy:string,flujo?:string){
  const obligacion=obligacionParaCondicion(condicion,flujo);if(!obligacion)return null;
  const candidates=rows.filter(r=>r.obligacion===obligacion).sort((a,b)=>a.fecha.localeCompare(b.fecha));
  return candidates.find(r=>r.fecha<hoy&&r.estado!=="cerrado")??candidates.find(r=>r.fecha>=hoy)??null;
}

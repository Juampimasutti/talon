import {describe,expect,it} from "vitest";
import {csvPracticadas,validarImportePracticado} from "./practicadas";

describe("retenciones practicadas",()=>{
  it("tolera cinco centavos",()=>{expect(validarImportePracticado(10_000,2100,2105)).toBeNull();expect(validarImportePracticado(10_000,2100,2106)).toContain("no coincide");});
  it("genera un CSV alineado y con coma decimal",()=>{
    const csv=csvPracticadas([{id:"omitido",tipo:"retencion",sujetoCuit:"20111111112",sujetoDenominacion:"SUJETO EJEMPLO",regimen:"1",baseCents:12345,alicuotaBps:2100,importeCents:2592,fecha:"2026-09-10",numeroCertificado:"A-1",estado:"vigente"}]);
    const [head,row]=csv.trim().replace(/^\uFEFF/,"").split("\r\n");
    expect(head.split(";")).toHaveLength(9);expect(row.split(";")).toHaveLength(9);
    expect(row).toContain('"123,45"');expect(row).toContain('"25,92"');
  });
});

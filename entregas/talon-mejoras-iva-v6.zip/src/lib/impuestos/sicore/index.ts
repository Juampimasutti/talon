import{formatFixed,type FixedField}from"../libro-iva-digital";
export type SicoreRow={comprobante:number;fechaComprobante:string;numeroComprobante:string;importeComprobanteCents:number;impuesto:number;regimen:number;operacion:number;baseCents:number;fechaRetencion:string;condicion:number;suspendido?:boolean;importeRetencionCents:number;porcentajeExclusionCents?:number;fechaBoletin?:string;tipoDocumento:number;numeroDocumento:string;certificadoOriginal:string};
const f=(n:number,d:number,h:number,t:FixedField<SicoreRow>["tipo"],nombre:string,value:FixedField<SicoreRow>["value"]):FixedField<SicoreRow>=>({n,desde:d,hasta:h,tipo:t,nombre,value});const date=(x:string)=>x?x.slice(0,10).split("-").reverse().join("/"):"";const decimal=(cents:number)=>`${cents<0?"-":""}${Math.trunc(Math.abs(cents)/100)},${String(Math.abs(cents)%100).padStart(2,"0")}`;
/** Todos los campos y posiciones son deducidos del ejemplo, a confirmar con la ayuda de SICORE. */
export const SICORE:FixedField<SicoreRow>[]=[
 f(1,1,2,"N","Comprobante — deducido del ejemplo, a confirmar con la ayuda de SICORE",r=>r.comprobante),
 f(2,3,12,"A","Fecha comprobante — deducido del ejemplo, a confirmar con la ayuda de SICORE",r=>date(r.fechaComprobante)),
 f(3,13,28,"N","Número — deducido del ejemplo, a confirmar con la ayuda de SICORE",r=>r.numeroComprobante.replace(/\D/g,"")),
 f(4,29,44,"N","Importe comprobante — deducido del ejemplo, a confirmar con la ayuda de SICORE",r=>r.importeComprobanteCents),
 f(5,45,48,"N","Impuesto — deducido del ejemplo, a confirmar con la ayuda de SICORE",r=>r.impuesto),
 f(6,49,51,"N","Régimen — deducido del ejemplo, a confirmar con la ayuda de SICORE",r=>r.regimen),
 f(7,52,52,"N","Operación — deducido del ejemplo, a confirmar con la ayuda de SICORE",r=>r.operacion),
 f(8,53,66,"N","Base — deducido del ejemplo, a confirmar con la ayuda de SICORE",r=>r.baseCents),
 f(9,67,76,"A","Fecha retención — deducido del ejemplo, a confirmar con la ayuda de SICORE",r=>date(r.fechaRetencion)),
 f(10,77,78,"N","Condición — deducido del ejemplo, a confirmar con la ayuda de SICORE",r=>r.condicion),
 f(11,79,79,"N","Suspendido — deducido del ejemplo, a confirmar con la ayuda de SICORE",r=>r.suspendido?1:0),
 f(12,80,93,"D","Retención — deducido del ejemplo, a confirmar con la ayuda de SICORE",r=>decimal(r.importeRetencionCents)),
 f(13,94,99,"N","Exclusión — deducido del ejemplo, a confirmar con la ayuda de SICORE",r=>r.porcentajeExclusionCents??0),
 f(14,100,109,"A","Boletín — deducido del ejemplo, a confirmar con la ayuda de SICORE",r=>date(r.fechaBoletin??"")),
 f(15,110,111,"N","Tipo documento — deducido del ejemplo, a confirmar con la ayuda de SICORE",r=>r.tipoDocumento),
 f(16,112,131,"A","Documento — deducido del ejemplo, a confirmar con la ayuda de SICORE",r=>r.numeroDocumento.replace(/\D/g,"")),
 f(17,132,145,"N","Certificado original — deducido del ejemplo, a confirmar con la ayuda de SICORE",r=>r.certificadoOriginal),
];
export function validarCodigosSicore(r:Pick<SicoreRow,"impuesto"|"regimen"|"operacion"|"condicion"|"tipoDocumento"|"certificadoOriginal">){const errors:string[]=[];if(!Number.isInteger(r.impuesto)||r.impuesto<1||r.impuesto>9999)errors.push("Impuesto SICORE inválido");if(!Number.isInteger(r.regimen)||r.regimen<1||r.regimen>999)errors.push("Régimen SICORE inválido");if(!Number.isInteger(r.operacion)||r.operacion<1||r.operacion>9)errors.push("Operación SICORE inválida");if(!Number.isInteger(r.condicion)||r.condicion<0||r.condicion>99)errors.push("Condición SICORE inválida");if(!Number.isInteger(r.tipoDocumento)||r.tipoDocumento<0||r.tipoDocumento>99)errors.push("Tipo de documento SICORE inválido");if(!/^\d{1,14}$/.test(r.certificadoOriginal))errors.push("Certificado original SICORE inválido");return errors;}
export function sicore(r:SicoreRow){const errors=validarCodigosSicore(r);if(errors.length)throw new Error(errors.join(". "));return formatFixed(r,SICORE)}export function sicoreTxt(rows:SicoreRow[]){return rows.length?`${rows.map(sicore).join("\r\n")}\r\n`:"";}

export function validarImportePracticado(baseCents:number,alicuotaBps:number,importeCents:number,toleranciaCents=5){
  const esperado=Math.round(baseCents*alicuotaBps/10000);
  return Math.abs(esperado-importeCents)<=toleranciaCents?null:`El importe no coincide con base × alícuota (esperado ${esperado})`;
}

import{describe,expect,it}from"vitest";import{validarImportePracticado}from"./practicadas";
describe("retenciones practicadas",()=>{it("valida importe con tolerancia configurada",()=>{expect(validarImportePracticado(100000,300,3000,5)).toBeNull();expect(validarImportePracticado(100000,300,3006,5)).toContain("no coincide");});});

# Mejoras de Impuestos

## T1 · Moneda extranjera

- La liquidación convierte IVA, crédito y percepciones a pesos con `round(cents × tipo_cambio)` por alícuota.
- LID, CSV y XLSX expresan importes en pesos y conservan moneda y tipo de cambio.
- La base conserva los valores originales.
- Prueba: importar el fixture DOL y calcular 202609; USD 210 con TC 1050,5 aporta 22.060.500 centavos.

## T2 · Períodos confirmados

- La importación comprueba el cierre antes de crear `imp_import_jobs`.
- Los errores PostgreSQL 55000 se reconocen también dentro de `cause` y se traducen a 409.

## T3 · Período y fecha

- AAAAMM acepta 01–12 y años 2000–2100.
- Ventas de otro período y compras futuras se rechazan. Compras anteriores entran con revisión por cómputo diferido.

## T4 · Condición de IVA

- Lista única: RI, monotributo, exento, consumidor final y no alcanzado.
- Migración 0039 normaliza valores inválidos a RI, deja auditoría y agrega CHECK.
- F.2002 devuelve 409 para sujetos que no son RI. Los exentos conservan la exportación LID.

## T5 · Correcciones menores

- Un receptor distinto del titular queda con aviso y revisión.
- El vencimiento de pago se conserva cuando el archivo trae la columna y ocupa el campo 22 del LID.
- El ZIP omite archivos vacíos.
- TODO documentado: el README asigna permisos de Contabilidad al Contador aunque el módulo está intencionalmente apagado. No se modificó por estar fuera de alcance.

## T6 · IVA Simple

- Migración 0040: esquema por cliente e inicio configurable.
- Selección pura entre IVA Simple, F.2002/LID, LID exento y no corresponde.
- Resumen F.2051 por alícuota y certificados en `GET /api/impuestos/iva-simple/resumen`.
- Los endpoints de liquidación, reapertura y exportación reutilizan el cierre y los diseños comprobados.
- TODO: CSV “Ajustes y otros conceptos”. El PDF con columnas y códigos no está en el repo; no se inventó el formato.

## F1 · Retenciones y percepciones sufridas

- Migración 0042 con aislamiento por estudio y empresa cliente.
- API CRUD, duplicados, cierre de período y ventana origen+5 para percepciones.
- Pantalla de carga y consulta por período dentro de Ventas.
- La liquidación suma automáticamente certificados del período de cómputo; los campos manuales quedan como otros importes.
- TODO: importador oficial, pendiente del diseño de ARCA.

## F2 · Prorrateo

- Destino del crédito por compra: directo gravado, directo exento o prorrateable.
- Coeficiente automático por ventas y coeficiente manual configurable y auditado.
- La liquidación guarda el coeficiente usado.
- TODO: ajuste anual, pendiente de una fuente oficial inequívoca.

## F3 · Retenciones y percepciones practicadas

- Migración 0045 modela sujeto, régimen, base, alícuota, importe, fecha, comprobante y certificado con RLS.
- TODO: exportaciones SIRE F.2005 y SICORE F.744. Los diseños oficiales de registro no están disponibles localmente; no se inventaron posiciones.

## F4 · Vencimientos

- Migración 0043 global con fuente URL y fechas oficiales indicadas para 09/2026.
- Helper probado para todas las terminaciones y visualización en la empresa fiscal.

## F5 · Comprobantes manuales

- API de alta, edición de origen manual y baja lógica con control de período, duplicado, tipo, documento, total, IVA, crédito B/C y tolerancia.
- Clasificación para prorrateo y auditoría.
- Formulario visual de alta dentro de Ventas y Compras.
- Endpoint para deshacer un lote mediante baja lógica, motivo y auditoría.

## F6 · Diseños especiales

- TODO: servicios importados, TurIVA y bienes usados. El repo no contiene los diseños oficiales; no se generan archivos vacíos ni formatos supuestos.

## Migraciones

- 0039 condición IVA.
- 0040 configuración IVA Simple.
- 0041 vencimiento de pago.
- 0042 certificados sufridos.
- 0043 calendario.
- 0044 prorrateo.
- 0045 certificados practicados.

# Mejoras IVA v3 — brief v2 (23/10/2026)

Base: ZIP v2 copiado a `/workspace/saas/v3`, repositorio inicializado en la rama `mejoras-iva-v2`. Entorno probado con Node.js 24.19.0, npm 11.9.0 y PostgreSQL 16.15.

## B1 — resumen de IVA Simple
- El resumen aplica el signo de `imp_tipos_comprobante` y redondea cada neto/IVA después de convertir por `tipo_cambio`.
- Se agregó `src/lib/impuestos/iva-simple.ts` y prueba con NC y comprobante en dólares.
- Prueba API con los fixtures 202609: débito del resumen `2.877.000`, igual a `debitoFiscalCents`; crédito `24.370.501`, igual a `creditoComprasCents`. La factura USD quedó convertida con TC 1050,5.

## B2 — guardia de certificados
- Migración `0046_impuestos_guardias_y_practicadas.sql`: trigger 55000 sobre OLD y NEW de `periodo_computo`.
- PATCH comprueba primero el período original y luego el nuevo, con respuesta 409 clara.
- Repro API: mover un certificado desde 202609 confirmado a 202610 respondió 409. El test PostgreSQL verificó el código 55000.

## B3 — períodos inválidos
- `parsePeriodo` y `withErrors` traducen Zod a 400.
- Las cinco rutas del brief respondieron `400 Período inválido` para 202613: libro, exportar, liquidación, certificados e IVA Simple.
- Se mantienen los límites 2000-01 a 2100-12.

## B4 — fecha contra período
- POST y PATCH manuales aplican `reglaFechaImportada`.
- Verificado por API: venta 202608 en 202609 → 400; compra 202611 en 202609 → 400; compra 202608 en 202609 → 200, `requiere_revision=true` y aviso de cómputo diferido.

## B5 — auditoría
- Las bajas de comprobantes y certificados exigen motivo y escriben `impuestos.comprobante.anular` / `impuestos.certificado.anular`.
- Confirmar liquidación e importar escriben auditoría.
- Conteo manual comprobado: 1 baja de comprobante, 1 baja de certificado, 2 importaciones y 1 liquidación confirmada.

## P1 — IVA Simple
- `esquemaParaPeriodo` gobierna resumen, exportación y liquidación; `no_corresponde` responde 409 y el aviso de F.2002 posterior a 202511 llega a API/UI.
- Pantalla IVA Simple por empresa: resumen por alícuota, certificados, saldos, confirmar/reabrir y descargas disponibles.
- Avisos de tamaño: TXT >10 MB, TXT >70 MB y ZIP >10 MB.
- **TODO ARCA:** el PDF oficial de “Ajustes y otros conceptos” respondió HTTP 403 el 23/10/2026. No se genera CSV sin posiciones y códigos oficiales. Por ese motivo no corresponde snapshot del CSV.

## P2 — prorrateo
- PATCH individual y masivo de `destinoCredito`, válidos para comprobantes importados, con cierre y auditoría.
- Selector en Libro IVA Compras.
- Verificación API: la factura 1001 fue marcada `prorratea`; con venta exenta el coeficiente fue 5781 bps y el crédito bajó de 24.370.501 a 23.484.511.
- El diseño del LID para informar prorrateo queda **TODO** hasta disponer de especificación oficial inequívoca.

## P3 — certificados
- `periodoOrigen` debe coincidir con el mes de `fecha`.
- Pendientes muestra percepciones futuras y marca el mes límite origen+5.
- La liquidación separa certificados automáticos de importes manuales.
- Importador oficial: **TODO**, no se encontró un diseño oficial de registro utilizable.

## P4 — retenciones practicadas
- CRUD con edición, baja lógica, motivo, auditoría, control de período y relación opcional con comprobante de venta.
- Valida `importe = base × alícuota` con tolerancia de `imp_config`; incluye listado, formulario y CSV.
- Migración 0046 amplía policy/GRANT. Tests de importe y RLS en verde.
- SIRE F.2005 y SICORE F.744: **TODO** hasta obtener diseños oficiales; no se inventaron posiciones.

## P5 — vencimientos
- Tablero y detalle muestran próximo vencimiento, estado abierto/confirmado y resaltan vencidos sin confirmar.
- Helper y pruebas para terminaciones, ausencia de datos y vencido sin confirmar.
- **TODO de datos:** `https://seti.afip.gob.ar/av/viewVencimientos.do` respondió HTTP 403. Se conserva únicamente 202609, ya verificado (19–23/10/2026; exentos 15/10/2026); no se calcularon fechas por fórmula.

## P6 — períodos
- Cubierto por B3/B4, con meses y años fuera de rango rechazados.

## P7 — sujetos exentos
- **TODO ARCA:** el diseño oficial no pudo obtenerse en este entorno. Se conserva el LID común con aviso explícito y no se afirma compatibilidad con el diseño de sujetos exentos.

## P8 — servicios, TurIVA y bienes usados
- **TODO ARCA:** no se generan archivos especiales sin sus diseños oficiales. No se modelaron posiciones estimadas ni se incluyeron archivos vacíos en el ZIP.

## Menores
- CSV del LID emite Tipo, Punto de venta y Número como enteros.
- Los 409 usan “Reabrilo para continuar” y los movimientos de certificado identifican período original/nuevo.
- Una reimportación ignora comprobantes anulados; historial de importaciones permite deshacer con motivo.
- RLS cubre certificados, retenciones practicadas y escritura denegada de vencimientos.

## Verificación
- `npx vitest run`: 43 archivos aprobados, 162 tests aprobados, 26 omitidos por flags de integración.
- `npx tsc --noEmit`: correcto.
- `npm run lint`: 0 errores, 3 advertencias preexistentes (TanStack Virtual y navegación de sesión).
- `npm run build`: correcto, 44 rutas.
- `RUN_DB_TESTS=1 npx vitest run src/lib/db/`: 13 tests DB aprobados (11 Impuestos/RLS, 1 RLS general, 1 seed); 14 flows omitidos por su flag propio.
- `npm run test:flows`: 14/14 circuitos HTTP con PostgreSQL aprobados.
- Migraciones: correctas desde base vacía y desde una base detenida exactamente en 0037.
- Repros API B1–B5: ejecutadas en servidor local de desarrollo contra PostgreSQL de demostración.

No se realizó ninguna acción externa ni presentación ante ARCA.

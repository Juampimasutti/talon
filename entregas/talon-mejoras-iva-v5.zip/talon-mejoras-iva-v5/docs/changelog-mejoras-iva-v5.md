# Mejoras IVA v5 — entrega

Fecha: 23/10/2026. Rama: `mejoras-iva-v4`.

## Cambios y prueba asociada

- V1 — deshacer una importación deja el trabajo en `deshecho`, impide un segundo deshacer activo y permite reimportar el archivo. Prueba: `V1: deshace una sola vez y permite reimportar el mismo archivo` en `impuestos-rls.integration.test.ts`. **VERIFICADO**.
- V2 — F.2003, F.2004 y F.2005 escriben importes con coma y dos decimales en sus posiciones oficiales. Pruebas `V2 F.2003...`, `V2 F.2004...` y `V2 F.2005...` en `sire/index.test.ts`. **VERIFICADO**.
- Ajustes IVA Simple — genera débito, restitución de débito, crédito y restitución de crédito; incorpora dación en pago. Suite `ajustes IVA Simple — cuatro estructuras oficiales`. **VERIFICADO**, incluida comparación estructural local con ejemplos autorizados sin copiarlos al repositorio.
- V4 — importaciones de servicios protegidas en INSERT, UPDATE y DELETE cuando el período está confirmado. Prueba `V4: protege importaciones de servicios...`. **VERIFICADO**.
- V5 — ajustes abiertos editables y guardia segura para INSERT, UPDATE y DELETE; la API devuelve 409 en períodos confirmados. Prueba `V5: permite ajustes abiertos...`. **VERIFICADO**.
- V6 — comprobantes 030, 032 y 049 separados en cabecera y alícuotas de bienes usados, de 325 y 84 caracteres con CRLF. Suite `bienes usados`. **VERIFICADO**.
- V7 — ventas TurIVA excluye 063; compras TurIVA conserva 063, 195, 196 y 197. Suite `TurIVA`. **VERIFICADO**.
- V8 — importaciones de servicios admiten edición y anulación lógica con motivo y auditoría; respetan períodos confirmados. Prueba V4 ampliada y pruebas DB/RLS. **VERIFICADO**.
- SIRE — modelo, carga y exportación de F.2003/F.2004. La prueba de flujo valida HTTP 200 para F.2004 completo y 409 con identificación del registro para F.2003 incompleto. **VERIFICADO**.
- SICORE — máscara experimental corregida de 146 a 145 posiciones, importes con coma, comprobante numérico y documento alineado a izquierda. Prueba `genera la máscara deducida de 145 posiciones`. **VERIFICADO ESTRUCTURALMENTE**.
- P1 — límites exactos de 15 MB para importación y avisos de 10/70 MB para exportación. Prueba `respeta exactamente los límites de tamaño de la API`. **VERIFICADO**.
- P2 — el campo 21 del Libro IVA Digital usa el crédito computable después del prorrateo. Prueba `lleva al campo 21 el crédito computable prorrateado`. **VERIFICADO**.
- C — tablero de empresas ordenado por vencidos abiertos, próximos vencimientos y empresas sin fecha. Prueba `muestra vencidos abiertos, próximos y empresas sin fecha`. **VERIFICADO**.

## Verificación integral

Entorno: Node.js 24.19.0, npm 11.9.0 y PostgreSQL 16.15.

- `npm test`: 191 aprobadas, 32 omitidas por sus banderas de integración.
- `npx tsc --noEmit`: correcto.
- `npm run lint`: correcto, 0 errores y 3 advertencias conocidas (TanStack Virtual y navegación de cierre de sesión).
- `RUN_DB_TESTS=1 npm run test:db`: 17 aprobadas.
- `npm run test:flows`: build de producción correcto y 14 flujos aprobados.
- Base vacía: verificada por `seed.integration.test.ts`, que aplica todas las migraciones.
- Actualización desde 0048: verificada en una base temporal hasta `0054_impuestos_sire_formularios.sql`.
- Control de privacidad previo a cada commit: correcto; no se incorporaron CUIT ni archivos de los ejemplos reales.

## Pendientes reales

- **NO VERIFICADO:** importación de los TXT en los aplicativos o servicios reales de ARCA.
- **NO VERIFICADO:** máscara SICORE contra la ayuda oficial interna de SICORE 9; el diseño sigue marcado como experimental.
- **NO VERIFICADO:** ejecución manual de esta entrega en otra PC con Windows.
- **NO VERIFICADO:** presentación fiscal real. La entrega genera borradores y archivos; no transmite datos a ARCA.

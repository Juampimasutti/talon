// @vitest-environment happy-dom
import {afterEach,expect,it,vi} from 'vitest';
import {render,fireEvent,waitFor,cleanup} from '@testing-library/react';
import {ComprobanteManualScreen} from './comprobante-manual-screen';
afterEach(()=>{cleanup();vi.clearAllMocks()});
it('el clic guarda y limpia el formulario sin error',async()=>{
 const fetchMock=vi.fn(async(...args:Parameters<typeof fetch>)=>{void args;return new Response(JSON.stringify({ok:true,data:{id:'ficticio'}}),{status:200,headers:{'Content-Type':'application/json'}})});vi.stubGlobal('fetch',fetchMock);
 const view=render(<ComprobanteManualScreen empresaId="empresa-ficticia" libro="compras"/>);
 const fill=(name:string,value:string)=>fireEvent.change(view.container.querySelector(`[name="${name}"]`)!,{target:{value}});
 fill('fecha','2026-10-23');fill('tipo','1');fill('punto','1');fill('numero','1');fill('cuit','20123456786');fill('nombre','Empresa Ficticia');
 const inputs=view.getAllByLabelText('Neto');fireEvent.change(inputs[0],{target:{value:'100,00'}});
 fireEvent.click(view.getByRole('button',{name:'Guardar comprobante'}));
 await waitFor(()=>expect(fetchMock).toHaveBeenCalledTimes(1));
 await waitFor(()=>expect(view.getByRole('status').textContent).toBe('Comprobante guardado'));
 expect(fetchMock.mock.calls[0][1]?.method).toBe('POST');
 expect((view.getByLabelText('Denominación') as HTMLInputElement).value).toBe('');
 expect(view.queryByText(/Cannot read properties/)).toBeNull();
});
it('filtra letras con la matriz según ambas condiciones IVA',()=>{
 const view=render(<ComprobanteManualScreen empresaId="empresa-ficticia" libro="ventas" condicionIva="monotributo"/>);
 fireEvent.change(view.getByLabelText('Condición IVA de la contraparte'),{target:{value:'ri'}});
 const options=[...(view.getByLabelText('Tipo de comprobante') as HTMLSelectElement).options].filter(x=>x.value);
 expect(options.length).toBeGreaterThan(0);
 expect(options.every(x=>x.textContent?.includes(' C'))).toBe(true);
});
